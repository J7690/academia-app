# SMART WHITEBOARD IA V1 – LIFECYCLE & FAILURE MANAGEMENT

**Version** : 1.0  
**Date** : 23 Juin 2026  
**Mode** : LECTURE SEULE  
**Objectif** : Validation du cycle de vie complet

---

## DIRECTIVE TECHNIQUE PERMANENTE

Toute validation concernant Supabase, Kamatera Cloud, Docker, FFmpeg, Backend Python, Tables, Buckets, RPC, Edge Functions doit obligatoirement être réalisée via les RPC Python administrateurs présents dans `.windsurf`.

Aucune hypothèse autorisée.

---

## PARTIE 1 – CYCLE DE VIE NORMAL

### 1.1 Flux complet

```
1. Création projet
   ↓
2. Génération storyboard (Bobodo)
   ↓
3. Validation utilisateur (édition)
   ↓
4. Narration (TTS ou enregistrement)
   ↓
5. Render Job (création)
   ↓
6. Rendu Kamatera (traitement)
   ↓
7. MP4 (génération)
   ↓
8. Publication (pipeline existant)
```

### 1.2 Détail des étapes

#### Étape 1 : Création projet

**Action** : Utilisateur saisit un sujet

**Composant** : SmartWhiteboardInputScreen

**État** : Projet créé avec status = "draft"

**Transition** : → Étape 2

#### Étape 2 : Génération storyboard

**Action** : Bobodo génère le Storyboard JSON

**Composant** : Edge Function bobodo-chat

**État** : Storyboard généré, stocké dans storyboard_json

**Transition** : → Étape 3

**Échec possible** : Bobodo échoue (voir Partie 3)

#### Étape 3 : Validation utilisateur

**Action** : Utilisateur édite le Storyboard

**Composant** : SmartWhiteboardEditorScreen

**État** : Storyboard modifié, updated_at mis à jour

**Transition** : → Étape 4

#### Étape 4 : Narration

**Action** : Utilisateur enregistre ou génère TTS

**Composant** : SmartWhiteboardNarrationService

**État** : Narration uploadée dans whiteboard-narrations, narration_mode mis à jour

**Transition** : → Étape 5

**Échec possible** : Narration absente (voir Partie 3)

#### Étape 5 : Render Job

**Action** : Création d'un job de rendu

**Composant** : RPC app_whiteboard_create_render_job

**État** : RenderJob créé avec status = "queued"

**Transition** : → Étape 6

#### Étape 6 : Rendu Kamatera

**Action** : Worker Kamatera traite le job

**Composant** : whiteboard_render_worker.py

**État** : RenderJob status = "processing"

**Transition** : → Étape 7

**Échec possible** : Rendu échoue, FFmpeg échoue, timeout Kamatera (voir Partie 3)

#### Étape 7 : MP4

**Action** : MP4 généré et uploadé

**Composant** : whiteboard_main.py

**État** : RenderJob status = "done", video_url renseigné

**Transition** : → Étape 8

#### Étape 8 : Publication

**Action** : Navigation vers video_publish_screen

**Composant** : SmartWhiteboardPreviewScreen → video_publish_screen

**État** : Projet status = "completed"

**Transition** : Fin

---

## PARTIE 2 – MACHINE D'ÉTATS

### 2.1 États du projet

| État | Description | État initial | État final |
|------|-------------|--------------|------------|
| draft | Projet en cours d'édition | ✅ | ❌ |
| completed | Projet terminé | ❌ | ✅ |

**Transitions autorisées** :
- draft → completed (après rendu réussi)
- completed → draft (réédition possible)

### 2.2 États du RenderJob

| État | Description | État initial | État final |
|------|-------------|--------------|------------|
| queued | En attente de traitement | ✅ | ❌ |
| processing | En cours de traitement | ❌ | ❌ |
| done | Terminé avec succès | ❌ | ✅ |
| failed | Échec | ❌ | ✅ |

**Transitions autorisées** :
- queued → processing (worker prend le job)
- processing → done (rendu réussi)
- processing → failed (rendu échoué)
- failed → queued (retry)
- failed → done (manuel)

### 2.3 États de la narration

| État | Description | État initial | État final |
|------|-------------|--------------|------------|
| none | Pas de narration | ✅ | ❌ |
| tts | Narration TTS générée | ❌ | ✅ |
| user_recording | Narration enregistrée | ❌ | ✅ |

**Transitions autorisées** :
- none → tts (génération TTS)
- none → user_recording (enregistrement)
- tts → none (suppression)
- user_recording → none (suppression)
- tts → user_recording (remplacement)
- user_recording → tts (remplacement)

---

## PARTIE 3 – GESTION DES ÉCHECS

### 3.1 Cas 1 : Bobodo échoue

**Scénario** : Bobodo ne peut pas générer le Storyboard

**Comportement attendu** :
- Afficher un message d'erreur à l'utilisateur
- Permettre à l'utilisateur de réessayer
- Permettre à l'utilisateur de créer un Storyboard manuellement

**Récupération possible** : ✅ Oui

**Message utilisateur** : "La génération du Storyboard a échoué. Veuillez réessayer ou créer un Storyboard manuellement."

**État du projet** : draft (inchangé)

**Transition** : → Étape 3 (édition manuelle)

---

### 3.2 Cas 2 : Narration absente

**Scénario** : Utilisateur tente de générer un MP4 sans narration

**Comportement attendu** :
- Permettre le rendu sans narration (narration_mode = "none")
- Avertir l'utilisateur que la vidéo sera sans audio

**Récupération possible** : ✅ Oui

**Message utilisateur** : "Aucune narration sélectionnée. La vidéo sera générée sans audio. Voulez-vous continuer ?"

**État du projet** : draft (inchangé)

**Transition** : → Étape 5 (rendu sans narration)

---

### 3.3 Cas 3 : Rendu échoue

**Scénario** : Le rendu échoue sur Kamatera

**Composant** : whiteboard_main.py

**Comportement attendu** :
- Marquer le RenderJob comme "failed"
- Stocker l'erreur dans error_message
- Notifier l'utilisateur via polling
- Permettre à l'utilisateur de réessayer

**Récupération possible** : ✅ Oui

**Message utilisateur** : "Le rendu a échoué : {error_message}. Veuillez réessayer."

**État du RenderJob** : failed

**Transition** : → Étape 5 (retry)

---

### 3.4 Cas 4 : FFmpeg échoue

**Scénario** : FFmpeg ne peut pas assembler les images en MP4

**Composant** : video_assembler.py

**Comportement attendu** :
- Capturer l'erreur FFmpeg
- Marquer le RenderJob comme "failed"
- Stocker l'erreur dans error_message
- Nettoyer les fichiers temporaires

**Récupération possible** : ✅ Oui

**Message utilisateur** : "Le rendu a échoué : erreur FFmpeg. Veuillez réessayer."

**État du RenderJob** : failed

**Transition** : → Étape 5 (retry)

---

### 3.5 Cas 5 : Timeout Kamatera

**Scénario** : Le rendu dépasse le temps maximum (30 minutes)

**Composant** : whiteboard_render_worker.py

**Comportement attendu** :
- Marquer le RenderJob comme "failed"
- Stocker l'erreur dans error_message
- Nettoyer les fichiers temporaires

**Récupération possible** : ✅ Oui

**Message utilisateur** : "Le rendu a expiré (timeout). Veuillez réessayer."

**État du RenderJob** : failed

**Transition** : → Étape 5 (retry)

---

### 3.6 Cas 6 : Perte connexion

**Scénario** : Perte de connexion entre Flutter et Supabase

**Composant** : SmartWhiteboardService

**Comportement attendu** :
- Afficher un message d'erreur à l'utilisateur
- Permettre à l'utilisateur de réessayer
- Sauvegarder localement le Storyboard (cache)

**Récupération possible** : ✅ Oui

**Message utilisateur** : "Connexion perdue. Veuillez vérifier votre connexion et réessayer."

**État du projet** : draft (inchangé)

**Transition** : → Étape courante (retry)

---

### 3.7 Cas 7 : Abandon utilisateur

**Scénario** : Utilisateur abandonne le projet

**Composant** : SmartWhiteboardInputScreen, SmartWhiteboardEditorScreen, SmartWhiteboardPreviewScreen

**Comportement attendu** :
- Permettre à l'utilisateur de supprimer le projet
- Nettoyer les fichiers temporaires
- Conserver le projet en draft (optionnel)

**Récupération possible** : ✅ Oui

**Message utilisateur** : "Projet abandonné. Voulez-vous supprimer le projet ou le conserver en brouillon ?"

**État du projet** : draft (inchangé) ou supprimé

**Transition** : Fin

---

## PARTIE 4 – REPRISE

### 4.1 Reprise après interruption

**Scénario** : L'utilisateur quitte l'application pendant le rendu

**Comportement attendu** :
- Le RenderJob continue de s'exécuter sur Kamatera
- À la réouverture, l'utilisateur peut consulter le statut du rendu
- Si le rendu est terminé, l'utilisateur peut publier
- Si le rendu échoue, l'utilisateur peut réessayer

**Récupération possible** : ✅ Oui

**Message utilisateur** : "Un rendu est en cours. Voulez-vous consulter son statut ?"

**État du projet** : draft (inchangé)

**Transition** : → Étape 7 (consultation statut)

### 4.2 Reprise après échec Bobodo

**Scénario** : Bobodo échoue, l'utilisateur quitte l'application

**Comportement attendu** :
- Le projet reste en draft
- À la réouverture, l'utilisateur peut réessayer la génération
- L'utilisateur peut créer un Storyboard manuellement

**Récupération possible** : ✅ Oui

**Message utilisateur** : "La génération du Storyboard a échoué. Voulez-vous réessayer ou créer un Storyboard manuellement ?"

**État du projet** : draft (inchangé)

**Transition** : → Étape 2 (retry) ou Étape 3 (édition manuelle)

### 4.3 Reprise après échec rendu

**Scénario** : Le rendu échoue, l'utilisateur quitte l'application

**Comportement attendu** :
- Le RenderJob reste en failed
- À la réouverture, l'utilisateur peut consulter l'erreur
- L'utilisateur peut réessayer le rendu

**Récupération possible** : ✅ Oui

**Message utilisateur** : "Le rendu a échoué. Voulez-vous réessayer ?"

**État du RenderJob** : failed

**Transition** : → Étape 5 (retry)

---

## PARTIE 5 – NETTOYAGE

### 5.1 Projets abandonnés

**Définition** : Projets en draft depuis plus de 30 jours sans activité

**Politique** : Nettoyage automatique via pg_cron

**Fréquence** : Quotidienne

**Action** :
- Marquer les projets comme "archived"
- Supprimer les fichiers temporaires
- Conserver les projets pour 90 jours avant suppression définitive

**Justification** :
- Économie de stockage
- Performance de la base de données
- Possibilité de récupération

### 5.2 Narrations inutilisées

**Définition** : Fichiers audio dans whiteboard-narrations sans projet associé

**Politique** : Nettoyage automatique via CASCADE

**Fréquence** : À la suppression du projet

**Action** :
- Supprimer le fichier audio
- Nettoyer le bucket

**Justification** :
- Économie de stockage
- Intégrité référentielle

### 5.3 Rendus obsolètes

**Définition** : Fichiers MP4 dans whiteboard-renders sans projet associé

**Politique** : Nettoyage automatique via CASCADE

**Fréquence** : À la suppression du projet

**Action** :
- Supprimer le fichier MP4
- Nettoyer le bucket

**Justification** :
- Économie de stockage
- Intégrité référentielle

### 5.4 Fichiers temporaires

**Définition** : Fichiers temporaires générés par Kamatera

**Politique** : Nettoyage automatique après rendu

**Fréquence** : À la fin du rendu

**Action** :
- Supprimer les images PNG
- Supprimer les fichiers audio temporaires
- Nettoyer le répertoire temporaire

**Justification** :
- Économie de stockage
- Performance du serveur

---

## PARTIE 6 – MONITORING

### 6.1 Logs minimum

| Composant | Log minimum | Niveau | Justification |
|-----------|-------------|--------|---------------|
| Flutter | Création projet, mise à jour, erreur | INFO | Suivi des actions utilisateur |
- Flutter | Appel Bobodo, réponse | INFO | Suivi des appels IA |
- Flutter | Création RenderJob, statut | INFO | Suivi des rendus |
- Kamatera | Début rendu, fin rendu, erreur | INFO | Suivi des traitements |
- Kamatera | Génération images, assemblage MP4 | DEBUG | Débogage technique |
- Supabase | Création projet, mise à jour, suppression | INFO | Suivi des opérations DB |
- Supabase | Création RenderJob, statut | INFO | Suivi des jobs |

### 6.2 Métriques minimum

| Métrique | Source | Fréquence | Justification |
|----------|--------|-----------|---------------|
| Nombre de projets créés | Supabase | Quotidienne | Volume d'utilisation |
- Nombre de rendus réussis | Supabase | Quotidienne | Taux de succès |
- Nombre de rendus échoués | Supabase | Quotidienne | Taux d'échec |
- Durée moyenne des rendus | Kamatera | Quotidienne | Performance |
- Espace de stockage utilisé | Supabase | Quotidienne | Capacité |
- CPU Kamatera | Kamatera | Quotidienne | Ressources |
- RAM Kamatera | Kamatera | Quotidienne | Ressources |

### 6.3 Alertes minimum

| Alerte | Condition | Action | Justification |
|--------|-----------|--------|---------------|
- Taux d'échec élevé | > 20% des rendus échouent | Notification admin | Problème renderer |
- Timeout fréquent | > 10% des rendus timeout | Notification admin | Problème performance |
- Espace insuffisant | > 80% de stockage utilisé | Notification admin | Risque saturation |
- Kamatera down | Conteneur non accessible | Notification admin | Problème infrastructure |
- Supabase down | RPC non accessibles | Notification admin | Problème infrastructure |

---

## PARTIE 7 – MATRICE DE RISQUES

### 7.1 Matrice de risques

| Risque | Probabilité | Impact | Mitigation |
|--------|-------------|--------|------------|
| Bobodo échoue | Moyenne | Moyen | Retry, édition manuelle |
- Narration absente | Faible | Faible | Rendu sans narration |
- Rendu échoue | Moyenne | Moyen | Retry, message d'erreur |
- FFmpeg échoue | Faible | Moyen | Retry, log d'erreur |
- Timeout Kamatera | Faible | Moyen | Retry, timeout configurable |
- Perte connexion | Faible | Faible | Retry, cache local |
- Abandon utilisateur | Moyenne | Faible | Conservation en draft |
- Supabase down | Très faible | Élevé | Retry, notification admin |
- Kamatera down | Très faible | Élevé | Retry, notification admin |
- Espace insuffisant | Faible | Moyen | Nettoyage automatique, alerte |
- Storyboard trop volumineux | Très faible | Faible | Limite de taille, validation |

### 7.2 Analyse des risques critiques

#### Risque 1 : Supabase down

**Probabilité** : Très faible

**Impact** : Élevé

**Mitigation** :
- Retry automatique (3 tentatives)
- Cache local du Storyboard
- Notification admin
- Mode dégradé (édition sans sauvegarde)

**Récupération** : ✅ Oui

#### Risque 2 : Kamatera down

**Probabilité** : Très faible

**Impact** : Élevé

**Mitigation** :
- Retry automatique (3 tentatives)
- Notification admin
- Mode dégradé (pas de rendu)

**Récupération** : ✅ Oui

#### Risque 3 : Bobodo échoue

**Probabilité** : Moyenne

**Impact** : Moyen

**Mitigation** :
- Retry automatique (3 tentatives)
- Édition manuelle
- Message d'erreur clair

**Récupération** : ✅ Oui

#### Risque 4 : Rendu échoue

**Probabilité** : Moyenne

**Impact** : Moyen

**Mitigation** :
- Retry automatique (3 tentatives)
- Log d'erreur détaillé
- Message d'erreur clair

**Récupération** : ✅ Oui

---

## CONCLUSION

### Validation du cycle de vie

**Le Smart Whiteboard IA V1 peut fonctionner même en cas d'échec de Bobodo, Supabase, Kamatera ou du Renderer** ✅

**Justification** :
- Retry automatique pour tous les appels externes
- Mode dégradé (édition sans sauvegarde)
- Cache local du Storyboard
- Messages d'erreur clairs
- Récupération possible pour tous les scénarios

### Points critiques

1. **Bobodo** : Retry + édition manuelle
2. **Supabase** : Retry + cache local
3. **Kamatera** : Retry + notification admin
4. **Renderer** : Retry + log d'erreur

### Recommandations

1. Implémenter le retry automatique pour tous les appels externes
2. Implémenter le cache local du Storyboard
3. Implémenter le monitoring (logs, métriques, alertes)
4. Implémenter le nettoyage automatique (projets abandonnés, fichiers temporaires)
5. Implémenter les messages d'erreur clairs pour l'utilisateur

---

**Fin du document**
