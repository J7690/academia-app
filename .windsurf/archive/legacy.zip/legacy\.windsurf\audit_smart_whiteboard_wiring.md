# SMART WHITEBOARD - CARTOGRAPHIE COMPLÈTE DU CÂBLAGE

## CHAÎNE COMPLÈTE

### 1. UI → SmartWhiteboardProvider

**Fichier :** `academia_app/lib/features/challenge/smart_whiteboard/screens/smart_whiteboard_input_screen.dart`
**Méthode :** `_handleGenerate()`
**Ligne :** 40-83

**Input :**
```dart
- subject: String (via _subjectController.text.trim())
- rendererId: String (_selectedRenderer.name)
- themeId: String (_selectedTheme.name)
- narrationMode: String (_selectedNarrationMode.name)
```

**Output attendu :**
```dart
- Navigation vers '/smart-whiteboard-editor'
- OU SnackBar d'erreur
```

**Code :**
```dart
Future<void> _handleGenerate() async {
  final subject = _subjectController.text.trim();
  
  if (subject.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Veuillez saisir un sujet')),
    );
    return;
  }

  final provider = context.read<SmartWhiteboardProvider>();

  // Create project
  await provider.createProject(
    subject: subject,
    rendererId: _selectedRenderer.name,
    themeId: _selectedTheme.name,
    narrationMode: _selectedNarrationMode.name,
  );

  if (!mounted) return;

  if (provider.state == SmartWhiteboardState.error) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Erreur: ${provider.errorMessage}')),
    );
    return;
  }

  // Generate storyboard
  await provider.generateStoryboard();

  if (!mounted) return;

  if (provider.state == SmartWhiteboardState.error) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Erreur: ${provider.errorMessage}')),
    );
    return;
  }

  // Navigate to storyboard editor
  Navigator.of(context).pushNamed('/smart-whiteboard-editor');
}
```

---

### 2. SmartWhiteboardProvider → SmartWhiteboardService (createProject)

**Fichier :** `academia_app/lib/features/challenge/smart_whiteboard/providers/smart_whiteboard_provider.dart`
**Méthode :** `createProject()`
**Ligne :** 78-104

**Input :**
```dart
- subject: String
- rendererId: String
- themeId: String
- narrationMode: String (default 'none')
```

**Output attendu :**
```dart
- _currentProjectId: String
- _setState(SmartWhiteboardState.idle)
- OU _setError()
```

**Code :**
```dart
Future<void> createProject({
  required String subject,
  required String rendererId,
  required String themeId,
  String narrationMode = 'none',
}) async {
  _setState(SmartWhiteboardState.loading);
  _errorMessage = null;

  try {
    final result = await _projectService.createProject(
      subject: subject,
      rendererId: rendererId,
      themeId: themeId,
      narrationMode: narrationMode,
    );

    if (result['success'] == true) {
      _currentProjectId = result['project_id'] as String;
      _setState(SmartWhiteboardState.idle);
    } else {
      _setError(result['error'] as String? ?? 'Failed to create project');
    }
  } catch (e) {
    _setError(e.toString());
  }
}
```

---

### 3. SmartWhiteboardService → RPC SQL

**Fichier :** `academia_app/lib/features/challenge/smart_whiteboard/services/smart_whiteboard_service.dart`
**Méthode :** `createProject()`
**Ligne :** 17-37

**Input :**
```dart
- subject: String
- rendererId: String
- themeId: String
- narrationMode: String
- storyboardJson: Map<String, dynamic>? (default {})
```

**Output attendu :**
```dart
Map<String, dynamic>:
{
  "success": true,
  "project_id": "UUID"
}
```

**Code :**
```dart
Future<Map<String, dynamic>> createProject({
  required String subject,
  required String rendererId,
  required String themeId,
  String narrationMode = 'none',
  Map<String, dynamic>? storyboardJson,
}) async {
  final response = await _supabase.rpc(
    'whiteboard_create_project',
    params: {
      'p_student_id': _supabase.auth.currentUser?.id,
      'p_subject': subject,
      'p_renderer_id': rendererId,
      'p_theme_id': themeId,
      'p_narration_mode': narrationMode,
      'p_storyboard_json': storyboardJson ?? {},
    },
  );

  return response as Map<String, dynamic>;
}
```

---

### 4. RPC SQL (whiteboard_create_project)

**Fichier :** `.windsurf/deploy_whiteboard_rpcs_via_execute_ddl.py`
**DDL :** ddl10 (lignes 273-319)

**Input :**
```sql
p_student_id UUID
p_subject VARCHAR
p_renderer_id VARCHAR
p_theme_id VARCHAR
p_narration_mode VARCHAR
p_storyboard_json JSONB
```

**Output attendu :**
```json
{
  "success": true,
  "project_id": "UUID"
}
```

**Code SQL :**
```sql
CREATE OR REPLACE FUNCTION app.app_whiteboard_create_project(
  p_student_id UUID,
  p_subject VARCHAR,
  p_renderer_id VARCHAR,
  p_theme_id VARCHAR,
  p_narration_mode VARCHAR,
  p_storyboard_json JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_project_id UUID;
  v_result JSONB;
BEGIN
  INSERT INTO app.whiteboard_projects (
    student_id,
    subject,
    status,
    renderer_id,
    theme_id,
    narration_mode,
    storyboard_json
  ) VALUES (
    p_student_id,
    p_subject,
    'draft',
    p_renderer_id,
    p_theme_id,
    p_narration_mode,
    p_storyboard_json
  )
  RETURNING id INTO v_project_id;

  v_result := jsonb_build_object(
    'success', true,
    'project_id', v_project_id
  );

  RETURN v_result;
END;
$$;
```

---

### 5. SmartWhiteboardProvider → Edge Function

**Fichier :** `academia_app/lib/features/challenge/smart_whiteboard/providers/smart_whiteboard_provider.dart`
**Méthode :** `generateStoryboard()`
**Ligne :** 106-166

**Input :**
```dart
- mode: String (default 'simple_subject')
- subject: String (via _currentProject?.subject)
- content: String
- renderer: String (via _currentProject?.rendererId)
- theme: String (via _currentProject?.themeId)
- narration_mode: String (via _currentProject?.narrationMode)
```

**Output attendu :**
```dart
- _currentStoryboard: Storyboard
- _setState(SmartWhiteboardState.editing)
- OU _setError()
```

**Code :**
```dart
Future<void> generateStoryboard({
  String mode = 'simple_subject',
  String content = '',
}) async {
  if (_currentProjectId == null) {
    _setError('No project selected');
    return;
  }

  _setState(SmartWhiteboardState.bobodoGenerating);
  _errorMessage = null;

  try {
    final client = Supabase.instance.client;
    final userId = client.auth.currentUser?.id;

    if (userId == null) {
      _setError('Not authenticated');
      return;
    }

    final response = await client.functions.invoke(
      'whiteboard-generate-storyboard',
      body: {
        'mode': mode,
        'subject': _currentProject?.subject ?? '',
        'content': content,
        'renderer': _currentProject?.rendererId ?? 'scientific',
        'theme': _currentProject?.themeId ?? 'scientific',
        'narration_mode': _currentProject?.narrationMode ?? 'none',
      },
    );

    if (response.status != 200) {
      final errorData = response.data as Map<String, dynamic>?;
      if (errorData?['error'] == 'insufficient_credits') {
        _setError('Crédits insuffisants. Il vous faut 15 crédits pour générer un Storyboard.');
      } else if (errorData?['error'] == 'invalid_json') {
        _setError('Erreur de génération: JSON invalide. Veuillez réessayer.');
      } else if (errorData?['error'] == 'invalid_storyboard') {
        _setError('Erreur de génération: Storyboard invalide. Veuillez réessayer.');
      } else {
        _setError(errorData?['error'] ?? 'Failed to generate storyboard');
      }
      return;
    }

    final data = response.data as Map<String, dynamic>;
    final storyboardJson = data['storyboard_json'] as Map<String, dynamic>?;

    if (storyboardJson == null) {
      _setError('Erreur: storyboard_json manquant dans la réponse');
      return;
    }

    _currentStoryboard = Storyboard.fromJson(storyboardJson);
    _setState(SmartWhiteboardState.editing);
  } catch (e) {
    _setError(e.toString());
  }
}
```

---

### 6. Edge Function → OpenRouter

**Fichier :** `supabase/functions/whiteboard-generate-storyboard/index.ts`
**Méthode :** `callWithCascade()`
**Ligne :** 30-63

**Input :**
```typescript
- messages: Array<{role:string;content:string}>
- maxTok: number
```

**Output attendu :**
```typescript
{
  content: string,
  model: string,
  tier: string,
  usage: {prompt_tokens, completion_tokens, total_tokens},
  costUsd: number
}
```

**Code :**
```typescript
async function callWithCascade(
  msgs: Array<{role:string;content:string}>,
  maxTok: number
): Promise<CascadeResult> {
  const errs: string[] = [];
  for (const { model, tier } of TEXT_CASCADE) {
    if (!model) continue;
    try {
      const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method:'POST',
        headers:{
          Authorization:`Bearer ${OPENROUTER_API_KEY}`,
          'Content-Type':'application/json',
          Accept:'application/json'
        },
        body:JSON.stringify({
          model,
          messages:msgs,
          temperature:0.2,
          max_tokens:maxTok
        })
      });
      if (!r.ok) { errs.push(`${model}(${r.status})`); continue; }
      const d = await r.json();
      const c = (d?.choices?.[0]?.message?.content??'').toString().trim();
      if (!c) { errs.push(`${model}:empty`); continue; }
      const u = d?.usage ?? {prompt_tokens:0,completion_tokens:0,total_tokens:0};
      const cost = tier==='free'?0:((u.prompt_tokens||0)*0.0000001+(u.completion_tokens||0)*0.0000004);
      console.log(`[cascade] OK: ${model} (${tier}) ${u.total_tokens}tok $${cost.toFixed(6)}`);
      return {content:c,model,tier,usage:u,costUsd:cost};
    } catch(e) { errs.push(`${model}:${(e as Error).message?.slice(0,60)}`); }
  }
  throw new Error(`All models failed: ${errs.join(' | ')}`);
}
```

---

### 7. OpenRouter → Parser TS

**Fichier :** `supabase/functions/whiteboard-generate-storyboard/index.ts`
**Méthode :** JSON.parse() + validateStoryboard()
**Ligne :** 402-439

**Input :**
```typescript
- rawResponse: string (contenu de OpenRouter)
```

**Output attendu :**
```typescript
- parsed: unknown (JSON object)
- OU erreur invalid_json
- OU erreur invalid_storyboard
```

**Code :**
```typescript
// Remove markdown code blocks if present
let jsonToParse = rawResponse.trim();

if (jsonToParse.startsWith('```json')) {
  jsonToParse = jsonToParse.slice(7);
} else if (jsonToParse.startsWith('```')) {
  jsonToParse = jsonToParse.slice(3);
}

if (jsonToParse.endsWith('```')) {
  jsonToParse = jsonToParse.slice(0, -3);
}

jsonToParse = jsonToParse.trim();

let parsed: unknown;
try {
  parsed = JSON.parse(jsonToParse);
} catch (e) {
  await supabase.rpc('app_student_refund_credits', { p_reservation_id: reservationId });
  return jsonResponse({ 
    error: 'invalid_json', 
    detail: (e as Error).message?.slice(0, 300), 
    raw: rawResponse.slice(0, 500) 
  }, 500);
}

// Validate Storyboard
const validation = validateStoryboard(parsed);
if (!validation.valid) {
  await supabase.rpc('app_student_refund_credits', { p_reservation_id: reservationId });
  return jsonResponse({ 
    error: 'invalid_storyboard', 
    detail: validation.error,
    raw: rawResponse.slice(0, 500) 
  }, 500);
}
```

---

### 8. Edge Function → Réponse Supabase

**Fichier :** `supabase/functions/whiteboard-generate-storyboard/index.ts`
**Méthode :** jsonResponse()
**Ligne :** 496-506

**Input :**
```typescript
{
  success: true,
  storyboard_json: sb,
  project_data: projectData,
  credits_used: 15,
  model: cascadeResult.model,
  tokens_input: cascadeResult.usage.prompt_tokens || 0,
  tokens_output: cascadeResult.usage.completion_tokens || 0,
  cost_usd: cascadeResult.costUsd,
}
```

**Output attendu :**
```json
{
  "success": true,
  "storyboard_json": {...},
  "project_data": {...},
  "credits_used": 15,
  "model": "...",
  "tokens_input": 0,
  "tokens_output": 0,
  "cost_usd": 0.0
}
```

**Code :**
```typescript
return jsonResponse({
  success: true,
  storyboard_json: sb,
  project_data: projectData,
  credits_used: 15,
  model: cascadeResult.model,
  tokens_input: cascadeResult.usage.prompt_tokens || 0,
  tokens_output: cascadeResult.usage.completion_tokens || 0,
  cost_usd: cascadeResult.costUsd,
});
```

---

### 9. Réponse Supabase → Parser Flutter

**Fichier :** `academia_app/lib/features/challenge/smart_whiteboard/providers/smart_whiteboard_provider.dart`
**Méthode :** generateStoryboard()
**Ligne :** 153-162

**Input :**
```dart
response.data as Map<String, dynamic>
```

**Output attendu :**
```dart
- storyboardJson: Map<String, dynamic>
- _currentStoryboard: Storyboard
- _setState(SmartWhiteboardState.editing)
```

**Code :**
```dart
final data = response.data as Map<String, dynamic>;
final storyboardJson = data['storyboard_json'] as Map<String, dynamic>?;

if (storyboardJson == null) {
  _setError('Erreur: storyboard_json manquant dans la réponse');
  return;
}

_currentStoryboard = Storyboard.fromJson(storyboardJson);
_setState(SmartWhiteboardState.editing);
```

---

### 10. Parser Flutter → Navigation

**Fichier :** `academia_app/lib/features/challenge/smart_whiteboard/screens/smart_whiteboard_input_screen.dart`
**Méthode :** _handleGenerate()
**Ligne :** 82

**Input :**
```dart
'/smart-whiteboard-editor'
```

**Output attendu :**
```dart
- Navigation vers StoryboardEditorScreen
```

**Code :**
```dart
Navigator.of(context).pushNamed('/smart-whiteboard-editor');
```

---

## RÉSUMÉ VISUEL

```
UI (smart_whiteboard_input_screen.dart:40-83)
↓
SmartWhiteboardProvider.createProject() (smart_whiteboard_provider.dart:78-104)
↓
SmartWhiteboardService.createProject() (smart_whiteboard_service.dart:17-37)
↓
RPC whiteboard_create_project (SQL)
↓
SmartWhiteboardProvider.generateStoryboard() (smart_whiteboard_provider.dart:106-166)
↓
Edge Function whiteboard-generate-storyboard (index.ts:315-515)
↓
OpenRouter API (callWithCascade:30-63)
↓
Parser TS (JSON.parse + validateStoryboard:402-439)
↓
Réponse Supabase (jsonResponse:496-506)
↓
Parser Flutter (smart_whiteboard_provider.dart:153-162)
↓
Navigation (smart_whiteboard_input_screen.dart:82)
```
