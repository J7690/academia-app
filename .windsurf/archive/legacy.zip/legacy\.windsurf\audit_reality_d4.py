import requests
import json

url = "https://thevdfcwlcqzdoybfvgs.supabase.co/rest/v1/rpc/admin_execute_sql"
headers = {
    "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRoZXZkZmN3bGNxemRveWJmdmdzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MzA1NjU2MCwiZXhwIjoyMDc4NjMyNTYwfQ.U0xz7oHnUISnxzAG8ehm_gRzoOlQPucj61i2f-1FjgM",
    "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRoZXZkZmN3bGNxemRveWJmdmdzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MzA1NjU2MCwiZXhwIjoyMDc4NjMyNTYwfQ.U0xz7oHnUISnxzAG8ehm_gRzoOlQPucj61i2f-1FjgM",
    "Content-Type": "application/json",
}

print("=" * 80)
print("AUDIT DE RÉALITÉ - PHASE D.4")
print("=" * 80)

results = {}

# 1. Edge Function whiteboard-generate-storyboard
print("\n1. Vérification Edge Function whiteboard-generate-storyboard...")
try:
    # Essayer d'appeler l'Edge Function
    ef_url = "https://thevdfcwlcqzdoybfvgs.supabase.co/functions/v1/whiteboard-generate-storyboard"
    resp = requests.post(ef_url, headers=headers, json={}, timeout=10)
    if resp.status_code == 401 or resp.status_code == 400:
        # L'Edge Function existe mais l'authentification a échoué (normal)
        results['edge_function'] = {'exists': True, 'status': 'exists', 'note': 'Edge Function exists (auth required)'}
        print("  ✅ Edge Function exists")
    elif resp.status_code == 404:
        results['edge_function'] = {'exists': False, 'status': 'not_found'}
        print("  ❌ Edge Function not found")
    else:
        results['edge_function'] = {'exists': True, 'status': 'unknown', 'code': resp.status_code}
        print(f"  ⚠️ Edge Function status: {resp.status_code}")
except Exception as e:
    results['edge_function'] = {'exists': False, 'error': str(e)}
    print(f"  ❌ Error: {e}")

# 2. Table whiteboard_projects
print("\n2. Vérification Table whiteboard_projects...")
sql = """
SELECT EXISTS (
  SELECT FROM information_schema.tables 
  WHERE table_schema = 'app' 
  AND table_name = 'whiteboard_projects'
);
"""
resp = requests.post(url, headers=headers, json={"p_sql": sql}, timeout=30)
if resp.status_code == 200:
    data = resp.json()
    exists = data.get('data', [[False]])[0][0]
    results['table_whiteboard_projects'] = {'exists': exists}
    print(f"  {'✅' if exists else '❌'} Table whiteboard_projects: {exists}")
else:
    results['table_whiteboard_projects'] = {'exists': False, 'error': resp.text}
    print(f"  ❌ Error: {resp.text}")

# 3. Table whiteboard_renders
print("\n3. Vérification Table whiteboard_renders...")
sql = """
SELECT EXISTS (
  SELECT FROM information_schema.tables 
  WHERE table_schema = 'app' 
  AND table_name = 'whiteboard_renders'
);
"""
resp = requests.post(url, headers=headers, json={"p_sql": sql}, timeout=30)
if resp.status_code == 200:
    data = resp.json()
    exists = data.get('data', [[False]])[0][0]
    results['table_whiteboard_renders'] = {'exists': exists}
    print(f"  {'✅' if exists else '❌'} Table whiteboard_renders: {exists}")
else:
    results['table_whiteboard_renders'] = {'exists': False, 'error': resp.text}
    print(f"  ❌ Error: {resp.text}")

# 4. Buckets whiteboard-renders
print("\n4. Vérification Bucket whiteboard-renders...")
sql = """
SELECT EXISTS (
  SELECT FROM storage.buckets 
  WHERE name = 'whiteboard-renders'
);
"""
resp = requests.post(url, headers=headers, json={"p_sql": sql}, timeout=30)
if resp.status_code == 200:
    data = resp.json()
    exists = data.get('data', [[False]])[0][0]
    results['bucket_whiteboard_renders'] = {'exists': exists}
    print(f"  {'✅' if exists else '❌'} Bucket whiteboard-renders: {exists}")
else:
    results['bucket_whiteboard_renders'] = {'exists': False, 'error': resp.text}
    print(f"  ❌ Error: {resp.text}")

# 5. Buckets whiteboard-narrations
print("\n5. Vérification Bucket whiteboard-narrations...")
sql = """
SELECT EXISTS (
  SELECT FROM storage.buckets 
  WHERE name = 'whiteboard-narrations'
);
"""
resp = requests.post(url, headers=headers, json={"p_sql": sql}, timeout=30)
if resp.status_code == 200:
    data = resp.json()
    exists = data.get('data', [[False]])[0][0]
    results['bucket_whiteboard_narrations'] = {'exists': exists}
    print(f"  {'✅' if exists else '❌'} Bucket whiteboard-narrations: {exists}")
else:
    results['bucket_whiteboard_narrations'] = {'exists': False, 'error': resp.text}
    print(f"  ❌ Error: {resp.text}")

# 6. RPCs whiteboard
print("\n6. Vérification RPCs whiteboard...")
sql = """
SELECT routine_name
FROM information_schema.routines
WHERE routine_schema = 'app'
AND routine_name LIKE 'whiteboard_%'
ORDER BY routine_name;
"""
resp = requests.post(url, headers=headers, json={"p_sql": sql}, timeout=30)
if resp.status_code == 200:
    data = resp.json()
    rpcs = data.get('data', [])
    results['rpcs_whiteboard'] = {'exists': len(rpcs) > 0, 'rpcs': rpcs}
    print(f"  {'✅' if rpcs else '❌'} RPCs whiteboard: {len(rpcs)} found")
    for rpc in rpcs:
        print(f"    - {rpc[0]}")
else:
    results['rpcs_whiteboard'] = {'exists': False, 'error': resp.text}
    print(f"  ❌ Error: {resp.text}")

# 7. RPCs app_whiteboard
print("\n7. Vérification RPCs app_whiteboard...")
sql = """
SELECT routine_name
FROM information_schema.routines
WHERE routine_schema = 'app'
AND routine_name LIKE 'app_whiteboard_%'
ORDER BY routine_name;
"""
resp = requests.post(url, headers=headers, json={"p_sql": sql}, timeout=30)
if resp.status_code == 200:
    data = resp.json()
    rpcs = data.get('data', [])
    results['rpcs_app_whiteboard'] = {'exists': len(rpcs) > 0, 'rpcs': rpcs}
    print(f"  {'✅' if rpcs else '❌'} RPCs app_whiteboard: {len(rpcs)} found")
    for rpc in rpcs:
        print(f"    - {rpc[0]}")
else:
    results['rpcs_app_whiteboard'] = {'exists': False, 'error': resp.text}
    print(f"  ❌ Error: {resp.text}")

# 8. Worker Kamatera
print("\n8. Vérification Worker Kamatera...")
# Note: Kamatera est externe, on ne peut pas vérifier directement
# On vérifie si les RPCs Kamatera existent
sql = """
SELECT routine_name
FROM information_schema.routines
WHERE routine_schema = 'app'
AND routine_name LIKE '%kamatera%'
ORDER BY routine_name;
"""
resp = requests.post(url, headers=headers, json={"p_sql": sql}, timeout=30)
if resp.status_code == 200:
    data = resp.json()
    rpcs = data.get('data', [])
    results['worker_kamatera'] = {'exists': len(rpcs) > 0, 'rpcs': rpcs, 'note': 'External worker, RPCs checked'}
    print(f"  {'⚠️' if rpcs else '❌'} Worker Kamatera: {len(rpcs)} RPCs found (external)")
    for rpc in rpcs:
        print(f"    - {rpc[0]}")
else:
    results['worker_kamatera'] = {'exists': False, 'error': resp.text}
    print(f"  ❌ Error: {resp.text}")

# 9. Renderer
print("\n9. Vérification Renderer...")
# Vérifier si les tables de rendu existent
sql = """
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'app'
AND (table_name LIKE '%render%' OR table_name LIKE '%video%')
ORDER BY table_name;
"""
resp = requests.post(url, headers=headers, json={"p_sql": sql}, timeout=30)
if resp.status_code == 200:
    data = resp.json()
    tables = data.get('data', [])
    results['renderer'] = {'exists': len(tables) > 0, 'tables': tables}
    print(f"  {'✅' if tables else '❌'} Renderer: {len(tables)} tables found")
    for table in tables:
        print(f"    - {table[0]}")
else:
    results['renderer'] = {'exists': False, 'error': resp.text}
    print(f"  ❌ Error: {resp.text}")

# Sauvegarder les résultats
with open('audit_reality_d4_results.json', 'w') as f:
    json.dump(results, f, indent=2)

print("\n" + "=" * 80)
print("RÉSULTATS SAUVEGARDÉS DANS audit_reality_d4_results.json")
print("=" * 80)

# Résumé
print("\nRÉSUMÉ:")
print(f"  Edge Function: {'✅' if results.get('edge_function', {}).get('exists') else '❌'}")
print(f"  Table whiteboard_projects: {'✅' if results.get('table_whiteboard_projects', {}).get('exists') else '❌'}")
print(f"  Table whiteboard_renders: {'✅' if results.get('table_whiteboard_renders', {}).get('exists') else '❌'}")
print(f"  Bucket whiteboard-renders: {'✅' if results.get('bucket_whiteboard_renders', {}).get('exists') else '❌'}")
print(f"  Bucket whiteboard-narrations: {'✅' if results.get('bucket_whiteboard_narrations', {}).get('exists') else '❌'}")
print(f"  RPCs whiteboard: {'✅' if results.get('rpcs_whiteboard', {}).get('exists') else '❌'}")
print(f"  RPCs app_whiteboard: {'✅' if results.get('rpcs_app_whiteboard', {}).get('exists') else '❌'}")
print(f"  Worker Kamatera: {'⚠️' if results.get('worker_kamatera', {}).get('exists') else '❌'}")
print(f"  Renderer: {'✅' if results.get('renderer', {}).get('exists') else '❌'}")
