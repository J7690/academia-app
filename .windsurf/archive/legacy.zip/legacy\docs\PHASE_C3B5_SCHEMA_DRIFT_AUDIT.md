# PHASE C.3B.5 – SCHEMA DRIFT AUDIT

**Date** : 23 Juin 2026  
**Phase** : C.3B.5 – Schema Drift Audit  
**Mode** : AUDIT SEULEMENT  
**Objectif** : Déterminer l'ensemble des écarts entre l'architecture Smart Whiteboard validée et la base réelle

---

## DIRECTIVE

**AUCUNE MODIFICATION**  
**AUCUNE CORRECTION**  
**AUCUNE MIGRATION**

---

## PARTIE 1 – DATA CONTRACT VS BASE RÉELLE

### 1.1 WhiteboardProject

| Champ | Data Contract | Migration Officielle | Base Réelle (inférée) | Écart |
|-------|---------------|----------------------|----------------------|-------|
| id | UUID | UUID | UUID | ✅ Aucun |
| student_id | UUID | UUID | UUID | ✅ Aucun |
| subject | String | String | String | ✅ Aucun |
| status | draft\|completed | draft\|completed | draft\|completed | ✅ Aucun |
| created_at | ISO8601 | TIMESTAMPTZ | TIMESTAMPTZ | ✅ Aucun |
| updated_at | ISO8601 | TIMESTAMPTZ | TIMESTAMPTZ | ✅ Aucun |
| renderer_id | scientific\|notebook | scientific\|notebook | scientific\|notebook | ✅ Aucun |
| theme_id | scientific\|notebook | scientific\|notebook | scientific\|notebook | ✅ Aucun |
| narration_mode | none\|tts\|user_recording | none\|tts\|user_recording | none\|tts\|user_recording | ✅ Aucun |
| storyboard | JSONB | JSONB | JSONB | ✅ Aucun |

**Conclusion** : ✅ **CONFORME** - Aucun écart détecté

---

### 1.2 RenderJob

| Champ | Data Contract | Migration Officielle | Base Réelle (inférée) | Écart |
|-------|---------------|----------------------|----------------------|-------|
| id | UUID | UUID | UUID | ✅ Aucun |
| project_id | UUID | UUID | UUID | ✅ Aucun |
| status | queued\|processing\|done\|failed | queued\|processing\|done\|failed | **processing\|failed** | ❌ **CRITIQUE** |
| video_url | String | String | String | ✅ Aucun |
| duration_ms | Integer | Integer | Integer | ✅ Aucun |
| error_message | String | String | String | ✅ Aucun |
| progress | Integer | Integer | Integer | ✅ Aucun |
| created_at | ISO8601 | TIMESTAMPTZ | TIMESTAMPTZ | ✅ Aucun |
| completed_at | ISO8601 | TIMESTAMPTZ | TIMESTAMPTZ | ✅ Aucun |
| export_settings | JSON | ❌ Non spécifié | ❌ Absent | ⚠️ **MAJEUR** |
| started_at | ❌ Non spécifié | ❌ Absent | ❌ Absent | ⚠️ **MAJEUR** (utilisé par RPCs C.3B.1) |

**Conclusion** : ❌ **NON CONFORME** - Écarts critiques et majeurs détectés

---

### 1.3 ExportSettings

| Champ | Data Contract | Migration Officielle | Base Réelle (inférée) | Écart |
|-------|---------------|----------------------|----------------------|-------|
| format | mp4 | ❌ Non spécifié | ❌ Absent | ❌ **CRITIQUE** |
| resolution | 1080x1920 | ❌ Non spécifié | ❌ Absent | ❌ **CRITIQUE** |
| frame_rate | 30 | ❌ Non spécifié | ❌ Absent | ❌ **CRITIQUE** |
| video_codec | h264 | ❌ Non spécifié | ❌ Absent | ❌ **CRITIQUE** |
| audio_codec | aac | ❌ Non spécifié | ❌ Absent | ❌ **CRITIQUE** |

**Conclusion** : ❌ **NON CONFORME** - ExportSettings absent de la base

---

## PARTIE 2 – V1 FINAL SPEC VS BASE RÉELLE

### 2.1 Table `app.whiteboard_projects`

| Aspect | V1 Final Spec | Migration Officielle | Base Réelle (inférée) | Écart |
|--------|---------------|----------------------|----------------------|-------|
| Colonnes | 10 colonnes | 10 colonnes | 10 colonnes | ✅ Aucun |
| `status` CHECK | IN ('draft', 'completed') | IN ('draft', 'completed') | IN ('draft', 'completed') | ✅ Aucun |
| `renderer_id` CHECK | IN ('scientific', 'notebook') | IN ('scientific', 'notebook') | IN ('scientific', 'notebook') | ✅ Aucun |
| `theme_id` CHECK | IN ('scientific', 'notebook') | IN ('scientific', 'notebook') | IN ('scientific', 'notebook') | ✅ Aucun |
| `narration_mode` CHECK | IN ('none', 'tts', 'user') | IN ('none', 'tts', 'user_recording') | IN ('none', 'tts', 'user_recording') | ⚠️ **MAJEUR** |

**Conclusion** : ⚠️ **PARTIELLEMENT CONFORME** - Écart mineur sur `narration_mode`

---

### 2.2 Table `app.whiteboard_renders`

| Aspect | V1 Final Spec | Migration Officielle | Base Réelle (inférée) | Écart |
|--------|---------------|----------------------|----------------------|-------|
| Colonnes | 8 colonnes | 9 colonnes | 9 colonnes | ⚠️ **MAJEUR** |
| `status` CHECK | IN ('queued', 'processing', 'done', 'failed') | IN ('queued', 'processing', 'done', 'failed') | **IN ('processing', 'failed')** | ❌ **CRITIQUE** |
| `progress` | Non spécifié | INTEGER CHECK >= 0 AND <= 100 | INTEGER CHECK >= 0 AND <= 100 | ⚠️ **MAJEUR** |
| `started_at` | Non spécifié | ❌ Absent | ❌ Absent | ⚠️ **MAJEUR** (utilisé par RPCs C.3B.1) |
| `completed_at` | Spécifié | Spécifié | Spécifié | ✅ Aucun |
| `export_settings` | Spécifié (JSONB) | ❌ Absent | ❌ Absent | ❌ **CRITIQUE** |

**Conclusion** : ❌ **NON CONFORME** - Écarts critiques et majeurs détectés

---

## PARTIE 3 – AUDIT `app.whiteboard_projects`

### 3.1 Colonnes

| Colonne | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|---------|-------------------|-------------------|-------|----------|
| id | UUID | UUID | ✅ Aucun | - |
| student_id | UUID | UUID | ✅ Aucun | - |
| subject | TEXT | TEXT | ✅ Aucun | - |
| status | TEXT | TEXT | ✅ Aucun | - |
| created_at | TIMESTAMPTZ | TIMESTAMPTZ | ✅ Aucun | - |
| updated_at | TIMESTAMPTZ | TIMESTAMPTZ | ✅ Aucun | - |
| renderer_id | TEXT | TEXT | ✅ Aucun | - |
| theme_id | TEXT | TEXT | ✅ Aucun | - |
| narration_mode | TEXT | TEXT | ✅ Aucun | - |
| storyboard_json | JSONB | JSONB | ✅ Aucun | - |

**Conclusion** : ✅ **CONFORME** - Toutes les colonnes sont présentes

---

### 3.2 Contraintes

| Contrainte | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|-----------|-------------------|-------------------|-------|----------|
| PK (id) | ✅ | ✅ | ✅ Aucun | - |
| FK (student_id) | ✅ | ✅ | ✅ Aucun | - |
| CHECK (status) | IN ('draft', 'completed') | IN ('draft', 'completed') | ✅ Aucun | - |
| CHECK (renderer_id) | IN ('scientific', 'notebook') | IN ('scientific', 'notebook') | ✅ Aucun | - |
| CHECK (theme_id) | IN ('scientific', 'notebook') | IN ('scientific', 'notebook') | ✅ Aucun | - |
| CHECK (narration_mode) | IN ('none', 'tts', 'user') | IN ('none', 'tts', 'user_recording') | ⚠️ 'user' vs 'user_recording' | **MAJEUR** |

**Conclusion** : ⚠️ **PARTIELLEMENT CONFORME** - Écart mineur sur `narration_mode`

---

### 3.3 Indexes

| Index | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|-------|-------------------|-------------------|-------|----------|
| idx_whiteboard_projects_id | ✅ | ✅ | ✅ Aucun | - |
| idx_whiteboard_projects_student_id | ✅ | ✅ | ✅ Aucun | - |
| idx_whiteboard_projects_status | ✅ | ✅ | ✅ Aucun | - |
| idx_whiteboard_projects_created_at | ✅ | ✅ | ✅ Aucun | - |
| idx_whiteboard_projects_storyboard_json (GIN) | ✅ | ✅ | ✅ Aucun | - |

**Conclusion** : ✅ **CONFORME** - Tous les indexes sont présents

---

### 3.4 Triggers

| Trigger | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|---------|-------------------|-------------------|-------|----------|
| trigger_update_whiteboard_projects_updated_at | ✅ | ✅ | ✅ Aucun | - |

**Conclusion** : ✅ **CONFORME** - Trigger présent

---

### 3.5 Defaults

| Colonne | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|---------|-------------------|-------------------|-------|----------|
| id | gen_random_uuid() | gen_random_uuid() | ✅ Aucun | - |
| created_at | NOW() | NOW() | ✅ Aucun | - |
| updated_at | NOW() | NOW() | ✅ Aucun | - |

**Conclusion** : ✅ **CONFORME** - Tous les defaults sont présents

---

### 3.6 Policies RLS

| Policy | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|--------|-------------------|-------------------|-------|----------|
| Students can view own projects | ✅ | ✅ | ✅ Aucun | - |
| Students can create own projects | ✅ | ✅ | ✅ Aucun | - |
| Students can update own projects | ✅ | ✅ | ✅ Aucun | - |
| Students can delete own projects | ✅ | ✅ | ✅ Aucun | - |

**Conclusion** : ✅ **CONFORME** - Toutes les policies sont présentes

---

## PARTIE 4 – AUDIT `app.whiteboard_renders`

### 4.1 Colonnes

| Colonne | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|---------|-------------------|-------------------|-------|----------|
| id | UUID | UUID | ✅ Aucun | - |
| project_id | UUID | UUID | ✅ Aucun | - |
| status | TEXT | TEXT | ✅ Aucun | - |
| video_url | TEXT | TEXT | ✅ Aucun | - |
| duration_ms | INTEGER | INTEGER | ✅ Aucun | - |
| error_message | TEXT | TEXT | ✅ Aucun | - |
| progress | ❌ Non spécifié | INTEGER | ⚠️ Présent non spécifié | **MAJEUR** |
| created_at | TIMESTAMPTZ | TIMESTAMPTZ | ✅ Aucun | - |
| completed_at | TIMESTAMPTZ | TIMESTAMPTZ | ✅ Aucun | - |
| export_settings | JSONB | ❌ Absent | ❌ Absent | **CRITIQUE** |
| started_at | ❌ Non spécifié | ❌ Absent | ❌ Absent | **MAJEUR** (utilisé par RPCs C.3B.1) |

**Conclusion** : ❌ **NON CONFORME** - Écarts critiques et majeurs détectés

---

### 4.2 Contraintes

| Contrainte | Attendue (V1 Spec) | Réelle (Migration) | Réelle (Base) | Écart | Sévérité |
|-----------|-------------------|-------------------|--------------|-------|----------|
| PK (id) | ✅ | ✅ | ✅ | ✅ Aucun | - |
| FK (project_id) | ✅ | ✅ | ✅ | ✅ Aucun | - |
| CHECK (status) | IN ('queued', 'processing', 'done', 'failed') | IN ('queued', 'processing', 'done', 'failed') | **IN ('processing', 'failed')** | ❌ **CRITIQUE** | **CRITIQUE** |
| CHECK (progress) | ❌ Non spécifié | IN (0, 100) | IN (0, 100) | ⚠️ Présent non spécifié | **MAJEUR** |

**Conclusion** : ❌ **NON CONFORME** - Écart critique sur le CHECK status

---

### 4.3 Indexes

| Index | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|-------|-------------------|-------------------|-------|----------|
| idx_whiteboard_renders_id | ✅ | ✅ | ✅ Aucun | - |
| idx_whiteboard_renders_project_id | ✅ | ✅ | ✅ Aucun | - |
| idx_whiteboard_renders_status | ✅ | ✅ | ✅ Aucun | - |
| idx_whiteboard_renders_created_at | ✅ | ✅ | ✅ Aucun | - |

**Conclusion** : ✅ **CONFORME** - Tous les indexes sont présents

---

### 4.4 Triggers

| Trigger | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|---------|-------------------|-------------------|-------|----------|
| Aucun | ❌ Non spécifié | ❌ Absent | ✅ Aucun | - |

**Conclusion** : ✅ **CONFORME** - Aucun trigger spécifié

---

### 4.5 Defaults

| Colonne | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|---------|-------------------|-------------------|-------|----------|
| id | gen_random_uuid() | gen_random_uuid() | ✅ Aucun | - |
| created_at | NOW() | NOW() | ✅ Aucun | - |

**Conclusion** : ✅ **CONFORME** - Tous les defaults sont présents

---

### 4.6 Policies RLS

| Policy | Attendue (V1 Spec) | Réelle (Migration) | Écart | Sévérité |
|--------|-------------------|-------------------|-------|----------|
| Students can view own renders | ✅ | ✅ | ✅ Aucun | - |
| Students can create own renders | ✅ | ✅ | ✅ Aucun | - |

**Conclusion** : ✅ **CONFORME** - Toutes les policies sont présentes

---

## PARTIE 5 – AUDIT CONTRAINTES, FK, INDEXES, TRIGGERS, DEFAULTS, POLICIES RLS

### 5.1 Résumé

| Élément | `whiteboard_projects` | `whiteboard_renders` |
|---------|----------------------|---------------------|
| CHECK | ✅ Conforme | ❌ Critique (status) |
| FK | ✅ Conforme | ✅ Conforme |
| Indexes | ✅ Conforme | ✅ Conforme |
| Triggers | ✅ Conforme | ✅ Conforme |
| Defaults | ✅ Conforme | ✅ Conforme |
| Policies RLS | ✅ Conforme | ✅ Conforme |

**Conclusion** : ❌ **NON CONFORME** - Écart critique sur le CHECK status de `whiteboard_renders`

---

## PARTIE 6 – AUDIT RPCS WHITEBOARD

### 6.1 RPCs Spécifiées V1 (non créées)

| RPC | Schema | Statut | Écart | Sévérité |
|-----|--------|--------|-------|----------|
| `app_whiteboard_create_project` | app | ❌ Non créée | Non conforme | **CRITIQUE** |
| `app_whiteboard_update_project` | app | ❌ Non créée | Non conforme | **CRITIQUE** |
| `app_whiteboard_get_project` | app | ❌ Non créée | Non conforme | **CRITIQUE** |
| `app_whiteboard_list_projects` | app | ❌ Non créée | Non conforme | **CRITIQUE** |
| `app_whiteboard_delete_project` | app | ❌ Non créée | Non conforme | **CRITIQUE** |
| `app_whiteboard_create_render_job` | app | ❌ Non créée | Non conforme | **CRITIQUE** |
| `app_whiteboard_get_render_status` | app | ❌ Non créée | Non conforme | **CRITIQUE** |

**Conclusion** : ❌ **NON CONFORME** - 7 RPCs spécifiées non créées

---

### 6.2 RPCs Créées C.3B.1 (non spécifiées)

| RPC | Schema | Statut | Écart | Sévérité |
|-----|--------|--------|-------|----------|
| `public.whiteboard_fetch_queued_jobs` | public | ⚠️ Créée mais inutile | Non conforme | **MAJEUR** |
| `public.whiteboard_mark_processing` | public | ⚠️ Créée mais utilise `started_at` absent | Non conforme | **CRITIQUE** |
| `public.whiteboard_mark_done` | public | ⚠️ Créée mais utilise `completed_at` | Conforme | - |
| `public.whiteboard_mark_failed` | public | ⚠️ Créée mais utilise `completed_at` | Conforme | - |
| `public.whiteboard_get_any_student_id` | public | ⚠️ Créée pour test | Non conforme | **MINEUR** |

**Conclusion** : ❌ **NON CONFORME** - 5 RPCs créées non conformes à la spécification

---

### 6.3 Analyse détaillée

#### `public.whiteboard_fetch_queued_jobs`

**Problème** : Dépend de `status='queued'` qui est refusé par la contrainte CHECK  
**Impact** : Inutile tant que la contrainte n'est pas corrigée  
**Statut** : ❌ **INUTILE**

#### `public.whiteboard_mark_processing`

**Problème** : Utilise `started_at` qui n'existe pas dans la table  
**Impact** : Échouera à l'exécution  
**Statut** : ❌ **NON FONCTIONNEL**

#### `public.whiteboard_mark_done`

**Problème** : Aucun problème détecté  
**Impact** : Fonctionnel  
**Statut** : ✅ **FONCTIONNEL**

#### `public.whiteboard_mark_failed`

**Problème** : Aucun problème détecté  
**Impact** : Fonctionnel  
**Statut** : ✅ **FONCTIONNEL**

---

## PARTIE 7 – MATRICE COMPLÈTE DES ÉCARTS

### 7.1 Classification

| Écart | Table/Colonne/RPC | Type | Sévérité | Impact |
|-------|-------------------|------|----------|--------|
| CHECK status (queued/done refusés) | `whiteboard_renders.status` | Contrainte | **CRITIQUE** | Worker inutilisable |
| export_settings absent | `whiteboard_renders` | Colonne | **CRITIQUE** | ExportSettings non stocké |
| started_at absent | `whiteboard_renders` | Colonne | **MAJEUR** | RPC mark_processing échouera |
| progress présent non spécifié | `whiteboard_renders` | Colonne | **MAJEUR** | Écart spécification |
| narration_mode (user vs user_recording) | `whiteboard_projects.narration_mode` | Contrainte | **MAJEUR** | Écart spécification |
| 7 RPCs V1 non créées | RPCs | RPC | **CRITIQUE** | Flux Flutter impossible |
| 5 RPCs C.3B.1 non conformes | RPCs | RPC | **MAJEUR** | Écart architecture |
| whiteboard_fetch_queued_jobs inutile | RPC | RPC | **MAJEUR** | Worker inutilisable |
| whiteboard_mark_processing non fonctionnel | RPC | RPC | **CRITIQUE** | Worker échouera |

---

### 7.2 Résumé par sévérité

| Sévérité | Nombre | Écarts |
|----------|--------|--------|
| **CRITIQUE** | 5 | CHECK status, export_settings, 7 RPCs V1, whiteboard_mark_processing |
| **MAJEUR** | 4 | started_at, progress, narration_mode, 5 RPCs C.3B.1 |
| **MINEUR** | 1 | whiteboard_get_any_student_id |

---

## PARTIE 8 – PLAN DE REMISE EN CONFORMITÉ

### 8.1 Priorité CRITIQUE

#### Étape 1 : Corriger la contrainte CHECK status

```sql
ALTER TABLE app.whiteboard_renders DROP CONSTRAINT whiteboard_renders_status_check;

ALTER TABLE app.whiteboard_renders 
ADD CONSTRAINT whiteboard_renders_status_check 
CHECK (status IN ('queued', 'processing', 'done', 'failed'));
```

**Impact** : Permet l'insertion de jobs avec `status='queued'`

---

#### Étape 2 : Ajouter la colonne export_settings

```sql
ALTER TABLE app.whiteboard_renders ADD COLUMN export_settings JSONB;
```

**Impact** : Permet le stockage des ExportSettings

---

#### Étape 3 : Créer les 7 RPCs V1

**RPCs à créer** :
- `app_whiteboard_create_project`
- `app_whiteboard_update_project`
- `app_whiteboard_get_project`
- `app_whiteboard_list_projects`
- `app_whiteboard_delete_project`
- `app_whiteboard_create_render_job`
- `app_whiteboard_get_render_status`

**Impact** : Permet le flux Flutter complet

---

#### Étape 4 : Corriger whiteboard_mark_processing

**Option A** : Ajouter la colonne `started_at`
```sql
ALTER TABLE app.whiteboard_renders ADD COLUMN started_at TIMESTAMPTZ;
```

**Option B** : Supprimer la référence à `started_at` dans la RPC

**Impact** : Permet au worker de marquer les jobs comme processing

---

### 8.2 Priorité MAJEURE

#### Étape 5 : Ajouter la colonne started_at

```sql
ALTER TABLE app.whiteboard_renders ADD COLUMN started_at TIMESTAMPTZ;
```

**Impact** : Permet le suivi du début de traitement

---

#### Étape 6 : Harmoniser narration_mode

**Option A** : Modifier la contrainte pour accepter `'user'`
```sql
ALTER TABLE app.whiteboard_projects DROP CONSTRAINT whiteboard_projects_narration_mode_check;

ALTER TABLE app.whiteboard_projects 
ADD CONSTRAINT whiteboard_projects_narration_mode_check 
CHECK (narration_mode IN ('none', 'tts', 'user'));
```

**Option B** : Modifier la spécification V1 pour utiliser `'user_recording'`

**Impact** : Harmonise la spécification avec l'implémentation

---

#### Étape 7 : Décider de progress

**Option A** : Conserver `progress` et l'ajouter à la spécification V1

**Option B** : Supprimer `progress` de la table

**Impact** : Harmonise la spécification avec l'implémentation

---

#### Étape 8 : Supprimer ou renommer les RPCs C.3B.1

**Option A** : Supprimer les RPCs C.3B.1
```sql
DROP FUNCTION public.whiteboard_fetch_queued_jobs;
DROP FUNCTION public.whiteboard_mark_processing;
DROP FUNCTION public.whiteboard_mark_done;
DROP FUNCTION public.whiteboard_mark_failed;
DROP FUNCTION public.whiteboard_get_any_student_id;
```

**Option B** : Renommer les RPCs C.3B.1 pour éviter la confusion

**Impact** : Évite la confusion avec les RPCs V1

---

### 8.3 Priorité MINEURE

#### Étape 9 : Supprimer whiteboard_get_any_student_id

```sql
DROP FUNCTION public.whiteboard_get_any_student_id;
```

**Impact** : Nettoyage des RPCs de test

---

## CONCLUSION

### 8.4 Résumé

**Écarts totaux** : 10 (5 critiques, 4 majeurs, 1 mineur)

**Table `whiteboard_projects`** : ✅ **CONFORME** (écart mineur sur narration_mode)

**Table `whiteboard_renders`** : ❌ **NON CONFORME** (écarts critiques et majeurs)

**RPCs** : ❌ **NON CONFORME** (7 RPCs V1 manquantes, 5 RPCs C.3B.1 non conformes)

### 8.5 Impact

**Immédiat** :
- Worker inutilisable (CHECK status)
- Flux Flutter impossible (RPCs V1 manquantes)
- RPC mark_processing échouera (started_at absent)

**Futur** :
- ExportSettings non stocké
- Écart de spécification (narration_mode, progress)

### 8.6 Recommandation

**Exécuter le plan de remise en conformité dans l'ordre de priorité** :
1. Priorité CRITIQUE (Étapes 1-4)
2. Priorité MAJEURE (Étapes 5-8)
3. Priorité MINEURE (Étape 9)

---

**Fin du Schema Drift Audit**
