# WHITEBOARD DUPLICATE ANALYSIS

**Date**: 2026-06-26
**Méthode**: Comparaison Flutter ↔ pg_proc ↔ .windsurf
**Source PostgreSQL**: pg_proc (43 fonctions)

---

## RÈGLE DE DÉCISION

Pour chaque RPC Flutter, on compare:
1. **Nom** exact
2. **Schéma** (public uniquement pour PostgREST)
3. **Signature** exacte (types, ordre, valeurs par défaut)
4. **Appel Flutter** réel
5. **Définition** dans .windsurf

**Decision**:
- **KEEP** : Nom + schéma + signature correspondent exactement au contrat Flutter
- **DELETE** : Même nom mais schéma différent ou signature différente
- **CREATE** : Appelé par Flutter mais n'existe pas dans pg_proc avec la bonne signature

---

## 1. whiteboard_create_project

### Flutter attend

```dart
'whiteboard_create_project',
params: {
  'p_student_id': _supabase.auth.currentUser?.id,        // uuid
  'p_subject': subject,                                      // text
  'p_renderer_id': rendererId,                             // text
  'p_theme_id': themeId,                                   // text
  'p_narration_mode': narrationMode,                       // text
  'p_storyboard_json': storyboardJson ?? {},               // jsonb
}
```

**SIGNATURE ATTENDUE**:
```sql
(
  p_student_id uuid,
  p_subject text,
  p_renderer_id text,
  p_theme_id text,
  p_narration_mode text,
  p_storyboard_json jsonb
)
RETURNS jsonb
```

### Versions trouvées dans pg_proc

| Schéma | Fonction | Arguments | Statut |
|--------|----------|-----------|--------|
| app | app_whiteboard_create_project | p_student_id uuid, p_subject character varying, p_renderer_id character varying, p_theme_id character varying, p_narration_mode character varying, p_storyboard_json jsonb | DELETE |
| app | whiteboard_create_project | p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid | DELETE |
| app | whiteboard_create_project | p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb | DELETE |
| public | whiteboard_create_project | p_student_id uuid, p_subject character varying, p_renderer_id character varying, p_theme_id character varying, p_narration_mode character varying, p_storyboard_json jsonb | DELETE |
| public | whiteboard_create_project | p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid | DELETE |

### Fichiers .windsurf qui les créent

| Fichier | RPC définie | Statut |
|---------|-------------|--------|
| `sql/06_create_rpcs_editor.sql` | app.app_whiteboard_create_project | DELETE |
| `sql/07_create_public_wrapper_rpc.sql` | public.whiteboard_create_project (VARCHAR) | DELETE |
| `deploy_whiteboard_rpcs_via_execute_ddl.py` | public.whiteboard_create_project (VARCHAR) | DELETE |

### Décision

**RPC**: public.whiteboard_create_project

**Décision**: **CREATE** (aucune version conforme au contrat Flutter)

**Justification**:
- Aucune version existante n'a exactement la signature attendue.
- Les versions existantes utilisent `character varying` au lieu de `text`, ou placent `p_student_id` en dernier.
- Le schéma `app` n'est pas accessible via PostgREST.
- Toutes les versions existantes doivent être supprimées pour éviter PGRST203.

### Action

1. Supprimer toutes les versions existantes de `whiteboard_create_project` dans `app` et `public`
2. Créer une nouvelle version conforme dans `public`:

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_create_project(
  p_student_id uuid,
  p_subject text,
  p_renderer_id text,
  p_theme_id text,
  p_narration_mode text,
  p_storyboard_json jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_project_id uuid;
  v_result jsonb;
BEGIN
  INSERT INTO app.whiteboard_projects (
    student_id,
    subject,
    status,
    renderer_id,
    theme_id,
    narration_mode,
    storyboard_json
  ) VALUES (
    p_student_id,
    p_subject,
    'draft',
    p_renderer_id,
    p_theme_id,
    p_narration_mode,
    p_storyboard_json
  )
  RETURNING id INTO v_project_id;

  v_result := jsonb_build_object(
    'success', true,
    'project_id', v_project_id
  );

  RETURN v_result;
END;
$$;
```

---

## 2. whiteboard_get_project

### Flutter attend

```dart
'whiteboard_get_project',
params: {
  'p_project_id': projectId,    // uuid
}
```

**SIGNATURE ATTENDUE**:
```sql
(
  p_project_id uuid
)
RETURNS jsonb
```

### Versions trouvées dans pg_proc

| Schéma | Fonction | Arguments | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_get_project | p_project_id uuid | DELETE |
| app | whiteboard_get_project | p_project_id uuid, p_student_id uuid | DELETE |
| public | whiteboard_get_project | p_project_id uuid, p_student_id uuid | DELETE |

### Fichiers .windsurf qui les créent

| Fichier | RPC définie | Statut |
|---------|-------------|--------|
| `sql/06_create_rpcs_editor.sql` | app.whiteboard_get_project (1 param) | DELETE |
| `sql_changes/change_20260624_whiteboard_editor_rpcs.sql` | app.whiteboard_get_project (1 param) | DELETE |

### Décision

**RPC**: public.whiteboard_get_project

**Décision**: **CREATE**

**Justification**:
- Aucune version existante n'a exactement la signature attendue (1 paramètre uuid).
- Les versions publiques ajoutent `p_student_id` inutilement.
- Le schéma `app` n'est pas accessible via PostgREST.

### Action

1. Supprimer toutes les versions existantes de `whiteboard_get_project` dans `app` et `public`
2. Créer une nouvelle version conforme dans `public`:

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_get_project(
  p_project_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  project_record RECORD;
  result JSONB;
BEGIN
  SELECT 
    id,
    student_id,
    subject,
    status,
    created_at,
    updated_at,
    renderer_id,
    theme_id,
    narration_mode,
    storyboard_json
  INTO project_record
  FROM app.whiteboard_projects
  WHERE id = p_project_id
  AND student_id = auth.uid();
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Project not found');
  END IF;
  
  result = jsonb_build_object(
    'success', true,
    'project', to_jsonb(project_record)
  );
  
  RETURN result;
END;
$$;
```

---

## 3. whiteboard_update_project

### Flutter attend

```dart
'whiteboard_update_project',
params: {
  'p_project_id': projectId,          // uuid
  'p_subject': subject,                  // text?
  'p_status': status,                    // text?
  'p_renderer_id': rendererId,         // text?
  'p_theme_id': themeId,               // text?
  'p_narration_mode': narrationMode,    // text?
  'p_storyboard_json': storyboardJson,  // jsonb?
}
```

**SIGNATURE ATTENDUE**:
```sql
(
  p_project_id uuid,
  p_subject text DEFAULT NULL,
  p_status text DEFAULT NULL,
  p_renderer_id text DEFAULT NULL,
  p_theme_id text DEFAULT NULL,
  p_narration_mode text DEFAULT NULL,
  p_storyboard_json jsonb DEFAULT NULL
)
RETURNS jsonb
```

### Versions trouvées dans pg_proc

| Schéma | Fonction | Arguments | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_update_project | p_project_id uuid, p_subject character varying, p_status character varying, p_renderer_id character varying, p_theme_id character varying, p_narration_mode character varying, p_storyboard_json jsonb | DELETE |
| app | whiteboard_update_project | p_project_id uuid, p_subject text, p_status text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb | DELETE |
| app | whiteboard_update_project | p_project_id uuid, p_subject text, p_status text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid | DELETE |
| public | whiteboard_update_project | p_project_id uuid, p_subject text, p_status text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid | DELETE |

### Fichiers .windsurf qui les créent

| Fichier | RPC définie | Statut |
|---------|-------------|--------|
| `sql/06_create_rpcs_editor.sql` | app.whiteboard_update_project (VARCHAR ou TEXT) | DELETE |
| `sql_changes/change_20260624_whiteboard_editor_rpcs.sql` | app.whiteboard_update_project (VARCHAR ou TEXT) | DELETE |

### Décision

**RPC**: public.whiteboard_update_project

**Décision**: **CREATE**

**Justification**:
- Aucune version n'a exactement la signature attendue (7 paramètres avec NULL defaults).
- Les versions publiques ajoutent `p_student_id` en plus.
- Les versions app utilisent `character varying` ou n'ont pas de valeur par défaut explicite.

### Action

1. Supprimer toutes les versions existantes de `whiteboard_update_project` dans `app` et `public`
2. Créer une nouvelle version conforme dans `public`:

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_update_project(
  p_project_id uuid,
  p_subject text DEFAULT NULL,
  p_status text DEFAULT NULL,
  p_renderer_id text DEFAULT NULL,
  p_theme_id text DEFAULT NULL,
  p_narration_mode text DEFAULT NULL,
  p_storyboard_json jsonb DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  project_record RECORD;
  result JSONB;
BEGIN
  UPDATE app.whiteboard_projects
  SET 
    subject = COALESCE(p_subject, subject),
    status = COALESCE(p_status, status),
    renderer_id = COALESCE(p_renderer_id, renderer_id),
    theme_id = COALESCE(p_theme_id, theme_id),
    narration_mode = COALESCE(p_narration_mode, narration_mode),
    storyboard_json = COALESCE(p_storyboard_json, storyboard_json),
    updated_at = NOW()
  WHERE id = p_project_id
  AND student_id = auth.uid()
  RETURNING * INTO project_record;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Project not found');
  END IF;
  
  result = jsonb_build_object(
    'success', true,
    'project', to_jsonb(project_record)
  );
  
  RETURN result;
END;
$$;
```

---

## 4. whiteboard_list_projects

### Flutter attend

```dart
'whiteboard_list_projects',
params: {
  'p_status': status,    // text?
}
```

**SIGNATURE ATTENDUE**:
```sql
(
  p_status text DEFAULT NULL
)
RETURNS jsonb
```

### Versions trouvées dans pg_proc

| Schéma | Fonction | Arguments | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_list_projects | p_student_id uuid, p_status text | DELETE |
| app | whiteboard_list_projects | p_status text, p_student_id uuid | DELETE |
| app | whiteboard_list_projects | p_status text | DELETE |
| app | whiteboard_list_projects | p_status character varying | DELETE |
| public | whiteboard_list_projects | p_status character varying | DELETE |
| public | whiteboard_list_projects | p_status text, p_student_id uuid | DELETE |

### Fichiers .windsurf qui les créent

| Fichier | RPC définie | Statut |
|---------|-------------|--------|
| `sql/06_create_rpcs_editor.sql` | app.whiteboard_list_projects (p_status text) | DELETE |
| `sql/07_create_public_wrapper_rpc.sql` | public.whiteboard_list_projects (VARCHAR) | DELETE |

### Décision

**RPC**: public.whiteboard_list_projects

**Décision**: **CREATE**

**Justification**:
- Aucune version n'a exactement la signature attendue (1 paramètre `text DEFAULT NULL`).
- Les versions publiques existantes utilisent `character varying` ou ajoutent `p_student_id`.

### Action

1. Supprimer toutes les versions existantes de `whiteboard_list_projects` dans `app` et `public`
2. Créer une nouvelle version conforme dans `public`:

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_list_projects(
  p_status text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  projects JSONB;
  result JSONB;
BEGIN
  SELECT jsonb_agg(to_jsonb(t))
  INTO projects
  FROM (
    SELECT 
      id,
      student_id,
      subject,
      status,
      created_at,
      updated_at,
      renderer_id,
      theme_id,
      narration_mode
    FROM app.whiteboard_projects
    WHERE student_id = auth.uid()
    AND (p_status IS NULL OR status = p_status)
    ORDER BY created_at DESC
  ) t;
  
  result = jsonb_build_object(
    'success', true,
    'projects', COALESCE(projects, '[]'::jsonb)
  );
  
  RETURN result;
END;
$$;
```

---

## 5. whiteboard_delete_project

### Flutter attend

```dart
'whiteboard_delete_project',
params: {
  'p_project_id': projectId,    // uuid
}
```

**SIGNATURE ATTENDUE**:
```sql
(
  p_project_id uuid
)
RETURNS jsonb
```

### Versions trouvées dans pg_proc

| Schéma | Fonction | Arguments | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_delete_project | p_project_id uuid | DELETE |
| app | whiteboard_delete_project | p_project_id uuid, p_student_id uuid | DELETE |
| public | whiteboard_delete_project | p_project_id uuid, p_student_id uuid | DELETE |

### Fichiers .windsurf qui les créent

| Fichier | RPC définie | Statut |
|---------|-------------|--------|
| `sql/06_create_rpcs_editor.sql` | app.whiteboard_delete_project (1 param) | DELETE |
| `sql_changes/change_20260624_whiteboard_editor_rpcs.sql` | app.whiteboard_delete_project (1 param) | DELETE |

### Décision

**RPC**: public.whiteboard_delete_project

**Décision**: **CREATE**

**Justification**:
- Aucune version n'a exactement la signature attendue (1 paramètre uuid).
- Les versions publiques ajoutent `p_student_id`.

### Action

1. Supprimer toutes les versions existantes de `whiteboard_delete_project` dans `app` et `public`
2. Créer une nouvelle version conforme dans `public`:

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_delete_project(
  p_project_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result JSONB;
BEGIN
  DELETE FROM app.whiteboard_projects
  WHERE id = p_project_id
  AND student_id = auth.uid();
  
  result = jsonb_build_object(
    'success', true,
    'message', 'Project deleted'
  );
  
  RETURN result;
END;
$$;
```

---

## 6. whiteboard_create_render_job

### Flutter attend

```dart
'whiteboard_create_render_job',
params: {
  'p_project_id': projectId,    // uuid
}
```

**SIGNATURE ATTENDUE**:
```sql
(
  p_project_id uuid
)
RETURNS jsonb
```

### Versions trouvées dans pg_proc

| Schéma | Fonction | Arguments | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_create_render_job | p_project_id uuid, p_student_id uuid | DELETE |
| app | whiteboard_create_render_job | p_project_id uuid | DELETE |
| public | whiteboard_create_render_job | p_project_id uuid, p_student_id uuid | DELETE |

### Fichiers .windsurf qui les créent

| Fichier | RPC définie | Statut |
|---------|-------------|--------|
| Aucun fichier actuel ne définit cette RPC avec la bonne signature | - | CREATE |

### Décision

**RPC**: public.whiteboard_create_render_job

**Décision**: **CREATE**

**Justification**:
- Aucune version conforme n'existe dans `public`.
- La version avec `p_student_id` ne correspond pas au contrat Flutter.

### Action

Créer une nouvelle version dans `public`:

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_create_render_job(
  p_project_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_render_id uuid;
  v_project_exists boolean;
  v_result jsonb;
BEGIN
  -- Vérifier que le projet appartient à l'utilisateur
  SELECT EXISTS (
    SELECT 1 FROM app.whiteboard_projects
    WHERE id = p_project_id AND student_id = auth.uid()
  ) INTO v_project_exists;

  IF NOT v_project_exists THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Project not found or unauthorized'
    );
  END IF;

  INSERT INTO app.whiteboard_renders (
    project_id,
    status,
    progress
  ) VALUES (
    p_project_id,
    'queued',
    0
  )
  RETURNING id INTO v_render_id;

  v_result := jsonb_build_object(
    'success', true,
    'render_id', v_render_id
  );

  RETURN v_result;
END;
$$;
```

---

## 7. whiteboard_get_render_status

### Flutter attend

```dart
'whiteboard_get_render_status',
params: {
  'p_render_id': renderId,    // uuid
}
```

**SIGNATURE ATTENDUE**:
```sql
(
  p_render_id uuid
)
RETURNS jsonb
```

### Versions trouvées dans pg_proc

| Schéma | Fonction | Arguments | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_get_render_status | p_render_id uuid | DELETE |
| app | whiteboard_get_render_status | p_render_id uuid, p_student_id uuid | DELETE |
| public | whiteboard_get_render_status | p_render_id uuid, p_student_id uuid | DELETE |

### Fichiers .windsurf qui les créent

| Fichier | RPC définie | Statut |
|---------|-------------|--------|
| Aucun fichier actuel ne définit cette RPC avec la bonne signature | - | CREATE |

### Décision

**RPC**: public.whiteboard_get_render_status

**Décision**: **CREATE**

**Justification**:
- Aucune version conforme n'existe dans `public`.
- La version avec `p_student_id` ne correspond pas au contrat Flutter.

### Action

Créer une nouvelle version dans `public`:

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_get_render_status(
  p_render_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  render_record RECORD;
  result JSONB;
BEGIN
  SELECT 
    wr.id,
    wr.project_id,
    wr.status,
    wr.video_url,
    wr.duration_ms,
    wr.file_size_bytes,
    wr.created_at,
    wr.completed_at,
    wr.error_message,
    wr.progress
  INTO render_record
  FROM app.whiteboard_renders wr
  JOIN app.whiteboard_projects wp ON wr.project_id = wp.id
  WHERE wr.id = p_render_id
  AND wp.student_id = auth.uid();
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Render not found');
  END IF;
  
  result = jsonb_build_object(
    'success', true,
    'render', to_jsonb(render_record)
  );
  
  RETURN result;
END;
$$;
```

---

## 8. FONCTIONS WORKER (DÉJÀ CONFORMES)

### 8.1 whiteboard_fetch_queued_jobs

**Flutter attend**: NON (worker Python)

**Version pg_proc conforme**:
```sql
public.whiteboard_fetch_queued_jobs(p_limit integer DEFAULT 5)
RETURNS TABLE
```

**Décision**: KEEP

**Justification**: Version unique dans public, signature correcte, utilisée par le worker Python.

### 8.2 whiteboard_mark_processing

**Flutter attend**: NON

**Version pg_proc conforme**:
```sql
public.whiteboard_mark_processing(p_job_id uuid)
RETURNS void
```

**Décision**: KEEP

### 8.3 whiteboard_mark_done

**Flutter attend**: NON

**Version pg_proc conforme**:
```sql
public.whiteboard_mark_done(p_job_id uuid, p_video_url text, p_duration_ms integer)
RETURNS void
```

**Décision**: KEEP

### 8.4 whiteboard_mark_failed

**Flutter attend**: NON

**Version pg_proc conforme**:
```sql
public.whiteboard_mark_failed(p_job_id uuid, p_error_message text)
RETURNS void
```

**Décision**: KEEP

### 8.5 whiteboard_get_any_student_id

**Flutter attend**: NON

**Version pg_proc conforme**:
```sql
public.whiteboard_get_any_student_id()
RETURNS uuid
```

**Décision**: KEEP

---

## 9. FONCTIONS TRIGGER (DÉJÀ CONFORMES)

### 9.1 app.whiteboard_projects_updated_at

**Décision**: KEEP

**Justification**: Trigger unique pour updated_at sur whiteboard_projects.

### 9.2 app.whiteboard_ai_generations_updated_at

**Décision**: KEEP

**Justification**: Trigger pour updated_at sur whiteboard_ai_generations (table obsolète mais fonction inoffensive).

### 9.3 app.update_whiteboard_projects_updated_at

**Décision**: DELETE

**Justification**: Doublon de app.whiteboard_projects_updated_at. Même table, même rôle.

---

## RÉSUMÉ FINAL

### RPCs Flutter à créer (7)

| RPC | Schéma | Signature | Raison |
|-----|--------|-----------|--------|
| whiteboard_create_project | public | 6 paramètres | Aucune version conforme |
| whiteboard_get_project | public | 1 paramètre | Aucune version conforme |
| whiteboard_update_project | public | 7 paramètres | Aucune version conforme |
| whiteboard_list_projects | public | 1 paramètre optionnel | Aucune version conforme |
| whiteboard_delete_project | public | 1 paramètre | Aucune version conforme |
| whiteboard_create_render_job | public | 1 paramètre | Aucune version conforme |
| whiteboard_get_render_status | public | 1 paramètre | Aucune version conforme |

### RPCs à supprimer (36 environ)

Toutes les versions non conformes de ces 7 RPCs dans `app` et `public`, plus:
- `app.app_whiteboard_create_project`
- `app.app_whiteboard_fetch_queued_jobs`
- `app.app_whiteboard_mark_done`
- `app.app_whiteboard_mark_failed`
- `app.app_whiteboard_mark_processing`
- `app.whiteboard_fetch_queued_jobs`
- `app.whiteboard_mark_done`
- `app.whiteboard_mark_failed`
- `app.whiteboard_mark_processing`
- `app.update_whiteboard_projects_updated_at` (doublon trigger)

### RPCs à conserver (8)

| RPC | Schéma | Raison |
|-----|--------|--------|
| whiteboard_fetch_queued_jobs | public | Worker Python |
| whiteboard_mark_processing | public | Worker Python |
| whiteboard_mark_done | public | Worker Python |
| whiteboard_mark_failed | public | Worker Python |
| whiteboard_get_any_student_id | public | Worker Python |
| whiteboard_projects_updated_at | app | Trigger |
| whiteboard_ai_generations_updated_at | app | Trigger |

---

## PROCHAINES ÉTAPES

1. **VALIDATION** : Vérifier ce rapport avec le SQL Editor via pg_proc
2. **NETTOYAGE** : Exécuter le SQL de suppression des 36 fonctions non conformes
3. **CRÉATION** : Créer les 7 nouvelles RPCs conformes au contrat Flutter
4. **TEST** : Appeler chaque RPC depuis Flutter pour confirmer PGRST203 résolu
5. **DOCUMENTATION** : Mettre à jour `.windsurf/whiteboard_rpc_contract.md` et `.windsurf/whiteboard_rpc_wiring.md`

**RÈGLE RESPECTÉE**: Aucune RPC n'a été créée pendant cet audit. PostgreSQL = source de vérité.
