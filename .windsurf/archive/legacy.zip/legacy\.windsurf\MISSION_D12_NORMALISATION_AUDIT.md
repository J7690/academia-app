# MISSION D.12 – NORMALISATION DU MOTEUR D'AUDIT SUPABASE ET DES DOSSIERS .WINDSURF

**Date**: 2026-06-26
**Version app**: 1.0.6+11
**Méthodologie**: PostgreSQL = SOURCE DE VÉRITÉ UNIQUEMENT

---

## CONTEXTE

Les audits précédents ont généré des faux négatifs:
- "0 RPC whiteboard trouvées"
- Création de doublons
- Erreurs PGRST203
- Plusieurs signatures concurrentes

**Problème identifié**: Méthodologie d'audit fausse. Les scripts Python utilisant `admin_execute_sql` ne retournent pas les résultats SELECT. Seule une interrogation directe de PostgreSQL via SQL Editor est valide.

---

## PRINCIPES FONDAMENTAUX

### PostgreSQL = Source de vérité

Les scripts Python et les rapports Markdown ne sont que des assistants. La preuve finale doit toujours venir de:
- `pg_proc` pour les fonctions
- `pg_class` / `pg_stat_user_tables` pour les tables
- `pg_trigger` pour les triggers
- `pg_policies` pour les RLS policies

### Interdictions

- **INTERDIT** d'utiliser `information_schema.routines` comme preuve finale
- **INTERDIT** de conclure "0 RPC" sans interrogation pg_proc
- **INTERDIT** de créer une fonction si pg_proc montre déjà une fonction similaire
- **INTERDIT** de supprimer une fonction sans cartographie complète
- **INTERDIT** de modifier/créer/supprimer des RPCs pendant l'audit

---

## RÈGLE DE CRÉATION D'UNE RPC

Une RPC peut être créée UNIQUEMENT si **toutes** les conditions suivantes sont remplies:

1. **Elle n'existe pas dans pg_proc** avec le même nom, schéma et signature
2. **Elle n'existe pas dans .windsurf** avec une signature équivalente
3. **Flutter l'appelle réellement** dans un fichier `.dart` via `_supabase.rpc(...)` ou `supabase.rpc(...)`
4. **Aucune signature compatible** n'existe déjà dans le schéma `public`
5. **Elle doit être créée dans le schéma `public`** pour être accessible via PostgREST

### Processus de validation

```
Flutter appelle RPC X
        ↓
Vérifier pg_proc: RPC X existe-t-elle dans public?
        ↓
Si OUI: comparer signature exacte
        ↓
Si signature OK → KEEP
Si signature différente → DELETE + CREATE
Si non dans public → CREATE
        ↓
Documenter dans .windsurf/whiteboard_rpc_contract.md
```

---

## PREUVES OBLIGATOIRES

Chaque audit doit afficher et documenter:

| Élément | Obligatoire | Format |
|---------|-------------|--------|
| URL Supabase | Oui | `https://<project>.supabase.co` |
| Projet | Oui | Nom du projet |
| SQL exact exécuté | Oui | Requête copiée-collée |
| Nombre de lignes | Oui | Entier |
| Premières lignes | Oui | 5-10 lignes |
| Source | Oui | `pg_proc` / `pg_class` / `pg_trigger` / `pg_policies` |

### Modèle de preuve

```markdown
URL Supabase: https://thevdfcwlcqzdoybfvgs.supabase.co
Projet: thevdfcwlcqzdoybfvgs
SQL exact exécuté:
SELECT n.nspname, p.proname, pg_get_function_identity_arguments(p.oid)
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE p.proname ILIKE '%whiteboard%'
ORDER BY n.nspname, p.proname;

Nombre de lignes: 43
Premières lignes:
- app, app_whiteboard_create_project, p_student_id uuid, ...
- app, whiteboard_create_project, p_subject text, ...
- public, whiteboard_create_project, p_student_id uuid, ...

Source: pg_proc
```

---

## REQUÊTES DE VÉRIFICATION OBLIGATOIRES

### FONCTIONS

```sql
SELECT
    n.nspname,
    p.proname,
    pg_get_function_identity_arguments(p.oid)
FROM pg_proc p
JOIN pg_namespace n
ON n.oid = p.pronamespace
WHERE p.proname ILIKE '%whiteboard%'
ORDER BY
    n.nspname,
    p.proname;
```

### TABLES

```sql
SELECT
    schemaname,
    relname
FROM pg_stat_user_tables
WHERE relname ILIKE '%whiteboard%'
ORDER BY schemaname, relname;
```

### TRIGGERS

```sql
SELECT
    n.nspname,
    c.relname,
    t.tgname
FROM pg_trigger t
JOIN pg_class c
ON c.oid=t.tgrelid
JOIN pg_namespace n
ON n.oid=c.relnamespace
WHERE
NOT t.tgisinternal
AND (
    c.relname ILIKE '%whiteboard%'
    OR t.tgname ILIKE '%whiteboard%'
);
```

### POLICIES

```sql
SELECT
    schemaname,
    tablename,
    policyname
FROM pg_policies
WHERE tablename ILIKE '%whiteboard%';
```

---

## CARTOGRAPHIE FINALE UNIQUE

### FLUTTER → RPC ATTENDUES

| Fichier Flutter | RPC Appelée | Signature Attendue | Schéma Attendu |
|-----------------|-------------|---------------------|-----------------|
| smart_whiteboard_service.dart:24 | whiteboard_create_project | 6 paramètres | public |
| smart_whiteboard_service.dart:41 | whiteboard_get_project | 1 paramètre | public |
| smart_whiteboard_service.dart:61 | whiteboard_update_project | 7 paramètres | public |
| smart_whiteboard_service.dart:79 | whiteboard_list_projects | 1 paramètre optionnel | public |
| smart_whiteboard_service.dart:91 | whiteboard_delete_project | 1 paramètre | public |
| smart_whiteboard_render_service.dart:18 | whiteboard_create_render_job | 1 paramètre | public |
| smart_whiteboard_render_service.dart:30 | whiteboard_get_render_status | 1 paramètre | public |

### RPC EXISTANTES DANS PG_PROC (43 fonctions)

Voir: `.windsurf/whiteboard_real_inventory.md`

### FICHIERS .WINDSURF QUI LES CRÉENT

Voir: `.windsurf/whiteboard_source_inventory.md`

### DOUBLONS À SUPPRIMER

Voir: `.windsurf/whiteboard_duplicate_analysis.md`

**Résumé**:
- 35+ fonctions à supprimer (versions non conformes)
- 8 fonctions à conserver (5 worker + 3 triggers)
- 7 RPCs à créer dans public (versions conformes au contrat Flutter)
- 1 trigger à supprimer (doublon `app.update_whiteboard_projects_updated_at`)

---

## DOCUMENTS PRODUITS

| Fichier | Phase | Description |
|---------|-------|-------------|
| `.windsurf/whiteboard_source_inventory.md` | 1 | Inventaire des fichiers .windsurf et RPCs définies |
| `.windsurf/flutter_rpc_contracts.md` | 2 | Cartographie des appels Flutter → Supabase |
| `.windsurf/whiteboard_duplicate_analysis.md` | 4 | Analyse des doublons et décisions KEEP/DELETE/CREATE |
| `.windsurf/MISSION_D12_NORMALISATION_AUDIT.md` | 5-6 | Règles, preuves et synthèse finale |

---

## PROCHAINES ÉTAPES (NON EXÉCUTÉES)

1. **VALIDATION** : Exécuter les 4 requêtes SQL ci-dessus dans le SQL Editor Supabase
2. **NETTOYAGE** : Exécuter le SQL de suppression des doublons (basé sur whiteboard_duplicate_analysis.md)
3. **CRÉATION** : Créer les 7 RPCs conformes dans public
4. **TEST** : Vérifier que chaque appel Flutter fonctionne sans PGRST203
5. **MISE À JOUR** : Synchroniser les fichiers .windsurf après création

---

## RÈGLE FINALE

**Aucune hypothèse. Uniquement des preuves reproductibles.**

Toute création, suppression ou modification de RPC doit être justifiée par:
1. Un appel Flutter prouvé
2. Une interrogation pg_proc prouvée
3. Une comparaison de signature exacte
4. Un fichier .windsurf de référence
