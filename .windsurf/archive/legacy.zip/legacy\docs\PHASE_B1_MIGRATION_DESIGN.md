# PHASE B.1 – SUPABASE MIGRATION DESIGN

**Version** : 1.0  
**Date** : 23 Juin 2026  
**Mode** : LECTURE SEULE  
**Objectif** : Plan exact de migration avant exécution

---

## DIRECTIVE TECHNIQUE PERMANENTE

Toute validation concernant Supabase, Tables, Buckets, RPC, Edge Functions, Policies doit obligatoirement être réalisée via les RPC Python administrateurs présents dans `.windsurf`.

Aucune hypothèse autorisée.

---

## PARTIE 1 – MIGRATION SQL

### 1.1 Ordre exact de création

**Justification de l'ordre** :
1. Tables d'abord (structure de base)
2. Indexes ensuite (optimisation)
3. Contraintes ensuite (intégrité)
4. Policies ensuite (sécurité)
5. Buckets ensuite (stockage)
6. RPCs ensuite (logique métier)

**Ordre détaillé** :

#### Étape 1 : Création des tables

**1.1 Table whiteboard_projects**
```sql
CREATE TABLE app.whiteboard_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES app.students(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('draft', 'completed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  renderer_id TEXT NOT NULL CHECK (renderer_id IN ('scientific', 'notebook')),
  theme_id TEXT NOT NULL CHECK (theme_id IN ('scientific', 'notebook')),
  narration_mode TEXT NOT NULL CHECK (narration_mode IN ('none', 'tts', 'user_recording')),
  storyboard_json JSONB NOT NULL
);
```

**1.2 Table whiteboard_renders**
```sql
CREATE TABLE app.whiteboard_renders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES app.whiteboard_projects(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('queued', 'processing', 'done', 'failed')),
  video_url TEXT,
  duration_ms INTEGER,
  error_message TEXT,
  progress INTEGER CHECK (progress >= 0 AND progress <= 100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);
```

#### Étape 2 : Création des indexes

**2.1 Indexes whiteboard_projects**
```sql
CREATE INDEX idx_whiteboard_projects_id ON app.whiteboard_projects(id);
CREATE INDEX idx_whiteboard_projects_student_id ON app.whiteboard_projects(student_id);
CREATE INDEX idx_whiteboard_projects_status ON app.whiteboard_projects(status);
CREATE INDEX idx_whiteboard_projects_created_at ON app.whiteboard_projects(created_at);
CREATE INDEX idx_whiteboard_projects_storyboard_json ON app.whiteboard_projects USING GIN (storyboard_json);
```

**2.2 Indexes whiteboard_renders**
```sql
CREATE INDEX idx_whiteboard_renders_id ON app.whiteboard_renders(id);
CREATE INDEX idx_whiteboard_renders_project_id ON app.whiteboard_renders(project_id);
CREATE INDEX idx_whiteboard_renders_status ON app.whiteboard_renders(status);
CREATE INDEX idx_whiteboard_renders_created_at ON app.whiteboard_renders(created_at);
```

#### Étape 3 : Création des contraintes

**Note** : Les contraintes sont déjà incluses dans la création des tables (PRIMARY KEY, FOREIGN KEY, CHECK).

**Contraintes supplémentaires** :
```sql
-- Trigger pour updated_at automatique
CREATE OR REPLACE FUNCTION app.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_whiteboard_projects_updated_at
BEFORE UPDATE ON app.whiteboard_projects
FOR EACH ROW
EXECUTE FUNCTION app.update_updated_at_column();
```

#### Étape 4 : Création des policies

**4.1 Policies whiteboard_projects**
```sql
-- Lecture
CREATE POLICY "Students can read own projects"
ON app.whiteboard_projects FOR SELECT
USING (auth.uid() = student_id);

CREATE POLICY "Admins can read all projects"
ON app.whiteboard_projects FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM app.users
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Écriture
CREATE POLICY "Students can create own projects"
ON app.whiteboard_projects FOR INSERT
WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Admins can create projects"
ON app.whiteboard_projects FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM app.users
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Modification
CREATE POLICY "Students can update own projects"
ON app.whiteboard_projects FOR UPDATE
USING (auth.uid() = student_id);

CREATE POLICY "Admins can update all projects"
ON app.whiteboard_projects FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM app.users
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Suppression
CREATE POLICY "Students can delete own projects"
ON app.whiteboard_projects FOR DELETE
USING (auth.uid() = student_id);

CREATE POLICY "Admins can delete all projects"
ON app.whiteboard_projects FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM app.users
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Activer RLS
ALTER TABLE app.whiteboard_projects ENABLE ROW LEVEL SECURITY;
```

**4.2 Policies whiteboard_renders**
```sql
-- Lecture
CREATE POLICY "Students can read own renders"
ON app.whiteboard_renders FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM app.whiteboard_projects
    WHERE id = project_id AND student_id = auth.uid()
  )
);

CREATE POLICY "Admins can read all renders"
ON app.whiteboard_renders FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM app.users
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Écriture
CREATE POLICY "Students can create renders for own projects"
ON app.whiteboard_renders FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM app.whiteboard_projects
    WHERE id = project_id AND student_id = auth.uid()
  )
);

CREATE POLICY "Admins can create renders"
ON app.whiteboard_renders FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM app.users
    WHERE id = auth.uid() AND role = 'admin'
  )
);

CREATE POLICY "Service role can create renders"
ON app.whiteboard_renders FOR INSERT
TO service_role
WITH CHECK (true);

-- Modification
CREATE POLICY "Students can update own renders"
ON app.whiteboard_renders FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM app.whiteboard_projects
    WHERE id = project_id AND student_id = auth.uid()
  )
);

CREATE POLICY "Admins can update all renders"
ON app.whiteboard_renders FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM app.users
    WHERE id = auth.uid() AND role = 'admin'
  )
);

CREATE POLICY "Service role can update renders"
ON app.whiteboard_renders FOR UPDATE
TO service_role
USING (true);

-- Suppression
CREATE POLICY "Students can delete own renders"
ON app.whiteboard_renders FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM app.whiteboard_projects
    WHERE id = project_id AND student_id = auth.uid()
  )
);

CREATE POLICY "Admins can delete all renders"
ON app.whiteboard_renders FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM app.users
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Activer RLS
ALTER TABLE app.whiteboard_renders ENABLE ROW LEVEL SECURITY;
```

#### Étape 5 : Création des buckets

**5.1 Bucket whiteboard-narrations**
```sql
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('whiteboard-narrations', 'whiteboard-narrations', false, 10485760, ARRAY['audio/mpeg', 'audio/wav']);
```

**5.2 Bucket whiteboard-renders**
```sql
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('whiteboard-renders', 'whiteboard-renders', false, 524288000, ARRAY['video/mp4']);
```

#### Étape 6 : Création des RPCs

**6.1 RPC app_whiteboard_create_project**
```sql
CREATE OR REPLACE FUNCTION app.app_whiteboard_create_project(
  p_student_id UUID,
  p_subject TEXT,
  p_renderer_id TEXT,
  p_theme_id TEXT,
  p_narration_mode TEXT,
  p_storyboard_json JSONB
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_project_id UUID;
  v_project JSONB;
BEGIN
  -- Validation des paramètres
  IF p_renderer_id NOT IN ('scientific', 'notebook') THEN
    RAISE EXCEPTION 'Invalid renderer_id';
  END IF;
  
  IF p_theme_id NOT IN ('scientific', 'notebook') THEN
    RAISE EXCEPTION 'Invalid theme_id';
  END IF;
  
  IF p_narration_mode NOT IN ('none', 'tts', 'user_recording') THEN
    RAISE EXCEPTION 'Invalid narration_mode';
  END IF;
  
  -- Création du projet
  INSERT INTO app.whiteboard_projects (
    student_id,
    subject,
    status,
    renderer_id,
    theme_id,
    narration_mode,
    storyboard_json
  ) VALUES (
    p_student_id,
    p_subject,
    'draft',
    p_renderer_id,
    p_theme_id,
    p_narration_mode,
    p_storyboard_json
  ) RETURNING row_to_json(*) INTO v_project;
  
  RETURN v_project;
END;
$$;
```

**6.2 RPC app_whiteboard_update_project**
```sql
CREATE OR REPLACE FUNCTION app.app_whiteboard_update_project(
  p_project_id UUID,
  p_subject TEXT,
  p_status TEXT,
  p_renderer_id TEXT,
  p_theme_id TEXT,
  p_narration_mode TEXT,
  p_storyboard_json JSONB
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_project JSONB;
BEGIN
  -- Validation des paramètres
  IF p_status NOT IN ('draft', 'completed') THEN
    RAISE EXCEPTION 'Invalid status';
  END IF;
  
  IF p_renderer_id NOT IN ('scientific', 'notebook') THEN
    RAISE EXCEPTION 'Invalid renderer_id';
  END IF;
  
  IF p_theme_id NOT IN ('scientific', 'notebook') THEN
    RAISE EXCEPTION 'Invalid theme_id';
  END IF;
  
  IF p_narration_mode NOT IN ('none', 'tts', 'user_recording') THEN
    RAISE EXCEPTION 'Invalid narration_mode';
  END IF;
  
  -- Mise à jour du projet
  UPDATE app.whiteboard_projects
  SET
    subject = p_subject,
    status = p_status,
    renderer_id = p_renderer_id,
    theme_id = p_theme_id,
    narration_mode = p_narration_mode,
    storyboard_json = p_storyboard_json
  WHERE id = p_project_id
  RETURNING row_to_json(*) INTO v_project;
  
  RETURN v_project;
END;
$$;
```

**6.3 RPC app_whiteboard_get_project**
```sql
CREATE OR REPLACE FUNCTION app.app_whiteboard_get_project(
  p_project_id UUID
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_project JSONB;
BEGIN
  SELECT row_to_json(*)
  INTO v_project
  FROM app.whiteboard_projects
  WHERE id = p_project_id;
  
  RETURN v_project;
END;
$$;
```

**6.4 RPC app_whiteboard_list_projects**
```sql
CREATE OR REPLACE FUNCTION app.app_whiteboard_list_projects(
  p_student_id UUID,
  p_status TEXT DEFAULT NULL,
  p_limit INTEGER DEFAULT 50,
  p_offset INTEGER DEFAULT 0
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_projects JSONB;
BEGIN
  SELECT json_agg(row_to_json(*))
  INTO v_projects
  FROM app.whiteboard_projects
  WHERE student_id = p_student_id
    AND (p_status IS NULL OR status = p_status)
  ORDER BY created_at DESC
  LIMIT p_limit
  OFFSET p_offset;
  
  RETURN COALESCE(v_projects, '[]'::JSONB);
END;
$$;
```

**6.5 RPC app_whiteboard_delete_project**
```sql
CREATE OR REPLACE FUNCTION app.app_whiteboard_delete_project(
  p_project_id UUID
) RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM app.whiteboard_projects
  WHERE id = p_project_id;
  
  RETURN true;
EXCEPTION
  WHEN OTHERS THEN
    RETURN false;
END;
$$;
```

**6.6 RPC app_whiteboard_create_render_job**
```sql
CREATE OR REPLACE FUNCTION app.app_whiteboard_create_render_job(
  p_project_id UUID
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_render_job JSONB;
BEGIN
  INSERT INTO app.whiteboard_renders (
    project_id,
    status
  ) VALUES (
    p_project_id,
    'queued'
  ) RETURNING row_to_json(*) INTO v_render_job;
  
  RETURN v_render_job;
END;
$$;
```

**6.7 RPC app_whiteboard_get_render_status**
```sql
CREATE OR REPLACE FUNCTION app.app_whiteboard_get_render_status(
  p_render_job_id UUID
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_render_job JSONB;
BEGIN
  SELECT row_to_json(*)
  INTO v_render_job
  FROM app.whiteboard_renders
  WHERE id = p_render_job_id;
  
  RETURN v_render_job;
END;
$$;
```

---

## PARTIE 2 – ROLLBACK

### 2.1 Plan de rollback

**Ordre de suppression (inverse de création)** :

#### Étape 1 : Suppression des RPCs
```sql
DROP FUNCTION IF EXISTS app.app_whiteboard_get_render_status(UUID);
DROP FUNCTION IF EXISTS app.app_whiteboard_create_render_job(UUID);
DROP FUNCTION IF EXISTS app.app_whiteboard_delete_project(UUID);
DROP FUNCTION IF EXISTS app.app_whiteboard_list_projects(UUID, TEXT, INTEGER, INTEGER);
DROP FUNCTION IF EXISTS app.app_whiteboard_get_project(UUID);
DROP FUNCTION IF EXISTS app.app_whiteboard_update_project(UUID, TEXT, TEXT, TEXT, TEXT, TEXT, JSONB);
DROP FUNCTION IF EXISTS app.app_whiteboard_create_project(UUID, TEXT, TEXT, TEXT, TEXT, JSONB);
```

#### Étape 2 : Suppression des buckets
```sql
DELETE FROM storage.buckets WHERE id = 'whiteboard-renders';
DELETE FROM storage.buckets WHERE id = 'whiteboard-narrations';
```

#### Étape 3 : Suppression des policies
```sql
-- whiteboard_renders
DROP POLICY IF EXISTS "Students can delete own renders" ON app.whiteboard_renders;
DROP POLICY IF EXISTS "Admins can delete all renders" ON app.whiteboard_renders;
DROP POLICY IF EXISTS "Service role can update renders" ON app.whiteboard_renders;
DROP POLICY IF EXISTS "Admins can update all renders" ON app.whiteboard_renders;
DROP POLICY IF EXISTS "Students can update own renders" ON app.whiteboard_renders;
DROP POLICY IF EXISTS "Service role can create renders" ON app.whiteboard_renders;
DROP POLICY IF EXISTS "Admins can create renders" ON app.whiteboard_renders;
DROP POLICY IF EXISTS "Students can create renders for own projects" ON app.whiteboard_renders;
DROP POLICY IF EXISTS "Admins can read all renders" ON app.whiteboard_renders;
DROP POLICY IF EXISTS "Students can read own renders" ON app.whiteboard_renders;

-- whiteboard_projects
DROP POLICY IF EXISTS "Admins can delete all projects" ON app.whiteboard_projects;
DROP POLICY IF EXISTS "Students can delete own projects" ON app.whiteboard_projects;
DROP POLICY IF EXISTS "Admins can update all projects" ON app.whiteboard_projects;
DROP POLICY IF EXISTS "Students can update own projects" ON app.whiteboard_projects;
DROP POLICY IF EXISTS "Admins can create projects" ON app.whiteboard_projects;
DROP POLICY IF EXISTS "Students can create own projects" ON app.whiteboard_projects;
DROP POLICY IF EXISTS "Admins can read all projects" ON app.whiteboard_projects;
DROP POLICY IF EXISTS "Students can read own projects" ON app.whiteboard_projects;
```

#### Étape 4 : Suppression des triggers
```sql
DROP TRIGGER IF EXISTS trigger_update_whiteboard_projects_updated_at ON app.whiteboard_projects;
DROP FUNCTION IF EXISTS app.update_updated_at_column();
```

#### Étape 5 : Suppression des indexes
```sql
-- whiteboard_renders
DROP INDEX IF EXISTS idx_whiteboard_renders_created_at;
DROP INDEX IF EXISTS idx_whiteboard_renders_status;
DROP INDEX IF EXISTS idx_whiteboard_renders_project_id;
DROP INDEX IF EXISTS idx_whiteboard_renders_id;

-- whiteboard_projects
DROP INDEX IF EXISTS idx_whiteboard_projects_storyboard_json;
DROP INDEX IF EXISTS idx_whiteboard_projects_created_at;
DROP INDEX IF EXISTS idx_whiteboard_projects_status;
DROP INDEX IF EXISTS idx_whiteboard_projects_student_id;
DROP INDEX IF EXISTS idx_whiteboard_projects_id;
```

#### Étape 6 : Suppression des tables
```sql
DROP TABLE IF EXISTS app.whiteboard_renders;
DROP TABLE IF EXISTS app.whiteboard_projects;
```

### 2.2 Dépendances

**Dépendances de suppression** :
- RPCs → Tables
- Buckets → Aucune
- Policies → Tables
- Triggers → Tables
- Indexes → Tables
- Tables → Aucune

**Ordre de suppression justifié** :
1. RPCs (dépendent des tables)
2. Buckets (indépendants)
3. Policies (dépendent des tables)
4. Triggers (dépendent des tables)
5. Indexes (dépendent des tables)
6. Tables (dépendent de students)

---

## PARTIE 3 – IMPACT

### 3.1 Impact sur Supabase existant

| Composant | Impact | Justification |
|-----------|--------|---------------|
- Tables existantes | ❌ Aucun | Tables whiteboard_* nouvelles |
- Indexes existants | ❌ Aucun | Indexes whiteboard_* nouveaux |
- RPCs existants | ❌ Aucun | RPCs app_whiteboard_* nouveaux |
- Buckets existants | ❌ Aucun | Buckets whiteboard-* nouveaux |
- Policies existantes | ❌ Aucun | Policies whiteboard_* nouvelles |

### 3.2 Impact sur Challenge

| Composant | Impact | Justification |
|-----------|--------|---------------|
- Tables challenge_* | ❌ Aucun | Tables distinctes |
- RPCs challenge_* | ❌ Aucun | RPCs distincts |
- Buckets challenge-* | ❌ Aucun | Buckets distincts |
- Edge Functions challenge-* | ❌ Aucun | Edge Functions distinctes |

### 3.3 Impact sur Bobodo

| Composant | Impact | Justification |
|-----------|--------|---------------|
- RPCs bobodo | ❌ Aucun | RPCs distincts |
- Edge Functions bobodo | ❌ Aucun | Edge Functions distinctes |

### 3.4 Impact sur Storage

| Composant | Impact | Justification |
|-----------|--------|---------------|
- Buckets existants | ❌ Aucun | Buckets whiteboard-* nouveaux |
- Espace disque | ✅ Minimal | Taille Storyboard ~5-20 Ko, buckets vides initialement |

### 3.5 Conclusion

**Aucun impact sur l'existant** ✅

---

## PARTIE 4 – VALIDATION DES NOMS

### 4.1 Conventions du projet Academia

**Tables** :
- Préfixe : `{module}_`
- Snake_case : ✅
- Pluriel : ✅

**Colonnes** :
- Snake_case : ✅
- Suffixe `_id` pour les clés étrangères : ✅
- Suffixe `_at` pour les dates : ✅
- Suffixe `_json` pour les JSONB : ✅

**Indexes** :
- Préfixe : `idx_`
- Format : `idx_{table}_{column}` : ✅

**Buckets** :
- Préfixe : `{module}-`
- Kebab-case : ✅

**RPCs** :
- Préfixe : `app_{module}_`
- Snake_case : ✅
- Verbe au début : ✅

### 4.2 Validation des noms

**Tables** :
- whiteboard_projects ✅
- whiteboard_renders ✅

**Colonnes** :
- id ✅
- student_id ✅
- subject ✅
- status ✅
- created_at ✅
- updated_at ✅
- renderer_id ✅
- theme_id ✅
- narration_mode ✅
- storyboard_json ✅
- project_id ✅
- video_url ✅
- duration_ms ✅
- error_message ✅
- progress ✅
- completed_at ✅

**Indexes** :
- idx_whiteboard_projects_id ✅
- idx_whiteboard_projects_student_id ✅
- idx_whiteboard_projects_status ✅
- idx_whiteboard_projects_created_at ✅
- idx_whiteboard_projects_storyboard_json ✅
- idx_whiteboard_renders_id ✅
- idx_whiteboard_renders_project_id ✅
- idx_whiteboard_renders_status ✅
- idx_whiteboard_renders_created_at ✅

**Buckets** :
- whiteboard-narrations ✅
- whiteboard-renders ✅

**RPCs** :
- app_whiteboard_create_project ✅
- app_whiteboard_update_project ✅
- app_whiteboard_get_project ✅
- app_whiteboard_list_projects ✅
- app_whiteboard_delete_project ✅
- app_whiteboard_create_render_job ✅
- app_whiteboard_get_render_status ✅

### 4.3 Conclusion

**Tous les noms respectent les conventions du projet Academia** ✅

---

## PARTIE 5 – CHECKLIST D'EXÉCUTION

### 5.1 Avant migration

- [ ] Backup de la base de données
- [ ] Vérifier que les RPC administrateurs sont accessibles
- [ ] Vérifier que l'utilisateur a les droits administrateur
- [ ] Vérifier que la table students existe
- [ ] Vérifier que la table users existe
- [ ] Documenter l'état actuel de la base de données
- [ ] Préparer le script de rollback
- [ ] Notifier les autres développeurs

### 5.2 Pendant migration

- [ ] Exécuter la création des tables
- [ ] Vérifier que les tables sont créées
- [ ] Exécuter la création des indexes
- [ ] Vérifier que les indexes sont créés
- [ ] Exécuter la création des contraintes
- [ ] Vérifier que les contraintes sont créées
- [ ] Exécuter la création des policies
- [ ] Vérifier que les policies sont créées
- [ ] Exécuter la création des buckets
- [ ] Vérifier que les buckets sont créés
- [ ] Exécuter la création des RPCs
- [ ] Vérifier que les RPCs sont créés
- [ ] Documenter chaque étape

### 5.3 Après migration

- [ ] Exécuter les tests SQL
- [ ] Exécuter les tests RLS
- [ ] Exécuter les tests buckets
- [ ] Exécuter les tests RPC
- [ ] Vérifier que les tests passent
- [ ] Documenter les résultats
- [ ] Notifier les autres développeurs
- [ ] Mettre à jour la documentation

---

## PARTIE 6 – TESTS POST-MIGRATION

### 6.1 Tests SQL

**Test 1 : Création d'un projet**
```sql
INSERT INTO app.whiteboard_projects (
  student_id,
  subject,
  status,
  renderer_id,
  theme_id,
  narration_mode,
  storyboard_json
) VALUES (
  'test-student-id',
  'Test Subject',
  'draft',
  'scientific',
  'scientific',
  'none',
  '{"version": "1.0", "scenes": []}'::JSONB
);
```

**Test 2 : Lecture d'un projet**
```sql
SELECT * FROM app.whiteboard_projects WHERE student_id = 'test-student-id';
```

**Test 3 : Mise à jour d'un projet**
```sql
UPDATE app.whiteboard_projects SET status = 'completed' WHERE student_id = 'test-student-id';
```

**Test 4 : Suppression d'un projet**
```sql
DELETE FROM app.whiteboard_projects WHERE student_id = 'test-student-id';
```

### 6.2 Tests RLS

**Test 1 : Étudiant peut lire ses propres projets**
```sql
-- Simuler un étudiant
SET ROLE authenticated;
SELECT * FROM app.whiteboard_projects WHERE student_id = auth.uid();
```

**Test 2 : Étudiant ne peut pas lire les projets des autres**
```sql
-- Simuler un étudiant
SET ROLE authenticated;
SELECT * FROM app.whiteboard_projects WHERE student_id != auth.uid();
```

**Test 3 : Admin peut lire tous les projets**
```sql
-- Simuler un admin
SET ROLE authenticated;
SELECT * FROM app.whiteboard_projects;
```

### 6.3 Tests buckets

**Test 1 : Création d'un fichier dans whiteboard-narrations**
```sql
-- Via RPC administrateur
-- Vérifier que le bucket existe
SELECT * FROM storage.buckets WHERE id = 'whiteboard-narrations';
```

**Test 2 : Création d'un fichier dans whiteboard-renders**
```sql
-- Via RPC administrateur
-- Vérifier que le bucket existe
SELECT * FROM storage.buckets WHERE id = 'whiteboard-renders';
```

### 6.4 Tests RPC

**Test 1 : app_whiteboard_create_project**
```sql
SELECT app.app_whiteboard_create_project(
  'test-student-id',
  'Test Subject',
  'scientific',
  'scientific',
  'none',
  '{"version": "1.0", "scenes": []}'::JSONB
);
```

**Test 2 : app_whiteboard_get_project**
```sql
SELECT app.app_whiteboard_get_project('test-project-id');
```

**Test 3 : app_whiteboard_list_projects**
```sql
SELECT app.app_whiteboard_list_projects('test-student-id');
```

**Test 4 : app_whiteboard_create_render_job**
```sql
SELECT app.app_whiteboard_create_render_job('test-project-id');
```

**Test 5 : app_whiteboard_get_render_status**
```sql
SELECT app.app_whiteboard_get_render_status('test-render-job-id');
```

---

## PARTIE 7 – DÉCISION

### 7.1 Évaluation

| Critère | État | Justification |
|---------|------|---------------|
- Ordre de création | ✅ Défini | Tables → Indexes → Contraintes → Policies → Buckets → RPCs |
- Plan de rollback | ✅ Défini | Ordre inverse complet |
- Impact sur Supabase existant | ✅ Aucun | Tables, indexes, RPCs, buckets distincts |
- Impact sur Challenge | ✅ Aucun | Tables, RPCs, buckets distincts |
- Impact sur Bobodo | ✅ Aucun | RPCs, Edge Functions distincts |
- Impact sur Storage | ✅ Minimal | Buckets vides initialement |
- Validation des noms | ✅ Réussi | Respect des conventions Academia |
- Checklist d'exécution | ✅ Définie | Avant, pendant, après |
- Tests post-migration | ✅ Définis | SQL, RLS, buckets, RPC |

### 7.2 Décision

**PHASE B.2 (EXÉCUTION DES MIGRATIONS) AUTORISÉE** ✅

**Justification** :
- Ordre de création défini et justifié
- Plan de rollback complet défini
- Aucun impact sur l'existant
- Noms validés (conventions Academia)
- Checklist d'exécution définie
- Tests post-migration définis

---

## CONCLUSION

**Phase B.1 – Supabase Migration Design** : ✅ Terminée

**Prêt pour Phase B.2** : Exécution des migrations

**Prochaine étape** : Phase B.2 – Exécution des migrations via RPC administrateurs

---

**Fin du document**
