-- CLEANUP WHITEBOARD DUPLICATES
-- Date: 2026-06-26
-- Mission: D.13
-- Purpose: Supprimer les RPCs whiteboard en double selon pg_proc
--
-- RÉSULTAT DE L'AUDIT pg_proc (BEFORE):
-- - Nombre total de fonctions whiteboard trouvées: 44 (incluant fonction d'audit temporaire)
-- - Nombre de fonctions à conserver: 8 (5 worker + 3 triggers)
-- - Nombre de fonctions à supprimer: 36
--
-- RÈGLE: Supprimer toutes les fonctions non conformes au contrat Flutter,
--        sauf les 5 worker publics et les 3 triggers app.
--
-- INTERDICTION: Ne pas exécuter ce script sans avoir d'abord lu .windsurf,
--               comparé avec Flutter et validé via pg_proc.

-- ============================================================
-- 1. SUPPRESSION DES FONCTIONS D'AUDIT TEMPORAIRES
-- ============================================================
DROP FUNCTION IF EXISTS public._audit_whiteboard_functions();

-- ============================================================
-- 2. SUPPRESSION DES FONCTIONS APP (non accessibles via PostgREST)
-- ============================================================

-- Doublons préfixés app_ dans app
DROP FUNCTION IF EXISTS app.app_whiteboard_create_project(
    p_student_id uuid,
    p_subject character varying,
    p_renderer_id character varying,
    p_theme_id character varying,
    p_narration_mode character varying,
    p_storyboard_json jsonb
);
DROP FUNCTION IF EXISTS app.app_whiteboard_fetch_queued_jobs(p_limit integer);
DROP FUNCTION IF EXISTS app.app_whiteboard_mark_done(
    p_job_id uuid,
    p_video_url text,
    p_duration_ms integer
);
DROP FUNCTION IF EXISTS app.app_whiteboard_mark_failed(
    p_job_id uuid,
    p_error_message text
);
DROP FUNCTION IF EXISTS app.app_whiteboard_mark_processing(p_job_id uuid);

-- Trigger doublon
DROP FUNCTION IF EXISTS app.update_whiteboard_projects_updated_at();

-- Doublons whiteboard_create_project dans app
DROP FUNCTION IF EXISTS app.whiteboard_create_project(
    p_subject text,
    p_renderer_id text,
    p_theme_id text,
    p_narration_mode text,
    p_storyboard_json jsonb
);
DROP FUNCTION IF EXISTS app.whiteboard_create_project(
    p_subject text,
    p_renderer_id text,
    p_theme_id text,
    p_narration_mode text,
    p_storyboard_json jsonb,
    p_student_id uuid
);

-- Doublons whiteboard_create_render_job dans app
DROP FUNCTION IF EXISTS app.whiteboard_create_render_job(
    p_project_id uuid,
    p_student_id uuid
);
DROP FUNCTION IF EXISTS app.whiteboard_create_render_job(p_project_id uuid);

-- Doublons whiteboard_delete_project dans app
DROP FUNCTION IF EXISTS app.whiteboard_delete_project(
    p_project_id uuid,
    p_student_id uuid
);
DROP FUNCTION IF EXISTS app.whiteboard_delete_project(p_project_id uuid);

-- Doublon whiteboard_fetch_queued_jobs dans app
DROP FUNCTION IF EXISTS app.whiteboard_fetch_queued_jobs(p_limit integer);

-- Doublons whiteboard_get_project dans app
DROP FUNCTION IF EXISTS app.whiteboard_get_project(
    p_project_id uuid,
    p_student_id uuid
);
DROP FUNCTION IF EXISTS app.whiteboard_get_project(p_project_id uuid);

-- Doublons whiteboard_get_render_status dans app
DROP FUNCTION IF EXISTS app.whiteboard_get_render_status(p_render_id uuid);
DROP FUNCTION IF EXISTS app.whiteboard_get_render_status(
    p_render_id uuid,
    p_student_id uuid
);

-- Doublons whiteboard_list_projects dans app
DROP FUNCTION IF EXISTS app.whiteboard_list_projects(
    p_student_id uuid,
    p_status text
);
DROP FUNCTION IF EXISTS app.whiteboard_list_projects(
    p_status text,
    p_student_id uuid
);
DROP FUNCTION IF EXISTS app.whiteboard_list_projects(p_status text);
DROP FUNCTION IF EXISTS app.whiteboard_list_projects(p_status character varying);

-- Doublons worker dans app
DROP FUNCTION IF EXISTS app.whiteboard_mark_done(
    p_job_id uuid,
    p_video_url text,
    p_duration_ms integer
);
DROP FUNCTION IF EXISTS app.whiteboard_mark_failed(
    p_job_id uuid,
    p_error_message text
);
DROP FUNCTION IF EXISTS app.whiteboard_mark_processing(p_job_id uuid);

-- Doublons whiteboard_update_project dans app
DROP FUNCTION IF EXISTS app.whiteboard_update_project(
    p_project_id uuid,
    p_subject character varying,
    p_status character varying,
    p_renderer_id character varying,
    p_theme_id character varying,
    p_narration_mode character varying,
    p_storyboard_json jsonb
);
DROP FUNCTION IF EXISTS app.whiteboard_update_project(
    p_project_id uuid,
    p_subject text,
    p_status text,
    p_renderer_id text,
    p_theme_id text,
    p_narration_mode text,
    p_storyboard_json jsonb
);
DROP FUNCTION IF EXISTS app.whiteboard_update_project(
    p_project_id uuid,
    p_subject text,
    p_status text,
    p_renderer_id text,
    p_theme_id text,
    p_narration_mode text,
    p_storyboard_json jsonb,
    p_student_id uuid
);

-- ============================================================
-- 3. SUPPRESSION DES FONCTIONS PUBLIC NON CONFORMES
-- ============================================================

-- Doublons whiteboard_create_project dans public
DROP FUNCTION IF EXISTS public.whiteboard_create_project(
    p_subject text,
    p_renderer_id text,
    p_theme_id text,
    p_narration_mode text,
    p_storyboard_json jsonb,
    p_student_id uuid
);
DROP FUNCTION IF EXISTS public.whiteboard_create_project(
    p_student_id uuid,
    p_subject character varying,
    p_renderer_id character varying,
    p_theme_id character varying,
    p_narration_mode character varying,
    p_storyboard_json jsonb
);

-- Doublons whiteboard_create_render_job dans public
DROP FUNCTION IF EXISTS public.whiteboard_create_render_job(
    p_project_id uuid,
    p_student_id uuid
);

-- Doublons whiteboard_delete_project dans public
DROP FUNCTION IF EXISTS public.whiteboard_delete_project(
    p_project_id uuid,
    p_student_id uuid
);

-- Doublons whiteboard_get_project dans public
DROP FUNCTION IF EXISTS public.whiteboard_get_project(
    p_project_id uuid,
    p_student_id uuid
);

-- Doublons whiteboard_get_render_status dans public
DROP FUNCTION IF EXISTS public.whiteboard_get_render_status(
    p_render_id uuid,
    p_student_id uuid
);

-- Doublons whiteboard_list_projects dans public
DROP FUNCTION IF EXISTS public.whiteboard_list_projects(
    p_status text,
    p_student_id uuid
);
DROP FUNCTION IF EXISTS public.whiteboard_list_projects(p_status character varying);

-- Doublon whiteboard_update_project dans public
DROP FUNCTION IF EXISTS public.whiteboard_update_project(
    p_project_id uuid,
    p_subject text,
    p_status text,
    p_renderer_id text,
    p_theme_id text,
    p_narration_mode text,
    p_storyboard_json jsonb,
    p_student_id uuid
);

-- ============================================================
-- 4. FONCTIONS CONSERVÉES (ne pas supprimer)
-- ============================================================
-- public.whiteboard_fetch_queued_jobs(p_limit integer DEFAULT 5)
-- public.whiteboard_mark_processing(p_job_id uuid)
-- public.whiteboard_mark_done(p_job_id uuid, p_video_url text, p_duration_ms integer)
-- public.whiteboard_mark_failed(p_job_id uuid, p_error_message text)
-- public.whiteboard_get_any_student_id()
-- app.whiteboard_projects_updated_at()
-- app.whiteboard_ai_generations_updated_at()
-- app.whiteboard_renders_updated_at() [si existe]

-- ============================================================
-- 5. VÉRIFICATION POST-NETTOYAGE
-- ============================================================
-- Exécuter après ce script:
-- SELECT n.nspname, p.proname, pg_get_function_identity_arguments(p.oid)
-- FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
-- WHERE p.proname ILIKE '%whiteboard%'
-- ORDER BY n.nspname, p.proname;
