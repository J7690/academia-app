-- PHASE D.3A.3 – Smart Whiteboard Content Agent
-- Tables et RPCs pour le Content Agent

-- 1. Ajouter action code generate_storyboard dans ai_action_prices
INSERT INTO app.ai_action_prices (action_code, price_usd, price_credits, description, is_active)
VALUES ('generate_storyboard', 0.0015, 15, 'Génération Storyboard Smart Whiteboard', true)
ON CONFLICT (action_code) DO UPDATE SET
  price_usd = EXCLUDED.price_usd,
  price_credits = EXCLUDED.price_credits,
  description = EXCLUDED.description,
  is_active = EXCLUDED.is_active;

-- 2. Créer table whiteboard_ai_generations
CREATE TABLE IF NOT EXISTS app.whiteboard_ai_generations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  generation_type VARCHAR(50) NOT NULL DEFAULT 'storyboard',
  input_params JSONB NOT NULL,
  output_json JSONB NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'validated',
  model_used VARCHAR(100),
  tokens_input INTEGER DEFAULT 0,
  tokens_output INTEGER DEFAULT 0,
  cost_usd DECIMAL(10, 6) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_whiteboard_ai_generations_created_by ON app.whiteboard_ai_generations(created_by);
CREATE INDEX IF NOT EXISTS idx_whiteboard_ai_generations_status ON app.whiteboard_ai_generations(status);
CREATE INDEX IF NOT EXISTS idx_whiteboard_ai_generations_created_at ON app.whiteboard_ai_generations(created_at DESC);

-- 3. RPC app_whiteboard_create_project
CREATE OR REPLACE FUNCTION app.app_whiteboard_create_project(
  p_student_id UUID,
  p_subject VARCHAR,
  p_renderer_id VARCHAR,
  p_theme_id VARCHAR,
  p_narration_mode VARCHAR,
  p_storyboard_json JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_project_id UUID;
  v_result JSONB;
BEGIN
  -- Créer le projet avec le Storyboard
  INSERT INTO app.whiteboard_projects (
    student_id,
    subject,
    status,
    renderer_id,
    theme_id,
    narration_mode,
    storyboard
  ) VALUES (
    p_student_id,
    p_subject,
    'draft',
    p_renderer_id,
    p_theme_id,
    p_narration_mode,
    p_storyboard_json
  )
  RETURNING id INTO v_project_id;

  -- Retourner le résultat
  v_result := jsonb_build_object(
    'success', true,
    'project_id', v_project_id
  );

  RETURN v_result;
END;
$$;

-- 4. RLS pour whiteboard_ai_generations
ALTER TABLE app.whiteboard_ai_generations ENABLE ROW LEVEL SECURITY;

-- RLS: Les étudiants peuvent voir leurs propres générations
CREATE POLICY "Students can view own generations"
  ON app.whiteboard_ai_generations
  FOR SELECT
  USING (auth.uid() = created_by);

-- RLS: Les admins peuvent voir toutes les générations
CREATE POLICY "Admins can view all generations"
  ON app.whiteboard_ai_generations
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM app.admin_users
      WHERE user_id = auth.uid()
    )
  );

-- RLS: Insertion autorisée via service role (Edge Functions)
CREATE POLICY "Service role can insert generations"
  ON app.whiteboard_ai_generations
  FOR INSERT
  WITH CHECK (true);

-- 5. Trigger updated_at pour whiteboard_ai_generations
CREATE OR REPLACE FUNCTION app.whiteboard_ai_generations_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER whiteboard_ai_generations_updated_at_trigger
  BEFORE UPDATE ON app.whiteboard_ai_generations
  FOR EACH ROW
  EXECUTE FUNCTION app.whiteboard_ai_generations_updated_at();
