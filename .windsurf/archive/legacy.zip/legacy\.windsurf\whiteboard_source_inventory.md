# WHITEBOARD SOURCE INVENTORY

**Date**: 2026-06-26
**Dossier scruté**: `.windsurf/`
**Mots-clés**: whiteboard, rpc, create function, create or replace function, deploy, migration, ddl

---

## FICHIERS SQL - DÉFINITIONS DE RPCs WHITEBOARD

### 1. `.windsurf/sql/05_create_rpcs_worker.sql`

**CONTENU**: RPCs worker dans le schéma public

**RPC DÉFINIES**:
| Schéma | Fonction | Signature | Statut |
|--------|----------|-----------|--------|
| public | whiteboard_fetch_queued_jobs | (p_limit integer DEFAULT 5) RETURNS TABLE | KEEP |
| public | whiteboard_mark_processing | (p_job_id uuid) RETURNS void | KEEP |
| public | whiteboard_mark_done | (p_job_id uuid, p_video_url text, p_duration_ms integer) RETURNS void | KEEP |
| public | whiteboard_mark_failed | (p_job_id uuid, p_error_message text) RETURNS void | KEEP |
| public | whiteboard_get_any_student_id | () RETURNS uuid | KEEP |

---

### 2. `.windsurf/sql/06_create_rpcs_editor.sql`

**CONTENU**: RPCs editor dans le schéma app

**RPC DÉFINIES**:
| Schéma | Fonction | Signature | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_get_project | (p_project_id UUID) RETURNS JSONB | DELETE (doublon, app inaccessible) |
| app | whiteboard_update_project | (p_project_id UUID, p_subject VARCHAR DEFAULT NULL, ...) RETURNS JSONB | DELETE (doublon, app inaccessible) |
| app | whiteboard_list_projects | (p_status VARCHAR DEFAULT NULL) RETURNS JSONB | DELETE (doublon, app inaccessible) |
| app | whiteboard_delete_project | (p_project_id UUID) RETURNS JSONB | DELETE (doublon, app inaccessible) |
| app | app_whiteboard_create_project | (p_student_id UUID, p_subject VARCHAR, ...) RETURNS JSONB | DELETE (doublon, app inaccessible) |

---

### 3. `.windsurf/sql/07_create_public_wrapper_rpc.sql`

**CONTENU**: Wrappers publics pour appeler les RPCs app

**RPC DÉFINIES**:
| Schéma | Fonction | Signature | Statut |
|--------|----------|-----------|--------|
| public | whiteboard_create_project | (p_student_id UUID, p_subject VARCHAR, p_renderer_id VARCHAR, p_theme_id VARCHAR, p_narration_mode VARCHAR, p_storyboard_json JSONB) RETURNS JSONB | DELETE (signature non conforme au contrat Flutter) |
| public | whiteboard_list_projects | (p_status VARCHAR DEFAULT NULL) RETURNS JSONB | DELETE (signature non conforme au contrat Flutter) |

---

### 4. `.windsurf/sql_changes/change_20260623_whiteboard_worker_rpcs.sql`

**CONTENU**: RPCs worker dans le schéma public (copie de 05_create_rpcs_worker.sql)

**RPC DÉFINIES**:
| Schéma | Fonction | Signature | Statut |
|--------|----------|-----------|--------|
| public | whiteboard_fetch_queued_jobs | (p_limit integer DEFAULT 5) RETURNS TABLE | KEEP |
| public | whiteboard_mark_processing | (p_job_id uuid) RETURNS void | KEEP |
| public | whiteboard_mark_done | (p_job_id uuid, p_video_url text, p_duration_ms integer) RETURNS void | KEEP |
| public | whiteboard_mark_failed | (p_job_id uuid, p_error_message text) RETURNS void | KEEP |
| public | whiteboard_get_any_student_id | () RETURNS uuid | KEEP |

---

### 5. `.windsurf/sql_changes/change_20260624_whiteboard_editor_rpcs.sql`

**CONTENU**: RPCs editor dans le schéma app (copie de 06_create_rpcs_editor.sql)

**RPC DÉFINIES**:
| Schéma | Fonction | Signature | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_get_project | (p_project_id UUID) RETURNS JSONB | DELETE (doublon, app inaccessible) |
| app | whiteboard_update_project | (p_project_id UUID, p_subject VARCHAR DEFAULT NULL, ...) RETURNS JSONB | DELETE (doublon, app inaccessible) |
| app | whiteboard_list_projects | (p_status VARCHAR DEFAULT NULL) RETURNS JSONB | DELETE (doublon, app inaccessible) |
| app | whiteboard_delete_project | (p_project_id UUID) RETURNS JSONB | DELETE (doublon, app inaccessible) |

---

### 6. `.windsurf/sql_changes/change_20260624_whiteboard_tables_buckets.sql`

**CONTENU**: Tables, RLS et trigger pour whiteboard

**RPC DÉFINIES**:
| Schéma | Fonction | Signature | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_projects_updated_at | () RETURNS TRIGGER | KEEP (trigger) |

**TABLES**:
| Schéma | Table | Statut |
|--------|-------|--------|
| app | whiteboard_projects | KEEP |
| app | whiteboard_renders | KEEP |

---

### 7. `.windsurf/sql_changes/change_20260623_whiteboard_renders_structure.sql`

**CONTENU**: Structure de la table whiteboard_renders

**RPC DÉFINIES**: Aucune

**TABLES**:
| Schéma | Table | Statut |
|--------|-------|--------|
| app | whiteboard_renders | KEEP |

---

### 8. `.windsurf/sql/01_create_app_schema.sql`

**CONTENU**: Création du schéma app

**RPC DÉFINIES**: Aucune

---

### 9. `.windsurf/sql/02_create_whiteboard_tables.sql`

**CONTENU**: Création des tables whiteboard

**RPC DÉFINIES**: Aucune

**TABLES**:
| Schéma | Table | Statut |
|--------|-------|--------|
| app | whiteboard_projects | KEEP |
| app | whiteboard_renders | KEEP |
| app | whiteboard_ai_generations | KEEP (dans le code mais obsolète) |

---

### 10. `.windsurf/sql/03_create_rls_policies.sql`

**CONTENU**: RLS policies pour les tables whiteboard

**RPC DÉFINIES**: Aucune

---

### 11. `.windsurf/sql/04_create_triggers.sql`

**CONTENU**: Triggers updated_at

**RPC DÉFINIES**:
| Schéma | Fonction | Signature | Statut |
|--------|----------|-----------|--------|
| app | whiteboard_projects_updated_at | () RETURNS TRIGGER | KEEP |
| app | whiteboard_ai_generations_updated_at | () RETURNS TRIGGER | KEEP/IGNORE (table obsolète) |
| app | update_whiteboard_projects_updated_at | () RETURNS TRIGGER | DELETE (doublon de whiteboard_projects_updated_at) |

---

## FICHIERS PYTHON - DÉPLOIEMENT DES RPCs WHITEBOARD

### 12. `.windsurf/deploy_whiteboard_rpcs_via_execute_ddl.py`

**CONTENU**: Déploie les RPCs worker et publics via execute_ddl

**RPC DÉPLOYÉES**:
- public.whiteboard_fetch_queued_jobs
- public.whiteboard_mark_processing
- public.whiteboard_mark_done
- public.whiteboard_mark_failed
- public.whiteboard_get_any_student_id
- public.whiteboard_create_project (wrapper)
- public.whiteboard_list_projects (wrapper)
- app.whiteboard_get_project
- app.whiteboard_update_project
- app.whiteboard_list_projects
- app.whiteboard_delete_project
- app.app_whiteboard_create_project

**STATUT**: IGNORE (script de déploiement, ne pas exécuter avant nettoyage)

---

### 13. `.windsurf/deploy_whiteboard_editor_rpcs.py`

**CONTENU**: Déploie les RPCs editor via admin_execute_sql (fichier sql_changes/change_20260624_whiteboard_editor_rpcs.sql)

**RPC DÉPLOYÉES**:
- app.whiteboard_get_project
- app.whiteboard_update_project
- app.whiteboard_list_projects
- app.whiteboard_delete_project

**STATUT**: IGNORE (script de déploiement, ne pas exécuter avant nettoyage)

---

### 14. `.windsurf/phase_c3b1_deploy_whiteboard_rpcs.py`

**CONTENU**: Déploiement de RPCs whiteboard (phase C3B1)

**STATUT**: IGNORE (script de déploiement historique)

---

### 15. `.windsurf/phase_b5_create_rpcs.py` et variants (v2, v3, v4)

**CONTENU**: Scripts de création de RPCs historiques

**STATUT**: IGNORE (scripts historiques, à vérifier manuellement)

---

### 16. `.windsurf/deploy_whiteboard_tables_via_execute_ddl.py`

**CONTENU**: Déploiement des tables whiteboard

**STATUT**: IGNORE (script de déploiement, les tables existent déjà)

---

## FICHIERS DE RAPPORT ET AUDIT

### 17. `.windsurf/whiteboard_rpc_contract.md`

**CONTENU**: Contrat officiel des RPCs whiteboard

**STATUT**: KEEP (référence officielle)

**RPCs définies dans le contrat**:
- public.whiteboard_create_project
- public.whiteboard_get_project
- public.whiteboard_update_project
- public.whiteboard_list_projects
- public.whiteboard_delete_project
- public.whiteboard_create_render_job
- public.whiteboard_get_render_status
- public.whiteboard_fetch_queued_jobs
- public.whiteboard_mark_processing
- public.whiteboard_mark_done
- public.whiteboard_mark_failed
- public.whiteboard_get_any_student_id

---

### 18. `.windsurf/whiteboard_rpc_wiring.md`

**CONTENU**: Cartographie des appels Flutter → Supabase

**STATUT**: KEEP (référence officielle)

---

### 19. `.windsurf/whiteboard_real_inventory.md`

**CONTENU**: Inventaire réel des 43 fonctions dans pg_proc

**STATUT**: KEEP (preuve PostgreSQL)

---

### 20. `.windsurf/cleanup_whiteboard_duplicates.sql`

**CONTENU**: Ancien script de nettoyage (vide car audit avait trouvé 0 fonctions)

**STATUT**: IGNORE (obsolète, faux négatif)

---

### 21. `.windsurf/cleanup_whiteboard_duplicates_real.sql`

**CONTENU**: Script de nettoyage basé sur les 43 fonctions pg_proc

**STATUT**: KEEP (mais ne pas exécuter avant validation Flutter)

---

## SYNTHÈSE

### Fichiers KEEP (sources de vérité)
1. `.windsurf/whiteboard_rpc_contract.md` - Contrat officiel
2. `.windsurf/whiteboard_rpc_wiring.md` - Cartographie Flutter
3. `.windsurf/whiteboard_real_inventory.md` - Preuve pg_proc
4. `.windsurf/cleanup_whiteboard_duplicates_real.sql` - Script de nettoyage validé

### Fichiers IGNORE (déploiement ou obsolètes)
- Scripts Python de déploiement
- `cleanup_whiteboard_duplicates.sql` (faux négatif)
- Fichiers SQL app avec RPCs inaccessibles directement

### RPCs à conserver après nettoyage
| Schéma | Fonction | Source |
|--------|----------|--------|
| public | whiteboard_fetch_queued_jobs | sql/05_create_rpcs_worker.sql |
| public | whiteboard_mark_processing | sql/05_create_rpcs_worker.sql |
| public | whiteboard_mark_done | sql/05_create_rpcs_worker.sql |
| public | whiteboard_mark_failed | sql/05_create_rpcs_worker.sql |
| public | whiteboard_get_any_student_id | sql/05_create_rpcs_worker.sql |
| app | whiteboard_projects_updated_at | sql/04_create_triggers.sql |
| app | whiteboard_ai_generations_updated_at | sql/04_create_triggers.sql |
| app | update_whiteboard_projects_updated_at | sql/04_create_triggers.sql (DOUBLON) |

### RPCs à recréer conformément au contrat Flutter
| Schéma | Fonction | Source attendue |
|--------|----------|-----------------|
| public | whiteboard_create_project | whiteboard_rpc_contract.md |
| public | whiteboard_get_project | whiteboard_rpc_contract.md |
| public | whiteboard_update_project | whiteboard_rpc_contract.md |
| public | whiteboard_list_projects | whiteboard_rpc_contract.md |
| public | whiteboard_delete_project | whiteboard_rpc_contract.md |
| public | whiteboard_create_render_job | whiteboard_rpc_contract.md |
| public | whiteboard_get_render_status | whiteboard_rpc_contract.md |

---

**RÈGLE**: Aucune RPC ne peut être créée avant que cet inventaire soit validé et que pg_proc soit nettoyé.
