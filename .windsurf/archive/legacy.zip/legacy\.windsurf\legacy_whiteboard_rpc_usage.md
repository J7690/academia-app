# LEGACY WHITEBOARD RPC USAGE

**Date**: 2026-06-26
**Mission**: D.15.1
**Objectif**: Inventaire complet des occurrences de `app_whiteboard_` dans le projet

---

## RÉSUMÉ

- **Total d'occurrences**: 343
- **À remplacer (REPLACE)**: 110
- **À conserver (KEEP)**: 233

---

## OCCURRENCES À REMPLACER (REPLACE)

| # | Fichier | Ligne | Ancien nom | Nouveau nom | Contexte |
|---|---------|-------|------------|-------------|----------|
| 1 | `.windsurf\check_specific_rpcs.py` | 18 | `app_whiteboard_create_project` | `whiteboard_create_project` | `WHERE routine_name IN ('app_whiteboard_create_project', 'whiteboard_create_proje` |
| 2 | `.windsurf\check_tables_direct.py` | 13 | `app_whiteboard_projects` | `whiteboard_projects` | `resp = requests.get(f"{url}/rest/v1/app_whiteboard_projects?limit=1", headers=he` |
| 3 | `.windsurf\check_tables_direct.py` | 16 | `app_whiteboard_projects` | `whiteboard_projects` | `print("✅ Table whiteboard_projects existe (via app_whiteboard_projects)")` |
| 4 | `.windsurf\check_tables_direct.py` | 24 | `app_whiteboard_renders` | `whiteboard_renders` | `resp = requests.get(f"{url}/rest/v1/app_whiteboard_renders?limit=1", headers=hea` |
| 5 | `.windsurf\check_tables_direct.py` | 27 | `app_whiteboard_renders` | `whiteboard_renders` | `print("✅ Table whiteboard_renders existe (via app_whiteboard_renders)")` |
| 6 | `.windsurf\cleanup_whiteboard_duplicates.sql` | 27 | `app_whiteboard_create_project` | `whiteboard_create_project` | `DROP FUNCTION IF EXISTS app.app_whiteboard_create_project(` |
| 7 | `.windsurf\cleanup_whiteboard_duplicates.sql` | 35 | `app_whiteboard_fetch_queued_jobs` | `whiteboard_fetch_queued_jobs` | `DROP FUNCTION IF EXISTS app.app_whiteboard_fetch_queued_jobs(p_limit integer);` |
| 8 | `.windsurf\cleanup_whiteboard_duplicates.sql` | 36 | `app_whiteboard_mark_done` | `whiteboard_mark_done` | `DROP FUNCTION IF EXISTS app.app_whiteboard_mark_done(` |
| 9 | `.windsurf\cleanup_whiteboard_duplicates.sql` | 41 | `app_whiteboard_mark_failed` | `whiteboard_mark_failed` | `DROP FUNCTION IF EXISTS app.app_whiteboard_mark_failed(` |
| 10 | `.windsurf\cleanup_whiteboard_duplicates.sql` | 45 | `app_whiteboard_mark_processing` | `whiteboard_mark_processing` | `DROP FUNCTION IF EXISTS app.app_whiteboard_mark_processing(p_job_id uuid);` |
| 11 | `.windsurf\cleanup_whiteboard_duplicates_real.sql` | 27 | `app_whiteboard_create_project` | `whiteboard_create_project` | `DROP FUNCTION IF EXISTS app.app_whiteboard_create_project CASCADE;` |
| 12 | `.windsurf\cleanup_whiteboard_duplicates_real.sql` | 28 | `app_whiteboard_fetch_queued_jobs` | `whiteboard_fetch_queued_jobs` | `DROP FUNCTION IF EXISTS app.app_whiteboard_fetch_queued_jobs CASCADE;` |
| 13 | `.windsurf\cleanup_whiteboard_duplicates_real.sql` | 29 | `app_whiteboard_mark_done` | `whiteboard_mark_done` | `DROP FUNCTION IF EXISTS app.app_whiteboard_mark_done CASCADE;` |
| 14 | `.windsurf\cleanup_whiteboard_duplicates_real.sql` | 30 | `app_whiteboard_mark_failed` | `whiteboard_mark_failed` | `DROP FUNCTION IF EXISTS app.app_whiteboard_mark_failed CASCADE;` |
| 15 | `.windsurf\cleanup_whiteboard_duplicates_real.sql` | 31 | `app_whiteboard_mark_processing` | `whiteboard_mark_processing` | `DROP FUNCTION IF EXISTS app.app_whiteboard_mark_processing CASCADE;` |
| 16 | `.windsurf\create_public_whiteboard_create_project.py` | 33 | `app_whiteboard_create_project` | `whiteboard_create_project` | `RETURN app.app_whiteboard_create_project(` |
| 17 | `.windsurf\d15_1_inventory.py` | 16 | `app_whiteboard_create_project` | `whiteboard_create_project` | `"app_whiteboard_create_project": "whiteboard_create_project",` |
| 18 | `.windsurf\d15_1_inventory.py` | 17 | `app_whiteboard_get_project` | `whiteboard_get_project` | `"app_whiteboard_get_project": "whiteboard_get_project",` |
| 19 | `.windsurf\d15_1_inventory.py` | 18 | `app_whiteboard_update_project` | `whiteboard_update_project` | `"app_whiteboard_update_project": "whiteboard_update_project",` |
| 20 | `.windsurf\d15_1_inventory.py` | 19 | `app_whiteboard_list_projects` | `whiteboard_list_projects` | `"app_whiteboard_list_projects": "whiteboard_list_projects",` |
| 21 | `.windsurf\d15_1_inventory.py` | 20 | `app_whiteboard_delete_project` | `whiteboard_delete_project` | `"app_whiteboard_delete_project": "whiteboard_delete_project",` |
| 22 | `.windsurf\d15_1_inventory.py` | 21 | `app_whiteboard_create_render_job` | `whiteboard_create_render_job` | `"app_whiteboard_create_render_job": "whiteboard_create_render_job",` |
| 23 | `.windsurf\d15_1_inventory.py` | 22 | `app_whiteboard_get_render_status` | `whiteboard_get_render_status` | `"app_whiteboard_get_render_status": "whiteboard_get_render_status",` |
| 24 | `.windsurf\d15_1_inventory.py` | 23 | `app_whiteboard_fetch_queued_jobs` | `whiteboard_fetch_queued_jobs` | `"app_whiteboard_fetch_queued_jobs": "whiteboard_fetch_queued_jobs",` |
| 25 | `.windsurf\d15_1_inventory.py` | 24 | `app_whiteboard_mark_processing` | `whiteboard_mark_processing` | `"app_whiteboard_mark_processing": "whiteboard_mark_processing",` |
| 26 | `.windsurf\d15_1_inventory.py` | 25 | `app_whiteboard_mark_done` | `whiteboard_mark_done` | `"app_whiteboard_mark_done": "whiteboard_mark_done",` |
| 27 | `.windsurf\d15_1_inventory.py` | 26 | `app_whiteboard_mark_failed` | `whiteboard_mark_failed` | `"app_whiteboard_mark_failed": "whiteboard_mark_failed",` |
| 28 | `.windsurf\d15_1_inventory.py` | 27 | `app_whiteboard_get_any_student_id` | `whiteboard_get_any_student_id` | `"app_whiteboard_get_any_student_id": "whiteboard_get_any_student_id",` |
| 29 | `.windsurf\d15_verify_breakpoint.py` | 4 | `app_whiteboard_create_project` | `whiteboard_create_project` | `Vérifie que app_whiteboard_create_project n'existe plus dans pg_proc.` |
| 30 | `.windsurf\d15_verify_breakpoint.py` | 12 | `app_whiteboard_create_project` | `whiteboard_create_project` | `RPC_URL = f"{SUPABASE_URL}/rest/v1/rpc/_check_app_whiteboard_create_project"` |
| 31 | `.windsurf\d15_verify_breakpoint.py` | 30 | `app_whiteboard_create_project` | `whiteboard_create_project` | `CREATE OR REPLACE FUNCTION public._check_app_whiteboard_create_project()` |
| 32 | `.windsurf\d15_verify_breakpoint.py` | 45 | `app_whiteboard_create_project` | `whiteboard_create_project` | `WHERE p.proname = 'app_whiteboard_create_project'` |
| 33 | `.windsurf\d15_verify_breakpoint.py` | 53 | `app_whiteboard_create_project` | `whiteboard_create_project` | `ddl = "DROP FUNCTION IF EXISTS public._check_app_whiteboard_create_project();"` |
| 34 | `.windsurf\d15_verify_breakpoint.py` | 69 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("\nRecherche de app_whiteboard_create_project dans pg_proc...")` |
| 35 | `.windsurf\d15_verify_breakpoint.py` | 83 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print(f"\nNombre de fonctions app_whiteboard_create_project trouvées: {count}")` |
| 36 | `.windsurf\d15_verify_breakpoint.py` | 86 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("\n✅ CONFIRMATION: app_whiteboard_create_project n'existe PLUS dans pg_pro` |
| 37 | `.windsurf\d15_verify_breakpoint.py` | 90 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("\n⚠️ app_whiteboard_create_project existe encore.")` |
| 38 | `.windsurf\deploy_whiteboard_content_agent.py` | 63 | `app_whiteboard_create_project` | `whiteboard_create_project` | `# Étape 4: RPC app_whiteboard_create_project` |
| 39 | `.windsurf\deploy_whiteboard_content_agent.py` | 65 | `app_whiteboard_create_project` | `whiteboard_create_project` | `CREATE OR REPLACE FUNCTION app.app_whiteboard_create_project(` |
| 40 | `.windsurf\deploy_whiteboard_content_agent.py` | 109 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("\n4. Création RPC app_whiteboard_create_project...")` |
| 41 | `.windsurf\deploy_whiteboard_content_agent_v2.py` | 63 | `app_whiteboard_create_project` | `whiteboard_create_project` | `# Étape 4: RPC app_whiteboard_create_project` |
| 42 | `.windsurf\deploy_whiteboard_content_agent_v2.py` | 65 | `app_whiteboard_create_project` | `whiteboard_create_project` | `CREATE OR REPLACE FUNCTION app.app_whiteboard_create_project(` |
| 43 | `.windsurf\deploy_whiteboard_content_agent_v2.py` | 109 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("\n4. Création RPC app_whiteboard_create_project...")` |
| 44 | `.windsurf\deploy_whiteboard_rpcs_via_execute_ddl.py` | 270 | `app_whiteboard_create_project` | `whiteboard_create_project` | `# Étape 3 : Déployer la RPC app_whiteboard_create_project (si elle n'existe pas ` |
| 45 | `.windsurf\deploy_whiteboard_rpcs_via_execute_ddl.py` | 271 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("\n3. Déploiement de la RPC app_whiteboard_create_project...")` |
| 46 | `.windsurf\deploy_whiteboard_rpcs_via_execute_ddl.py` | 274 | `app_whiteboard_create_project` | `whiteboard_create_project` | `CREATE OR REPLACE FUNCTION app.app_whiteboard_create_project(` |
| 47 | `.windsurf\deploy_whiteboard_rpcs_via_execute_ddl.py` | 319 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print(f"  app_whiteboard_create_project : {result10}")` |
| 48 | `.windsurf\legacy_whiteboard_rpc_usage.md` | 37 | `app_whiteboard_create_project` | `whiteboard_create_project` | `\| 1 \| `supabase/functions/whiteboard-generate-storyboard/index.ts` \| 451 \| `` |
| 49 | `.windsurf\legacy_whiteboard_rpc_usage.md` | 43 | `app_whiteboard_create_project` | `whiteboard_create_project` | `const { data: projectData } = await supabase.rpc('app_whiteboard_create_project'` |
| 50 | `.windsurf\official_rpc_registry.md` | 69 | `app_whiteboard_create_project` | `whiteboard_create_project` | `\| 13 \| app_whiteboard_create_project \| app \| `(p_student_id uuid, p_subject ` |
| 51 | `.windsurf\test_create_project_response.py` | 12 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("TEST RPC app_whiteboard_create_project")` |
| 52 | `.windsurf\test_create_project_response.py` | 17 | `app_whiteboard_create_project` | `whiteboard_create_project` | `SELECT app.app_whiteboard_create_project(` |
| 53 | `.windsurf\test_rest_api_rpc.py` | 17 | `app_whiteboard_create_project` | `whiteboard_create_project` | `# Test 1: app_whiteboard_create_project` |
| 54 | `.windsurf\test_rest_api_rpc.py` | 18 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("\n1. Test POST /rest/v1/rpc/app_whiteboard_create_project")` |
| 55 | `.windsurf\test_rest_api_rpc.py` | 19 | `app_whiteboard_create_project` | `whiteboard_create_project` | `url1 = f"{base_url}/rest/v1/rpc/app_whiteboard_create_project"` |
| 56 | `.windsurf\test_rest_api_rpc.py` | 65 | `app_whiteboard_create_project` | `whiteboard_create_project` | `# Test 4: app.app_whiteboard_create_project` |
| 57 | `.windsurf\test_rest_api_rpc.py` | 66 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("\n4. Test POST /rest/v1/rpc/app.app_whiteboard_create_project")` |
| 58 | `.windsurf\test_rest_api_rpc.py` | 67 | `app_whiteboard_create_project` | `whiteboard_create_project` | `url4 = f"{base_url}/rest/v1/rpc/app.app_whiteboard_create_project"` |
| 59 | `.windsurf\test_rpc_call.py` | 3 | `app_whiteboard_create_project` | `whiteboard_create_project` | `url = "https://thevdfcwlcqzdoybfvgs.supabase.co/rest/v1/rpc/app_whiteboard_creat` |
| 60 | `.windsurf\test_rpc_call.py` | 10 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("Testing RPC call to app_whiteboard_create_project...")` |
| 61 | `.windsurf\test_rpc_names.py` | 36 | `app_whiteboard_create_project` | `whiteboard_create_project` | `# Vérifier spécifiquement app_whiteboard_create_project` |
| 62 | `.windsurf\test_rpc_names.py` | 38 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("VÉRIFICATION app_whiteboard_create_project")` |
| 63 | `.windsurf\test_rpc_names.py` | 47 | `app_whiteboard_create_project` | `whiteboard_create_project` | `WHERE routine_name = 'app_whiteboard_create_project';` |
| 64 | `.windsurf\test_whiteboard_modes.py` | 68 | `app_whiteboard_create_project` | `whiteboard_create_project` | `result = self.call_rpc("app_whiteboard_create_project", params)` |
| 65 | `.windsurf\test_whiteboard_modes.py` | 141 | `app_whiteboard_create_project` | `whiteboard_create_project` | `result = self.call_rpc("app_whiteboard_create_project", params)` |
| 66 | `.windsurf\test_whiteboard_modes.py` | 188 | `app_whiteboard_create_project` | `whiteboard_create_project` | `result = self.call_rpc("app_whiteboard_create_project", params)` |
| 67 | `.windsurf\test_whiteboard_modes.py` | 223 | `app_whiteboard_create_project` | `whiteboard_create_project` | `result = self.call_rpc("app_whiteboard_create_project", params)` |
| 68 | `.windsurf\test_whiteboard_rpc_direct.py` | 14 | `app_whiteboard_create_project` | `whiteboard_create_project` | `SELECT app.app_whiteboard_create_project(` |
| 69 | `.windsurf\verify_whiteboard_deployment.py` | 128 | `app_whiteboard_create_project` | `whiteboard_create_project` | `'app_whiteboard_create_project'` |
| 70 | `.windsurf\verify_whiteboard_rpcs.py` | 38 | `app_whiteboard_create_project` | `whiteboard_create_project` | `# Vérifier aussi app_whiteboard_create_project spécifiquement` |
| 71 | `.windsurf\verify_whiteboard_rpcs.py` | 39 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print("\n--- RPC app_whiteboard_create_project ---")` |
| 72 | `.windsurf\verify_whiteboard_rpcs.py` | 46 | `app_whiteboard_create_project` | `whiteboard_create_project` | `WHERE routine_name = 'app_whiteboard_create_project';` |
| 73 | `.windsurf\verify_whiteboard_rpcs.py` | 53 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print(f"✅ app_whiteboard_create_project trouvée:")` |
| 74 | `.windsurf\verify_whiteboard_rpcs.py` | 57 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print(f"✅ app_whiteboard_create_project trouvée (affected_rows)")` |
| 75 | `.windsurf\verify_whiteboard_rpcs.py` | 59 | `app_whiteboard_create_project` | `whiteboard_create_project` | `print(f"❌ app_whiteboard_create_project non trouvée")` |
| 76 | `.windsurf\whiteboard_duplicate_analysis.md` | 58 | `app_whiteboard_create_project` | `whiteboard_create_project` | `\| app \| app_whiteboard_create_project \| p_student_id uuid, p_subject characte` |
| 77 | `.windsurf\whiteboard_duplicate_analysis.md` | 68 | `app_whiteboard_create_project` | `whiteboard_create_project` | `\| `sql/06_create_rpcs_editor.sql` \| app.app_whiteboard_create_project \| DELET` |
| 78 | `.windsurf\whiteboard_duplicate_analysis.md` | 805 | `app_whiteboard_create_project` | `whiteboard_create_project` | `- `app.app_whiteboard_create_project`` |
| 79 | `.windsurf\whiteboard_duplicate_analysis.md` | 806 | `app_whiteboard_fetch_queued_jobs` | `whiteboard_fetch_queued_jobs` | `- `app.app_whiteboard_fetch_queued_jobs`` |
| 80 | `.windsurf\whiteboard_duplicate_analysis.md` | 807 | `app_whiteboard_mark_done` | `whiteboard_mark_done` | `- `app.app_whiteboard_mark_done`` |
| 81 | `.windsurf\whiteboard_duplicate_analysis.md` | 808 | `app_whiteboard_mark_failed` | `whiteboard_mark_failed` | `- `app.app_whiteboard_mark_failed`` |
| 82 | `.windsurf\whiteboard_duplicate_analysis.md` | 809 | `app_whiteboard_mark_processing` | `whiteboard_mark_processing` | `- `app.app_whiteboard_mark_processing`` |
| 83 | `.windsurf\sql\06_create_rpcs_editor.sql` | 142 | `app_whiteboard_create_project` | `whiteboard_create_project` | `-- app_whiteboard_create_project (app schema)` |
| 84 | `.windsurf\sql\06_create_rpcs_editor.sql` | 143 | `app_whiteboard_create_project` | `whiteboard_create_project` | `CREATE OR REPLACE FUNCTION app.app_whiteboard_create_project(` |
| 85 | `.windsurf\sql\07_create_public_wrapper_rpc.sql` | 1 | `app_whiteboard_create_project` | `whiteboard_create_project` | `-- RPC publique whiteboard_create_project (wrapper autour de app_whiteboard_crea` |
| 86 | `.windsurf\sql\07_create_public_wrapper_rpc.sql` | 17 | `app_whiteboard_create_project` | `whiteboard_create_project` | `RETURN app.app_whiteboard_create_project(` |
| 87 | `.windsurf\sql_changes\change_20260624_whiteboard_content_agent.sql` | 34 | `app_whiteboard_create_project` | `whiteboard_create_project` | `-- 3. RPC app_whiteboard_create_project` |
| 88 | `.windsurf\sql_changes\change_20260624_whiteboard_content_agent.sql` | 35 | `app_whiteboard_create_project` | `whiteboard_create_project` | `CREATE OR REPLACE FUNCTION app.app_whiteboard_create_project(` |
| 89 | `academia_app\.windsurf\verify_whiteboard_deployment.py` | 128 | `app_whiteboard_create_project` | `whiteboard_create_project` | `'app_whiteboard_create_project'` |
| 90 | `academia_app\.windsurf\sql\06_create_rpcs_editor.sql` | 142 | `app_whiteboard_create_project` | `whiteboard_create_project` | `-- app_whiteboard_create_project (app schema)` |
| 91 | `academia_app\.windsurf\sql\06_create_rpcs_editor.sql` | 143 | `app_whiteboard_create_project` | `whiteboard_create_project` | `CREATE OR REPLACE FUNCTION app.app_whiteboard_create_project(` |
| 92 | `academia_app\.windsurf\sql\07_create_public_wrapper_rpc.sql` | 1 | `app_whiteboard_create_project` | `whiteboard_create_project` | `-- RPC publique whiteboard_create_project (wrapper autour de app_whiteboard_crea` |
| 93 | `academia_app\.windsurf\sql\07_create_public_wrapper_rpc.sql` | 17 | `app_whiteboard_create_project` | `whiteboard_create_project` | `RETURN app.app_whiteboard_create_project(` |
| 94 | `docs\ACADEMIA_CONTRACT_REGISTRY.md` | 558 | `app_whiteboard_create_project` | `whiteboard_create_project` | `**Nom** : app_whiteboard_create_project` |
| 95 | `docs\ACADEMIA_PROJECT_STATE.md` | 50 | `app_whiteboard_create_project` | `whiteboard_create_project` | `- app.app_whiteboard_create_project : ✅ Créée` |
| 96 | `docs\ACADEMIA_TRUTH_MATRIX.md` | 42 | `app_whiteboard_create_project` | `whiteboard_create_project` | `\| app.app_whiteboard_create_project \| A \| RPC créée via execute_ddl, confirmé` |
| 97 | `docs\SMART_WHITEBOARD_ARCHITECTURE_V1.md` | 145 | `app_whiteboard_create_project` | `whiteboard_create_project` | `\| app_whiteboard_create_project \| Créer un projet \| student_id, subject, stor` |
| 98 | `docs\SMART_WHITEBOARD_ARCHITECTURE_V1.md` | 146 | `app_whiteboard_update_project` | `whiteboard_update_project` | `\| app_whiteboard_update_project \| Mettre à jour un projet \| project_id, story` |
| 99 | `docs\SMART_WHITEBOARD_ARCHITECTURE_V1.md` | 147 | `app_whiteboard_get_project` | `whiteboard_get_project` | `\| app_whiteboard_get_project \| Récupérer un projet \| project_id \|` |
| 100 | `docs\SMART_WHITEBOARD_ARCHITECTURE_V1.md` | 148 | `app_whiteboard_list_projects` | `whiteboard_list_projects` | `\| app_whiteboard_list_projects \| Lister les projets d'un étudiant \| student_i` |
| 101 | `docs\SMART_WHITEBOARD_ARCHITECTURE_V1.md` | 149 | `app_whiteboard_delete_project` | `whiteboard_delete_project` | `\| app_whiteboard_delete_project \| Supprimer un projet \| project_id \|` |
| 102 | `docs\SMART_WHITEBOARD_ARCHITECTURE_V1.md` | 150 | `app_whiteboard_create_render_job` | `whiteboard_create_render_job` | `\| app_whiteboard_create_render_job \| Créer un job de rendu \| project_id, expo` |
| 103 | `docs\SMART_WHITEBOARD_ARCHITECTURE_V1.md` | 151 | `app_whiteboard_get_render_status` | `whiteboard_get_render_status` | `\| app_whiteboard_get_render_status \| Récupérer le statut d'un rendu \| render_` |
| 104 | `docs\SMART_WHITEBOARD_ARCHITECTURE_V1.md` | 581 | `app_whiteboard_create_render_job` | `whiteboard_create_render_job` | `1. Flutter → RPC app_whiteboard_create_render_job` |
| 105 | `docs\SMART_WHITEBOARD_ARCHITECTURE_V1.md` | 601 | `app_whiteboard_get_render_status` | `whiteboard_get_render_status` | `11. Flutter récupère video_url via RPC app_whiteboard_get_render_status` |
| 106 | `docs\SMART_WHITEBOARD_LIFECYCLE.md` | 90 | `app_whiteboard_create_render_job` | `whiteboard_create_render_job` | `**Composant** : RPC app_whiteboard_create_render_job` |
| 107 | `docs\SMART_WHITEBOARD_RENDERER_V1_FEASIBILITY.md` | 256 | `app_whiteboard_create_render_job` | `whiteboard_create_render_job` | `1. Flutter → RPC app_whiteboard_create_render_job` |
| 108 | `docs\SMART_WHITEBOARD_RENDERER_V1_FEASIBILITY.md` | 276 | `app_whiteboard_get_render_status` | `whiteboard_get_render_status` | `11. Flutter récupère video_url via RPC app_whiteboard_get_render_status` |
| 109 | `docs\SMART_WHITEBOARD_V1_SCOPE.md` | 550 | `app_whiteboard_create_render_job` | `whiteboard_create_render_job` | `12. RPC app_whiteboard_create_render_job` |
| 110 | `docs\SMART_WHITEBOARD_V1_SCOPE.md` | 584 | `app_whiteboard_create_render_job` | `whiteboard_create_render_job` | `RPC app_whiteboard_create_render_job` |

---

## OCCURRENCES À CONSERVER (KEEP)

| # | Fichier | Ligne | Ancien nom | Raison |
|---|---------|-------|------------|--------|
| 1 | `.windsurf\audit_smart_whiteboard_wiring.md` | 205 | `app_whiteboard_create_project` | KEEP (historical document) |
| 2 | `.windsurf\MISSION_D12_NORMALISATION_AUDIT.md` | 96 | `app_whiteboard_create_project` | KEEP (historical document) |
| 3 | `.windsurf\MISSION_D13_EXECUTION_REPORT.md` | 130 | `app_whiteboard_create_project` | KEEP (historical document) |
| 4 | `.windsurf\MISSION_D13_EXECUTION_REPORT.md` | 131 | `app_whiteboard_fetch_queued_jobs` | KEEP (historical document) |
| 5 | `.windsurf\MISSION_D15_1_FINAL_REPORT.md` | 36 | `app_whiteboard_create_project` | KEEP (historical document) |
| 6 | `.windsurf\MISSION_D15_1_FINAL_REPORT.md` | 41 | `app_whiteboard_create_project` | KEEP (historical document) |
| 7 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 31 | `app_whiteboard_create_project` | KEEP (historical document) |
| 8 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 32 | `app_whiteboard_create_project` | KEEP (historical document) |
| 9 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 51 | `app_whiteboard_create_project` | KEEP (historical document) |
| 10 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 63 | `app_whiteboard_create_project` | KEEP (historical document) |
| 11 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 69 | `app_whiteboard_create_project` | KEEP (historical document) |
| 12 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 72 | `app_whiteboard_create_project` | KEEP (historical document) |
| 13 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 84 | `app_whiteboard_create_project` | KEEP (historical document) |
| 14 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 95 | `app_whiteboard_create_project` | KEEP (historical document) |
| 15 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 98 | `app_whiteboard_create_project` | KEEP (historical document) |
| 16 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 104 | `app_whiteboard_create_project` | KEEP (historical document) |
| 17 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 112 | `app_whiteboard_create_project` | KEEP (historical document) |
| 18 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 153 | `app_whiteboard_create_project` | KEEP (historical document) |
| 19 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 187 | `app_whiteboard_create_project` | KEEP (historical document) |
| 20 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 208 | `app_whiteboard_create_project` | KEEP (historical document) |
| 21 | `.windsurf\MISSION_D15_BREAKPOINT_REPORT.md` | 210 | `app_whiteboard_create_project` | KEEP (historical document) |
| 22 | `.windsurf\whiteboard_real_inventory.md` | 43 | `app_whiteboard_fetch_queued_jobs` | KEEP (historical document) |
| 23 | `.windsurf\whiteboard_real_inventory.md` | 46 | `app_whiteboard_fetch_queued_jobs` | KEEP (historical document) |
| 24 | `.windsurf\whiteboard_real_inventory.md` | 73 | `app_whiteboard_mark_done` | KEEP (historical document) |
| 25 | `.windsurf\whiteboard_real_inventory.md` | 76 | `app_whiteboard_mark_done` | KEEP (historical document) |
| 26 | `.windsurf\whiteboard_real_inventory.md` | 103 | `app_whiteboard_mark_failed` | KEEP (historical document) |
| 27 | `.windsurf\whiteboard_real_inventory.md` | 106 | `app_whiteboard_mark_failed` | KEEP (historical document) |
| 28 | `.windsurf\whiteboard_real_inventory.md` | 133 | `app_whiteboard_mark_processing` | KEEP (historical document) |
| 29 | `.windsurf\whiteboard_real_inventory.md` | 136 | `app_whiteboard_mark_processing` | KEEP (historical document) |
| 30 | `.windsurf\whiteboard_real_inventory.md` | 175 | `app_whiteboard_create_project` | KEEP (historical document) |
| 31 | `.windsurf\whiteboard_real_inventory.md` | 178 | `app_whiteboard_create_project` | KEEP (historical document) |
| 32 | `.windsurf\whiteboard_source_inventory.md` | 37 | `app_whiteboard_create_project` | KEEP (historical document) |
| 33 | `.windsurf\whiteboard_source_inventory.md` | 174 | `app_whiteboard_create_project` | KEEP (historical document) |
| 34 | `docs\ACADEMIA_TRACEABILITY_MATRIX.md` | 69 | `app_whiteboard_create_project` | KEEP (historical document) |
| 35 | `docs\ACADEMIA_TRACEABILITY_MATRIX.md` | 77 | `app_whiteboard_get_project` | KEEP (historical document) |
| 36 | `docs\ACADEMIA_TRACEABILITY_MATRIX.md` | 78 | `app_whiteboard_update_project` | KEEP (historical document) |
| 37 | `docs\ACADEMIA_TRACEABILITY_MATRIX.md` | 79 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 38 | `docs\ACADEMIA_TRACEABILITY_MATRIX.md` | 80 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 39 | `docs\ACADEMIA_TRACEABILITY_MATRIX.md` | 593 | `app_whiteboard_create_project` | KEEP (historical document) |
| 40 | `docs\ACADEMIA_TRACEABILITY_MATRIX.md` | 633 | `app_whiteboard_create_project` | KEEP (historical document) |
| 41 | `docs\PHASE_A_READINESS.md` | 251 | `app_whiteboard_create_project` | KEEP (historical document) |
| 42 | `docs\PHASE_A_READINESS.md` | 252 | `app_whiteboard_update_project` | KEEP (historical document) |
| 43 | `docs\PHASE_A_READINESS.md` | 253 | `app_whiteboard_get_project` | KEEP (historical document) |
| 44 | `docs\PHASE_A_READINESS.md` | 254 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 45 | `docs\PHASE_A_READINESS.md` | 255 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 46 | `docs\PHASE_A_READINESS.md` | 256 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 47 | `docs\PHASE_A_READINESS.md` | 257 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 48 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 304 | `app_whiteboard_create_project` | KEEP (historical document) |
| 49 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 308 | `app_whiteboard_create_project` | KEEP (historical document) |
| 50 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 334 | `app_whiteboard_update_project` | KEEP (historical document) |
| 51 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 338 | `app_whiteboard_update_project` | KEEP (historical document) |
| 52 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 366 | `app_whiteboard_get_project` | KEEP (historical document) |
| 53 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 370 | `app_whiteboard_get_project` | KEEP (historical document) |
| 54 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 386 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 55 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 390 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 56 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 413 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 57 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 417 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 58 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 433 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 59 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 437 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 60 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 453 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 61 | `docs\PHASE_B0_SUPABASE_READINESS.md` | 457 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 62 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 225 | `app_whiteboard_create_project` | KEEP (historical document) |
| 63 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 229 | `app_whiteboard_create_project` | KEEP (historical document) |
| 64 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 253 | `app_whiteboard_update_project` | KEEP (historical document) |
| 65 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 257 | `app_whiteboard_update_project` | KEEP (historical document) |
| 66 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 283 | `app_whiteboard_get_project` | KEEP (historical document) |
| 67 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 287 | `app_whiteboard_get_project` | KEEP (historical document) |
| 68 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 301 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 69 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 305 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 70 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 325 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 71 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 329 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 72 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 343 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 73 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 347 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 74 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 361 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 75 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 365 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 76 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 541 | `app_whiteboard_create_project` | KEEP (historical document) |
| 77 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 543 | `app_whiteboard_update_project` | KEEP (historical document) |
| 78 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 545 | `app_whiteboard_get_project` | KEEP (historical document) |
| 79 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 547 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 80 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 549 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 81 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 551 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 82 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 553 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 83 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 578 | `app_whiteboard_create_project` | KEEP (historical document) |
| 84 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 579 | `app_whiteboard_get_project` | KEEP (historical document) |
| 85 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 580 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 86 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 581 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 87 | `docs\PHASE_B15_MIGRATION_DRY_RUN.md` | 582 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 88 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 277 | `app_whiteboard_create_project` | KEEP (historical document) |
| 89 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 279 | `app_whiteboard_create_project` | KEEP (historical document) |
| 90 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 331 | `app_whiteboard_update_project` | KEEP (historical document) |
| 91 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 333 | `app_whiteboard_update_project` | KEEP (historical document) |
| 92 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 382 | `app_whiteboard_get_project` | KEEP (historical document) |
| 93 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 384 | `app_whiteboard_get_project` | KEEP (historical document) |
| 94 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 403 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 95 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 405 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 96 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 431 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 97 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 433 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 98 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 451 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 99 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 453 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 100 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 475 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 101 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 477 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 102 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 506 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 103 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 507 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 104 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 508 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 105 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 509 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 106 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 510 | `app_whiteboard_get_project` | KEEP (historical document) |
| 107 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 511 | `app_whiteboard_update_project` | KEEP (historical document) |
| 108 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 512 | `app_whiteboard_create_project` | KEEP (historical document) |
| 109 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 703 | `app_whiteboard_create_project` | KEEP (historical document) |
| 110 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 704 | `app_whiteboard_update_project` | KEEP (historical document) |
| 111 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 705 | `app_whiteboard_get_project` | KEEP (historical document) |
| 112 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 706 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 113 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 707 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 114 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 708 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 115 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 709 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 116 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 840 | `app_whiteboard_create_project` | KEEP (historical document) |
| 117 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 842 | `app_whiteboard_create_project` | KEEP (historical document) |
| 118 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 852 | `app_whiteboard_get_project` | KEEP (historical document) |
| 119 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 854 | `app_whiteboard_get_project` | KEEP (historical document) |
| 120 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 857 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 121 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 859 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 122 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 862 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 123 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 864 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 124 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 867 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 125 | `docs\PHASE_B1_MIGRATION_DESIGN.md` | 869 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 126 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 567 | `app_whiteboard_create_project` | KEEP (historical document) |
| 127 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 568 | `app_whiteboard_update_project` | KEEP (historical document) |
| 128 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 569 | `app_whiteboard_get_project` | KEEP (historical document) |
| 129 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 570 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 130 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 571 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 131 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 572 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 132 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 573 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 133 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 622 | `app_whiteboard_create_project` | KEEP (historical document) |
| 134 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 623 | `app_whiteboard_update_project` | KEEP (historical document) |
| 135 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 624 | `app_whiteboard_get_project` | KEEP (historical document) |
| 136 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 625 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 137 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 626 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 138 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 627 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 139 | `docs\PHASE_C3B2_DAMAGE_ASSESSMENT.md` | 628 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 140 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 292 | `app_whiteboard_create_project` | KEEP (historical document) |
| 141 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 293 | `app_whiteboard_update_project` | KEEP (historical document) |
| 142 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 294 | `app_whiteboard_get_project` | KEEP (historical document) |
| 143 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 295 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 144 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 296 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 145 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 297 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 146 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 298 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 147 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 405 | `app_whiteboard_create_project` | KEEP (historical document) |
| 148 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 406 | `app_whiteboard_update_project` | KEEP (historical document) |
| 149 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 407 | `app_whiteboard_get_project` | KEEP (historical document) |
| 150 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 408 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 151 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 409 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 152 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 410 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 153 | `docs\PHASE_C3B5_SCHEMA_DRIFT_AUDIT.md` | 411 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 154 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 136 | `app_whiteboard_create_project` | KEEP (historical document) |
| 155 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 137 | `app_whiteboard_update_project` | KEEP (historical document) |
| 156 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 138 | `app_whiteboard_get_project` | KEEP (historical document) |
| 157 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 139 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 158 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 140 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 159 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 141 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 160 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 142 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 161 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 436 | `app_whiteboard_create_project` | KEEP (historical document) |
| 162 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 437 | `app_whiteboard_update_project` | KEEP (historical document) |
| 163 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 438 | `app_whiteboard_get_project` | KEEP (historical document) |
| 164 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 439 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 165 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 440 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 166 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 441 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 167 | `docs\PHASE_C3C1_PRE_REMEDIATION_LOCK.md` | 442 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 168 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 467 | `app_whiteboard_create_project` | KEEP (historical document) |
| 169 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 468 | `app_whiteboard_update_project` | KEEP (historical document) |
| 170 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 469 | `app_whiteboard_get_project` | KEEP (historical document) |
| 171 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 470 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 172 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 471 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 173 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 472 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 174 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 473 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 175 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 685 | `app_whiteboard_create_project` | KEEP (historical document) |
| 176 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 686 | `app_whiteboard_create_project` | KEEP (historical document) |
| 177 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 693 | `app_whiteboard_get_project` | KEEP (historical document) |
| 178 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 694 | `app_whiteboard_get_project` | KEEP (historical document) |
| 179 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 697 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 180 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 698 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 181 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 701 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 182 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 702 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 183 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 705 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 184 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 706 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 185 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 710 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 186 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 738 | `app_whiteboard_create_project` | KEEP (historical document) |
| 187 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 745 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 188 | `docs\PHASE_C3C_REMEDIATION_PLAN.md` | 766 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 189 | `docs\PHASE_D1_FLUTTER_FLOW_LOCK.md` | 273 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 190 | `docs\PHASE_D1_FLUTTER_FLOW_LOCK.md` | 274 | `app_whiteboard_get_render_job` | KEEP (historical document) |
| 191 | `docs\PHASE_D1_FLUTTER_FLOW_LOCK.md` | 628 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 192 | `docs\PHASE_D1_FLUTTER_FLOW_LOCK.md` | 629 | `app_whiteboard_get_render_job` | KEEP (historical document) |
| 193 | `docs\PHASE_D3A21_GENERATION_CONTRACT_LOCK.md` | 1677 | `app_whiteboard_create_project` | KEEP (historical document) |
| 194 | `docs\PHASE_D3A2_CONTENT_AGENT_SPEC.md` | 502 | `app_whiteboard_create_project` | KEEP (historical document) |
| 195 | `docs\PHASE_D3A2_CONTENT_AGENT_SPEC.md` | 506 | `app_whiteboard_create_project` | KEEP (historical document) |
| 196 | `docs\PHASE_D3A2_CONTENT_AGENT_SPEC.md` | 519 | `app_whiteboard_create_project` | KEEP (historical document) |
| 197 | `docs\PHASE_D3A2_IMPLEMENTATION_ROADMAP.md` | 33 | `app_whiteboard_create_project` | KEEP (historical document) |
| 198 | `docs\PHASE_D3A3_CONTENT_AGENT_IMPLEMENTATION.md` | 183 | `app_whiteboard_create_project` | KEEP (historical document) |
| 199 | `docs\PHASE_D3A3_NON_REGRESSION_PROOF.md` | 42 | `app_whiteboard_create_project` | KEEP (historical document) |
| 200 | `docs\PHASE_D3A3_NON_REGRESSION_PROOF.md` | 227 | `app_whiteboard_create_project` | KEEP (historical document) |
| 201 | `docs\PHASE_D3A3_REUSE_REPORT.md` | 356 | `app_whiteboard_create_project` | KEEP (historical document) |
| 202 | `docs\PHASE_D3B_NON_REGRESSION_PROOF.md` | 48 | `app_whiteboard_create_project` | KEEP (historical document) |
| 203 | `docs\PHASE_D5H_PRODUCTION_DEPLOYMENT_REPORT.md` | 57 | `app_whiteboard_create_project` | KEEP (historical document) |
| 204 | `docs\PHASE_D5H_PRODUCTION_DEPLOYMENT_REPORT.md` | 104 | `app_whiteboard_create_project` | KEEP (historical document) |
| 205 | `docs\PHASE_D5H_PRODUCTION_DEPLOYMENT_REPORT.md` | 156 | `app_whiteboard_create_project` | KEEP (historical document) |
| 206 | `docs\PHASE_D5H_PRODUCTION_DEPLOYMENT_REPORT.md` | 162 | `app_whiteboard_create_project` | KEEP (historical document) |
| 207 | `docs\PHASE_D5H_PRODUCTION_DEPLOYMENT_REPORT.md` | 208 | `app_whiteboard_create_project` | KEEP (historical document) |
| 208 | `docs\PHASE_D5I_PRODUCTION_ACTIVATION_REPORT.md` | 287 | `app_whiteboard_create_project` | KEEP (historical document) |
| 209 | `docs\PHASE_D6A_FLUTTER_INTEGRATION_AUDIT.md` | 27 | `app_whiteboard_create_project` | KEEP (historical document) |
| 210 | `docs\PHASE_D6E_PERFORMANCE_AUDIT.md` | 313 | `app_whiteboard_create_project` | KEEP (historical document) |
| 211 | `docs\REUSE_INVENTORY_SMART_WHITEBOARD_V1.md` | 66 | `app_whiteboard_create_project` | KEEP (historical document) |
| 212 | `docs\REUSE_INVENTORY_SMART_WHITEBOARD_V1.md` | 67 | `app_whiteboard_update_project` | KEEP (historical document) |
| 213 | `docs\REUSE_INVENTORY_SMART_WHITEBOARD_V1.md` | 68 | `app_whiteboard_get_project` | KEEP (historical document) |
| 214 | `docs\REUSE_INVENTORY_SMART_WHITEBOARD_V1.md` | 69 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 215 | `docs\REUSE_INVENTORY_SMART_WHITEBOARD_V1.md` | 70 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 216 | `docs\REUSE_INVENTORY_SMART_WHITEBOARD_V1.md` | 71 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 217 | `docs\REUSE_INVENTORY_SMART_WHITEBOARD_V1.md` | 72 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 218 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 367 | `app_whiteboard_create_project` | KEEP (historical document) |
| 219 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 370 | `app_whiteboard_create_project` | KEEP (historical document) |
| 220 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 409 | `app_whiteboard_update_project` | KEEP (historical document) |
| 221 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 412 | `app_whiteboard_update_project` | KEEP (historical document) |
| 222 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 432 | `app_whiteboard_get_project` | KEEP (historical document) |
| 223 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 435 | `app_whiteboard_get_project` | KEEP (historical document) |
| 224 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 454 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 225 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 457 | `app_whiteboard_list_projects` | KEEP (historical document) |
| 226 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 477 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 227 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 480 | `app_whiteboard_delete_project` | KEEP (historical document) |
| 228 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 496 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 229 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 499 | `app_whiteboard_create_render_job` | KEEP (historical document) |
| 230 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 528 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 231 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 531 | `app_whiteboard_get_render_status` | KEEP (historical document) |
| 232 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 735 | `app_whiteboard_list_queued_renders` | KEEP (historical document) |
| 233 | `docs\SMART_WHITEBOARD_V1_FINAL_SPEC.md` | 1172 | `app_whiteboard_create_render_job` | KEEP (historical document) |

---

## NOTE

Les fichiers KEEP sont des documents/historiques/rapports d'audit qui documentent l'état passé. Les modifier fausserait les preuves de normalisation. Pour atteindre 0 occurrence globale, ces fichiers doivent être archivés ou déplacés hors du projet.
