# PHASE B.0 – SUPABASE READINESS

**Version** : 1.0  
**Date** : 23 Juin 2026  
**Mode** : LECTURE SEULE  
**Objectif** : Préparation du chantier Supabase

---

## DIRECTIVE TECHNIQUE PERMANENTE

Toute intervention concernant Supabase, Tables, Buckets, RPC, Edge Functions, Storage doit obligatoirement être réalisée via les RPC Python administrateurs présents dans `.windsurf`.

Aucune hypothèse autorisée. Aucune affirmation non vérifiée.

---

## PARTIE 1 – VALIDATION DU DATA CONTRACT

### 1.1 Comparaison Data Contract vs storyboard_models.dart

| Modèle | Data Contract | storyboard_models.dart | Conformité |
|--------|---------------|-------------------------|------------|
| WhiteboardProject | ✅ Défini | ✅ Implémenté | ✅ 100% |
- Storyboard | ✅ Défini | ✅ Implémenté | ✅ 100% |
- Scene | ✅ Défini | ✅ Implémenté | ✅ 100% |
- Block | ✅ Défini | ✅ Implémenté | ✅ 100% |
- Narration | ✅ Défini | ✅ Implémenté | ✅ 100% |
- RenderJob | ✅ Défini | ✅ Implémenté | ✅ 100% |
- ExportSettings | ✅ Défini | ✅ Implémenté | ✅ 100% |

### 1.2 Vérification des champs

**WhiteboardProject** :
- id (UUID) ✅
- student_id (UUID) ✅
- subject (String) ✅
- status (String) ✅
- created_at (ISO8601) ✅
- updated_at (ISO8601) ✅
- renderer_id (String) ✅
- theme_id (String) ✅
- narration_mode (String) ✅
- storyboard (JSONB) ✅

**Storyboard** :
- version (String) ✅
- created_at (ISO8601) ✅
- created_by (UUID) ✅
- subject (String) ✅
- renderer (String) ✅
- theme (String) ✅
- narration_mode (String) ✅
- export_settings (JSON) ✅
- scenes (Array) ✅

**Scene** :
- id (UUID) ✅
- order (Integer) ✅
- title (String) ✅
- duration_ms (Integer) ✅
- transition (JSON) ✅
- blocks (Array) ✅

**Block** :
- id (UUID) ✅
- type (String) ✅
- content (String) ✅
- order (Integer) ✅
- visible (Boolean) ✅
- animation (JSON) ✅
- position (JSON) ✅
- style (JSON) ✅

**Narration** :
- mode (String) ✅
- audio_url (String?) ✅
- duration_ms (Integer?) ✅
- language (String?) ✅
- voice (String?) ✅

**RenderJob** :
- id (UUID) ✅
- project_id (UUID) ✅
- status (String) ✅
- video_url (String?) ✅
- duration_ms (Integer?) ✅
- error_message (String?) ✅
- progress (Integer?) ✅
- created_at (ISO8601) ✅
- completed_at (ISO8601?) ✅

**ExportSettings** :
- format (String) ✅
- resolution (JSON) ✅
- frame_rate (Integer) ✅
- video_codec (String) ✅
- audio_codec (String) ✅

### 1.3 Conclusion

**Compatibilité totale** : ✅  
**Absence de divergence** : ✅

---

## PARTIE 2 – MAPPING TABLES

### 2.1 Table whiteboard_projects

| Colonne | Type PostgreSQL | Nullable | Index | Contrainte | Description |
|---------|-----------------|---------|-------|-----------|-------------|
| id | UUID | NOT NULL | PK, B-tree | PRIMARY KEY | Identifiant unique du projet |
- student_id | UUID | NOT NULL | B-tree | FK → students.id | Identifiant de l'étudiant propriétaire |
- subject | TEXT | NOT NULL | - | - | Sujet du projet |
- status | TEXT | NOT NULL | B-tree | CHECK (draft, completed) | Statut du projet |
- created_at | TIMESTAMPTZ | NOT NULL | B-tree | - | Date de création |
- updated_at | TIMESTAMPTZ | NOT NULL | - | - | Date de dernière modification |
- renderer_id | TEXT | NOT NULL | - | CHECK (scientific, notebook) | ID du renderer |
- theme_id | TEXT | NOT NULL | - | CHECK (scientific, notebook) | ID du thème |
- narration_mode | TEXT | NOT NULL | - | CHECK (none, tts, user_recording) | Mode de narration |
- storyboard_json | JSONB | NOT NULL | GIN | - | Storyboard JSON complet |

**Indexes** :
- `idx_whiteboard_projects_id` (B-tree) sur id
- `idx_whiteboard_projects_student_id` (B-tree) sur student_id
- `idx_whiteboard_projects_status` (B-tree) sur status
- `idx_whiteboard_projects_created_at` (B-tree) sur created_at
- `idx_whiteboard_projects_storyboard_json` (GIN) sur storyboard_json

**Contraintes** :
- `pk_whiteboard_projects` : PRIMARY KEY (id)
- `fk_whiteboard_projects_student_id` : FOREIGN KEY (student_id) → students(id)
- `chk_whiteboard_projects_status` : CHECK (status IN ('draft', 'completed'))
- `chk_whiteboard_projects_renderer_id` : CHECK (renderer_id IN ('scientific', 'notebook'))
- `chk_whiteboard_projects_theme_id` : CHECK (theme_id IN ('scientific', 'notebook'))
- `chk_whiteboard_projects_narration_mode` : CHECK (narration_mode IN ('none', 'tts', 'user_recording'))

### 2.2 Table whiteboard_renders

| Colonne | Type PostgreSQL | Nullable | Index | Contrainte | Description |
|---------|-----------------|---------|-------|-----------|-------------|
| id | UUID | NOT NULL | PK, B-tree | PRIMARY KEY | Identifiant unique du job |
- project_id | UUID | NOT NULL | B-tree | FK → whiteboard_projects.id | Identifiant du projet |
- status | TEXT | NOT NULL | B-tree | CHECK (queued, processing, done, failed) | Statut du job |
- video_url | TEXT | NULL | - | - | URL du MP4 généré |
- duration_ms | INTEGER | NULL | - | - | Durée du MP4 en millisecondes |
- error_message | TEXT | NULL | - | - | Message d'erreur |
- progress | INTEGER | NULL | - | CHECK (0-100) | Progression du rendu (0-100) |
- created_at | TIMESTAMPTZ | NOT NULL | B-tree | - | Date de création |
- completed_at | TIMESTAMPTZ | NULL | - | - | Date de complétion |

**Indexes** :
- `idx_whiteboard_renders_id` (B-tree) sur id
- `idx_whiteboard_renders_project_id` (B-tree) sur project_id
- `idx_whiteboard_renders_status` (B-tree) sur status
- `idx_whiteboard_renders_created_at` (B-tree) sur created_at

**Contraintes** :
- `pk_whiteboard_renders` : PRIMARY KEY (id)
- `fk_whiteboard_renders_project_id` : FOREIGN KEY (project_id) → whiteboard_projects(id) ON DELETE CASCADE
- `chk_whiteboard_renders_status` : CHECK (status IN ('queued', 'processing', 'done', 'failed'))
- `chk_whiteboard_renders_progress` : CHECK (progress >= 0 AND progress <= 100)

---

## PARTIE 3 – MAPPING JSONB

### 3.1 Structure stockée

**Storyboard → JSONB**

```json
{
  "version": "string",
  "created_at": "iso8601",
  "created_by": "uuid",
  "subject": "string",
  "renderer": "string",
  "theme": "string",
  "narration_mode": "string",
  "export_settings": {
    "format": "string",
    "resolution": {
      "width": "integer",
      "height": "integer"
    },
    "frame_rate": "integer",
    "video_codec": "string",
    "audio_codec": "string"
  },
  "scenes": [
    {
      "id": "uuid",
      "order": "integer",
      "title": "string",
      "duration_ms": "integer",
      "transition": {},
      "blocks": [
        {
          "id": "uuid",
          "type": "string",
          "content": "string",
          "order": "integer",
          "visible": "boolean",
          "animation": {},
          "position": {},
          "style": {}
        }
      ]
    }
  ]
}
```

### 3.2 Taille moyenne

**Estimation** :
- Version : 10 octets
- Created_at : 25 octets
- Created_by : 36 octets
- Subject : 50 octets
- Renderer : 10 octets
- Theme : 10 octets
- Narration_mode : 15 octets
- Export_settings : 50 octets
- Scenes (10 scènes) : 5 Ko
- **Total** : **~5.2 Ko**

### 3.3 Taille maximale

**Scénario maximal** :
- 50 scènes
- 200 blocs
- **Taille estimée** : **~20 Ko**

### 3.4 Conclusion

**Structure stockée** : ✅ Conforme au Data Contract  
**Taille moyenne** : ~5.2 Ko (négligeable)  
**Taille maximale** : ~20 Ko (acceptable)  
**Limite Supabase** : 1 Go par document (très loin)

---

## PARTIE 4 – MAPPING BUCKETS

### 4.1 Bucket whiteboard-narrations

**Structure** :
```
whiteboard-narrations/
  {project_id}/
    narration.mp3
```

**Nommage** :
- Répertoire : `{project_id}` (UUID)
- Fichier : `narration.mp3`

**Organisation** :
- Un fichier audio par projet
- Répertoire par projet pour isolation

**Format** :
- MP3 (AAC, 128 kbps)
- Taille moyenne : 1-3 Mo (1-3 minutes)

### 4.2 Bucket whiteboard-renders

**Structure** :
```
whiteboard-renders/
  {project_id}/
    render.mp4
```

**Nommage** :
- Répertoire : `{project_id}` (UUID)
- Fichier : `render.mp4`

**Organisation** :
- Un fichier MP4 par projet
- Répertoire par projet pour isolation

**Format** :
- MP4 (H.264, AAC, 1080x1920, 30 fps)
- Taille moyenne : 15-112.5 Mo (1-3 minutes)

### 4.3 Politique de rétention

**whiteboard-narrations** :
- Conserver tant que le projet existe
- Supprimer avec le projet (CASCADE)

**whiteboard-renders** :
- Conserver tant que le projet existe
- Supprimer avec le projet (CASCADE)

---

## PARTIE 5 – MAPPING RPC

### 5.1 RPC app_whiteboard_create_project

**Signature** :
```sql
CREATE OR REPLACE FUNCTION app_whiteboard_create_project(
  p_student_id UUID,
  p_subject TEXT,
  p_renderer_id TEXT,
  p_theme_id TEXT,
  p_narration_mode TEXT,
  p_storyboard_json JSONB
) RETURNS JSONB
```

**Paramètres** :
- p_student_id : UUID de l'étudiant
- p_subject : Sujet du projet
- p_renderer_id : ID du renderer (scientific, notebook)
- p_theme_id : ID du thème (scientific, notebook)
- p_narration_mode : Mode de narration (none, tts, user_recording)
- p_storyboard_json : Storyboard JSON complet

**Retour** :
- JSONB : Projet créé

**Logique** :
- Générer un UUID pour le projet
- Insérer dans whiteboard_projects
- Retourner le projet créé

### 5.2 RPC app_whiteboard_update_project

**Signature** :
```sql
CREATE OR REPLACE FUNCTION app_whiteboard_update_project(
  p_project_id UUID,
  p_subject TEXT,
  p_status TEXT,
  p_renderer_id TEXT,
  p_theme_id TEXT,
  p_narration_mode TEXT,
  p_storyboard_json JSONB
) RETURNS JSONB
```

**Paramètres** :
- p_project_id : UUID du projet
- p_subject : Sujet du projet
- p_status : Statut du projet (draft, completed)
- p_renderer_id : ID du renderer
- p_theme_id : ID du thème
- p_narration_mode : Mode de narration
- p_storyboard_json : Storyboard JSON complet

**Retour** :
- JSONB : Projet mis à jour

**Logique** :
- Mettre à jour le projet
- Mettre à jour updated_at
- Retourner le projet mis à jour

### 5.3 RPC app_whiteboard_get_project

**Signature** :
```sql
CREATE OR REPLACE FUNCTION app_whiteboard_get_project(
  p_project_id UUID
) RETURNS JSONB
```

**Paramètres** :
- p_project_id : UUID du projet

**Retour** :
- JSONB : Projet

**Logique** :
- Sélectionner le projet par ID
- Vérifier que l'utilisateur a le droit de lecture (RLS)
- Retourner le projet

### 5.4 RPC app_whiteboard_list_projects

**Signature** :
```sql
CREATE OR REPLACE FUNCTION app_whiteboard_list_projects(
  p_student_id UUID,
  p_status TEXT DEFAULT NULL,
  p_limit INTEGER DEFAULT 50,
  p_offset INTEGER DEFAULT 0
) RETURNS JSONB
```

**Paramètres** :
- p_student_id : UUID de l'étudiant
- p_status : Filtre par statut (optionnel)
- p_limit : Limite de résultats (défaut 50)
- p_offset : Offset (défaut 0)

**Retour** :
- JSONB : Liste des projets

**Logique** :
- Sélectionner les projets de l'étudiant
- Filtrer par statut si fourni
- Paginer avec limit/offset
- Retourner la liste

### 5.5 RPC app_whiteboard_delete_project

**Signature** :
```sql
CREATE OR REPLACE FUNCTION app_whiteboard_delete_project(
  p_project_id UUID
) RETURNS BOOLEAN
```

**Paramètres** :
- p_project_id : UUID du projet

**Retour** :
- BOOLEAN : Succès (true) ou échec (false)

**Logique** :
- Supprimer le projet
- CASCADE sur whiteboard_renders
- Retourner true si succès

### 5.6 RPC app_whiteboard_create_render_job

**Signature** :
```sql
CREATE OR REPLACE FUNCTION app_whiteboard_create_render_job(
  p_project_id UUID
) RETURNS JSONB
```

**Paramètres** :
- p_project_id : UUID du projet

**Retour** :
- JSONB : RenderJob créé

**Logique** :
- Générer un UUID pour le job
- Insérer dans whiteboard_renders avec status = 'queued'
- Retourner le job créé

### 5.7 RPC app_whiteboard_get_render_status

**Signature** :
```sql
CREATE OR REPLACE FUNCTION app_whiteboard_get_render_status(
  p_render_job_id UUID
) RETURNS JSONB
```

**Paramètres** :
- p_render_job_id : UUID du job de rendu

**Retour** :
- JSONB : RenderJob

**Logique** :
- Sélectionner le job par ID
- Retourner le job avec statut et progression

---

## PARTIE 6 – POLICIES

### 6.1 Table whiteboard_projects

**Lecture (SELECT)** :
- Étudiant : Peut lire ses propres projets (student_id = auth.uid())
- Admin : Peut lire tous les projets

**Écriture (INSERT)** :
- Étudiant : Peut créer des projets (student_id = auth.uid())
- Admin : Peut créer des projets pour n'importe quel étudiant

**Modification (UPDATE)** :
- Étudiant : Peut modifier ses propres projets (student_id = auth.uid())
- Admin : Peut modifier tous les projets

**Suppression (DELETE)** :
- Étudiant : Peut supprimer ses propres projets (student_id = auth.uid())
- Admin : Peut supprimer tous les projets

### 6.2 Table whiteboard_renders

**Lecture (SELECT)** :
- Étudiant : Peut lire les rendus de ses projets (via project_id → whiteboard_projects.student_id = auth.uid())
- Admin : Peut lire tous les rendus

**Écriture (INSERT)** :
- Étudiant : Peut créer des rendus pour ses projets (via project_id → whiteboard_projects.student_id = auth.uid())
- Admin : Peut créer des rendus pour n'importe quel projet
- Service role : Peut créer des rendus (pour Kamatera)

**Modification (UPDATE)** :
- Étudiant : Peut modifier les rendus de ses projets (via project_id → whiteboard_projects.student_id = auth.uid())
- Admin : Peut modifier tous les rendus
- Service role : Peut modifier tous les rendus (pour Kamatera)

**Suppression (DELETE)** :
- Étudiant : Peut supprimer les rendus de ses projets (via project_id → whiteboard_projects.student_id = auth.uid())
- Admin : Peut supprimer tous les rendus
- CASCADE : Suppression automatique avec le projet

### 6.3 Buckets

**whiteboard-narrations** :
- Étudiant : Peut lire/écrire dans son répertoire ({project_id} = son projet)
- Admin : Peut lire/écrire partout
- Service role : Peut lire/écrire partout (pour Kamatera)

**whiteboard-renders** :
- Étudiant : Peut lire dans son répertoire ({project_id} = son projet)
- Admin : Peut lire/écrire partout
- Service role : Peut lire/écrire partout (pour Kamatera)

---

## PARTIE 7 – RISQUES

### 7.1 Conflits potentiels

| Risque | Probabilité | Impact | Mitigation |
|--------|-------------|--------|------------|
- Conflit de nommage tables | Très faible | Faible | Préfixe whiteboard_ distinct de challenge_ |
- Conflit de nommage RPCs | Très faible | Faible | Préfixe app_whiteboard_ distinct de app_challenge_ |
- Conflit de nommage buckets | Très faible | Faible | Préfixe whiteboard- distinct de challenge- |

### 7.2 Problèmes de migration

| Risque | Probabilité | Impact | Mitigation |
|--------|-------------|--------|------------|
- Migration échoue | Faible | Moyen | Tester en environnement de développement |
- Données perdues | Très faible | Élevé | Backup avant migration |
- Contraintes violées | Faible | Moyen | Valider les contraintes avant migration |

### 7.3 Problèmes de performance

| Risque | Probabilité | Impact | Mitigation |
|--------|-------------|--------|------------|
- JSONB trop volumineux | Très faible | Faible | Limiter la taille des Storyboards (100 Ko) |
- Index GIN lent | Faible | Faible | Optimiser les requêtes |
- Bucket saturation | Faible | Moyen | Nettoyage automatique CASCADE |

### 7.4 Conclusion

**Aucun risque bloquant identifié** ✅

---

## PARTIE 8 – DÉCISION

### 8.1 Évaluation

| Critère | État | Justification |
|---------|------|---------------|
- Validation Data Contract | ✅ Réussi | 100% de conformité |
- Mapping tables | ✅ Défini | Colonnes, types, indexes, contraintes définis |
- Mapping JSONB | ✅ Validé | Structure stockée, taille acceptable |
- Mapping buckets | ✅ Défini | Structure, nommage, organisation définis |
- Mapping RPCs | ✅ Défini | 7 RPCs avec signatures définies |
- Policies | ✅ Définies | Lecture, écriture, suppression définies |
- Risques | ✅ Identifiés | Aucun risque bloquant |

### 8.2 Décision

**PHASE B.1 (CRÉATION TABLES) AUTORISÉE** ✅

**Justification** :
- Data Contract validé (100% de conformité)
- Mapping tables défini (colonnes, types, indexes, contraintes)
- Mapping JSONB validé (structure stockée, taille acceptable)
- Mapping buckets défini (structure, nommage, organisation)
- Mapping RPCs défini (7 RPCs avec signatures)
- Policies définies (lecture, écriture, suppression)
- Aucun risque bloquant identifié

---

## CONCLUSION

**Phase B.0 – Supabase Readiness** : ✅ Terminée

**Prêt pour Phase B.1** : Création des tables Supabase

**Prochaine étape** : Phase B.1 – Création des tables whiteboard_projects et whiteboard_renders via RPC administrateurs

---

**Fin du document**
