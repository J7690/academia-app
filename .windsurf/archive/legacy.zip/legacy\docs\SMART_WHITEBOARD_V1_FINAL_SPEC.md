# SMART WHITEBOARD IA V1 – SPÉCIFICATION FINALE

**Version** : 1.0  
**Date** : 23 Juin 2026  
**Mode** : LECTURE SEULE  
**Objectif** : Contrat de développement du Smart Whiteboard IA V1

---

## DIRECTIVE PERMANENTE OBLIGATOIRE

### SUPABASE

Toute analyse, vérification ou validation concernant tables, buckets, policies, RPC, Edge Functions, stockage, schémas, permissions doit être réalisée exclusivement via les RPC Python administrateurs dédiés dans `.windsurf`.

Aucune hypothèse n'est autorisée. Aucune déduction n'est autorisée. Toute affirmation doit être vérifiée.

### KAMATERA CLOUD

Toute analyse, vérification ou validation concernant Docker, FFmpeg, CPU, RAM, stockage, services, workers, backend Python, volumes, configuration, pipelines vidéo doit être réalisée exclusivement via les RPC Python administrateurs dédiés dans `.windsurf`.

Aucune hypothèse n'est autorisée. Aucune déduction n'est autorisée. Toute affirmation doit être vérifiée.

---

## RAPPEL ARCHITECTURAL

Le Smart Whiteboard IA est un AJOUT.

Ce n'est pas une refonte. Ce n'est pas un remplacement. Ce n'est pas une migration.

---

## PARCOURS PROTÉGÉS

### Parcours 1
Filmer → Édition → Description → Compression Kamatera → Publication

### Parcours 2
Importer une vidéo → Édition → Description → Compression Kamatera → Publication

**Interdiction absolue de modifier ces parcours.**

---

## COMPOSANTS PROTÉGÉS

Interdiction absolue de modifier :
- `challenge_camera_capture_screen.dart`
- `student_challenge_video_editor_screen.dart`
- `video_publish_screen.dart`
- `videoasset_upload_service.dart`
- Pipeline de compression actuel
- Pipeline de publication actuel
- Tables `challenge_*`
- RPCs `challenge_*`
- Edge Functions `challenge_*`
- Workflows existants

---

## PARTIE 1 – ARCHITECTURE FLUTTER

### 1.1 Nouveaux écrans

#### Écran 1 : SmartWhiteboardInputScreen

**Fichier** : `lib/features/challenge/smart_whiteboard/smart_whiteboard_input_screen.dart`

**Fonction** : Saisie du sujet et génération du Storyboard via Bobodo

**Composants** :
- `TextField` pour saisir le sujet
- `ElevatedButton` "Générer avec Bobodo"
- `CircularProgressIndicator` pour l'état de chargement
- `Text` pour afficher les erreurs

**Actions** :
- `generateStoryboard(subject)` : Appel Bobodo pour générer Storyboard JSON
- Navigation vers `SmartWhiteboardEditorScreen` avec le Storyboard JSON

**Navigation** :
```dart
Navigator.pushNamed(
  context,
  '/smart-whiteboard-editor',
  arguments: {'storyboard_json': storyboardJson}
);
```

#### Écran 2 : SmartWhiteboardEditorScreen

**Fichier** : `lib/features/challenge/smart_whiteboard/smart_whiteboard_editor_screen.dart`

**Fonction** : Édition du contenu généré

**Composants** :
- `ListView.builder` pour afficher les blocs
- `TextField` pour éditer le texte de chaque bloc
- `IconButton` pour réorganiser les blocs (haut/bas)
- `IconButton` pour supprimer des blocs
- `FloatingActionButton` pour ajouter des blocs
- `ElevatedButton` "Prévisualiser"

**Types de blocs ajoutables** :
- title
- paragraph
- formula
- definition
- exercise
- correction

**Actions** :
- `addBlock(type)` : Ajouter un bloc
- `editBlock(blockId, content)` : Éditer un bloc
- `moveBlockUp(blockId)` : Déplacer un bloc vers le haut
- `moveBlockDown(blockId)` : Déplacer un bloc vers le bas
- `deleteBlock(blockId)` : Supprimer un bloc
- Navigation vers `SmartWhiteboardPreviewScreen` avec le Storyboard JSON modifié

#### Écran 3 : SmartWhiteboardPreviewScreen

**Fichier** : `lib/features/challenge/smart_whiteboard/smart_whiteboard_preview_screen.dart`

**Fonction** : Prévisualisation, narration et génération MP4

**Composants** :
- `AnimatedOpacity` pour l'affichage progressif des blocs (fade_in)
- `ElevatedButton` "Enregistrer narration"
- `ElevatedButton` "Utiliser TTS"
- `ElevatedButton` "Générer MP4"
- `LinearProgressIndicator` pour la progression du rendu
- `Text` pour afficher le statut du rendu

**Actions** :
- `recordNarration()` : Enregistrement audio utilisateur (flutter_sound)
- `generateTTS(text)` : Génération TTS (flutter_tts)
- `uploadNarration(audioFile)` : Upload audio vers Supabase Storage
- `createRenderJob()` : Créer un job de rendu via RPC
- `pollRenderStatus()` : Polling du statut de rendu
- Navigation vers `video_publish_screen` avec le MP4 généré

**Navigation** :
```dart
Navigator.pushNamed(
  context,
  '/video-publish',
  arguments: {'video_url': videoUrl, 'source': 'smart_whiteboard'}
);
```

### 1.2 Nouveaux widgets

#### Widget : WhiteboardBlockWidget

**Fichier** : `lib/features/challenge/smart_whiteboard/widgets/whiteboard_block_widget.dart`

**Fonction** : Affichage d'un bloc selon son type

**Composants** :
- `Text` pour title et paragraph
- `Math.tex` pour formula (flutter_math_fork)
- `Container` pour definition, exercise, correction

**Props** :
- `type` : Type du bloc
- `content` : Contenu du bloc
- `style` : Style du bloc

### 1.3 Nouveaux providers

#### Provider : SmartWhiteboardProvider

**Fichier** : `lib/features/challenge/smart_whiteboard/providers/smart_whiteboard_provider.dart`

**Fonction** : Gestion de l'état du Smart Whiteboard

**État** :
- `storyboardJson` : Storyboard JSON actuel
- `isGenerating` : État de génération Bobodo
- `isRendering` : État de rendu
- `renderStatus` : Statut du rendu
- `renderProgress` : Progression du rendu

**Méthodes** :
- `generateStoryboard(subject)` : Générer Storyboard via Bobodo
- `updateStoryboard(storyboardJson)` : Mettre à jour le Storyboard
- `createRenderJob()` : Créer un job de rendu
- `pollRenderStatus()` : Poller le statut de rendu

### 1.4 Nouveaux services

#### Service : SmartWhiteboardService

**Fichier** : `lib/features/challenge/smart_whiteboard/services/smart_whiteboard_service.dart`

**Fonction** : Appels RPC Supabase

**Méthodes** :
- `createProject(subject, storyboardJson)` : Créer un projet
- `updateProject(projectId, storyboardJson)` : Mettre à jour un projet
- `getProject(projectId)` : Récupérer un projet
- `listProjects(studentId)` : Lister les projets
- `deleteProject(projectId)` : Supprimer un projet
- `createRenderJob(projectId)` : Créer un job de rendu
- `getRenderStatus(renderId)` : Récupérer le statut de rendu

#### Service : SmartWhiteboardNarrationService

**Fichier** : `lib/features/challenge/smart_whiteboard/services/smart_whiteboard_narration_service.dart`

**Fonction** : Gestion de la narration

**Méthodes** :
- `recordNarration()` : Enregistrer l'audio utilisateur
- `generateTTS(text)` : Générer TTS
- `uploadNarration(projectId, audioFile)` : Upload audio vers Supabase Storage

### 1.5 Navigation

**Route ajoutée dans `main.dart`** :
```dart
'/smart-whiteboard-input': (context) => SmartWhiteboardInputScreen(),
'/smart-whiteboard-editor': (context) => SmartWhiteboardEditorScreen(
  storyboardJson: ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>,
),
'/smart-whiteboard-preview': (context) => SmartWhiteboardPreviewScreen(
  storyboardJson: ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>,
),
```

**Intégration dans `student_challenges_tab.dart`** :
```dart
ElevatedButton(
  onPressed: () {
    Navigator.pushNamed(context, '/smart-whiteboard-input');
  },
  child: Text('Smart Whiteboard IA'),
),
```

### 1.6 Injection dans le flux Challenge

**Point d'intégration** : `video_publish_screen.dart` (existant, PROTÉGÉ)

**Modification autorisée** : Aucune modification du fichier existant

**Approche** : Passer le `video_url` via navigation argument

```dart
Navigator.pushNamed(
  context,
  '/video-publish',
  arguments: {
    'video_url': videoUrl,
    'source': 'smart_whiteboard'
  }
);
```

---

## PARTIE 2 – ARCHITECTURE SUPABASE

### 2.1 Tables nécessaires

#### Table : whiteboard_projects

```sql
CREATE TABLE app.whiteboard_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES app.students(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  storyboard_json JSONB NOT NULL,
  renderer_id TEXT NOT NULL DEFAULT 'scientific',
  theme_id TEXT NOT NULL DEFAULT 'scientific',
  narration_mode TEXT NOT NULL DEFAULT 'none',
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_whiteboard_projects_student_id ON app.whiteboard_projects(student_id);
CREATE INDEX idx_whiteboard_projects_status ON app.whiteboard_projects(status);
```

**Colonnes** :
- `id` : UUID du projet
- `student_id` : UUID de l'étudiant
- `subject` : Sujet du projet
- `storyboard_json` : Storyboard JSON
- `renderer_id` : ID du renderer (scientific, notebook)
- `theme_id` : ID du thème
- `narration_mode` : Mode de narration (none, tts, user)
- `status` : Statut (draft, completed)
- `created_at` : Date de création
- `updated_at` : Date de mise à jour

#### Table : whiteboard_renders

```sql
CREATE TABLE app.whiteboard_renders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES app.whiteboard_projects(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'queued',
  video_url TEXT,
  duration_ms INTEGER,
  error_message TEXT,
  export_settings JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);

CREATE INDEX idx_whiteboard_renders_project_id ON app.whiteboard_renders(project_id);
CREATE INDEX idx_whiteboard_renders_status ON app.whiteboard_renders(status);
```

**Colonnes** :
- `id` : UUID du rendu
- `project_id` : UUID du projet
- `status` : Statut (queued, processing, done, failed)
- `video_url` : URL du MP4 généré
- `duration_ms` : Durée du MP4
- `error_message` : Message d'erreur
- `export_settings` : Paramètres d'export
- `created_at` : Date de création
- `completed_at` : Date de complétion

### 2.2 Buckets nécessaires

#### Bucket : whiteboard-narrations

**Rôle** : Stockage des fichiers audio de narration

**Structure** :
```
whiteboard-narrations/
  {project_id}/
    narration.mp3
```

**Policies RLS** :
- `SELECT` : Authentifié + propriétaire
- `INSERT` : Authentifié + propriétaire
- `UPDATE` : Authentifié + propriétaire
- `DELETE` : Authentifié + propriétaire

#### Bucket : whiteboard-renders

**Rôle** : Stockage des MP4 générés

**Structure** :
```
whiteboard-renders/
  {project_id}/
    render.mp4
```

**Policies RLS** :
- `SELECT` : Authentifié + propriétaire
- `INSERT` : Authentifié + propriétaire
- `UPDATE` : Authentifié + propriétaire
- `DELETE` : Authentifié + propriétaire

### 2.3 RPCs nécessaires

#### RPC : app_whiteboard_create_project

```sql
CREATE OR REPLACE FUNCTION app_whiteboard_create_project(
  p_student_id UUID,
  p_subject TEXT,
  p_storyboard_json JSONB,
  p_renderer_id TEXT DEFAULT 'scientific',
  p_theme_id TEXT DEFAULT 'scientific',
  p_narration_mode TEXT DEFAULT 'none'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_project_id UUID;
BEGIN
  INSERT INTO app.whiteboard_projects (
    student_id,
    subject,
    storyboard_json,
    renderer_id,
    theme_id,
    narration_mode
  ) VALUES (
    p_student_id,
    p_subject,
    p_storyboard_json,
    p_renderer_id,
    p_theme_id,
    p_narration_mode
  ) RETURNING id INTO v_project_id;
  
  RETURN jsonb_build_object(
    'success', true,
    'project_id', v_project_id
  );
END;
$$;
```

#### RPC : app_whiteboard_update_project

```sql
CREATE OR REPLACE FUNCTION app_whiteboard_update_project(
  p_project_id UUID,
  p_storyboard_json JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE app.whiteboard_projects
  SET
    storyboard_json = p_storyboard_json,
    updated_at = NOW()
  WHERE id = p_project_id;
  
  RETURN jsonb_build_object('success', true);
END;
$$;
```

#### RPC : app_whiteboard_get_project

```sql
CREATE OR REPLACE FUNCTION app_whiteboard_get_project(
  p_project_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_project JSONB;
BEGIN
  SELECT to_jsonb(wp) INTO v_project
  FROM app.whiteboard_projects wp
  WHERE wp.id = p_project_id;
  
  RETURN v_project;
END;
$$;
```

#### RPC : app_whiteboard_list_projects

```sql
CREATE OR REPLACE FUNCTION app_whiteboard_list_projects(
  p_student_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_projects JSONB;
BEGIN
  SELECT jsonb_agg(to_jsonb(wp)) INTO v_projects
  FROM app.whiteboard_projects wp
  WHERE wp.student_id = p_student_id
  ORDER BY wp.created_at DESC;
  
  RETURN COALESCE(v_projects, '[]'::jsonb);
END;
$$;
```

#### RPC : app_whiteboard_delete_project

```sql
CREATE OR REPLACE FUNCTION app_whiteboard_delete_project(
  p_project_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM app.whiteboard_projects
  WHERE id = p_project_id;
  
  RETURN jsonb_build_object('success', true);
END;
$$;
```

#### RPC : app_whiteboard_create_render_job

```sql
CREATE OR REPLACE FUNCTION app_whiteboard_create_render_job(
  p_project_id UUID,
  p_export_settings JSONB DEFAULT '{}'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_render_id UUID;
BEGIN
  INSERT INTO app.whiteboard_renders (
    project_id,
    status,
    export_settings
  ) VALUES (
    p_project_id,
    'queued',
    p_export_settings
  ) RETURNING id INTO v_render_id;
  
  RETURN jsonb_build_object(
    'success', true,
    'render_id', v_render_id
  );
END;
$$;
```

#### RPC : app_whiteboard_get_render_status

```sql
CREATE OR REPLACE FUNCTION app_whiteboard_get_render_status(
  p_render_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_render JSONB;
BEGIN
  SELECT to_jsonb(wr) INTO v_render
  FROM app.whiteboard_renders wr
  WHERE wr.id = p_render_id;
  
  RETURN v_render;
END;
$$;
```

### 2.4 Policies RLS

#### Table : whiteboard_projects

```sql
ALTER TABLE app.whiteboard_projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students can view own projects"
ON app.whiteboard_projects FOR SELECT
USING (auth.uid()::text = student_id::text);

CREATE POLICY "Students can create own projects"
ON app.whiteboard_projects FOR INSERT
WITH CHECK (auth.uid()::text = student_id::text);

CREATE POLICY "Students can update own projects"
ON app.whiteboard_projects FOR UPDATE
USING (auth.uid()::text = student_id::text);

CREATE POLICY "Students can delete own projects"
ON app.whiteboard_projects FOR DELETE
USING (auth.uid()::text = student_id::text);
```

#### Table : whiteboard_renders

```sql
ALTER TABLE app.whiteboard_renders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students can view own renders"
ON app.whiteboard_renders FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM app.whiteboard_projects wp
    WHERE wp.id = whiteboard_renders.project_id
    AND wp.student_id::text = auth.uid()::text
  )
);

CREATE POLICY "Students can create own renders"
ON app.whiteboard_renders FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM app.whiteboard_projects wp
    WHERE wp.id = whiteboard_renders.project_id
    AND wp.student_id::text = auth.uid()::text
  )
);
```

### 2.5 Validation requise

Avant de créer les tables et RPCs, utiliser les RPC Python administrateurs dans `.windsurf` pour :
- Vérifier que les tables n'existent pas déjà
- Vérifier que les RPCs n'existent pas déjà
- Vérifier que les buckets n'existent pas déjà
- Valider les schémas proposés

---

## PARTIE 3 – ARCHITECTURE KAMATERA

### 3.1 Validation requise

Avant de déployer sur Kamatera, utiliser les RPC Python administrateurs dans `.windsurf` pour :
- Vérifier que FFmpeg est installé
- Vérifier que Docker est installé
- Vérifier les ressources disponibles (CPU, RAM, disque)
- Vérifier les services actifs
- Valider la capacité de déploiement

### 3.2 Docker Compose

**Fichier** : `docker-compose.kamatera.yml`

**Services** :

#### Service : whiteboard-backend

```yaml
whiteboard-backend:
  build: .
  image: academia-whiteboard-backend:latest
  container_name: whiteboard-backend
  restart: unless-stopped
  ports:
    - "8002:8000"
  volumes:
    - /tmp/whiteboard_render:/tmp
  environment:
    - SUPABASE_URL=${SUPABASE_URL}
    - SUPABASE_SERVICE_KEY=${SUPABASE_SERVICE_KEY}
    - SUPABASE_ANON_KEY=${SUPABASE_ANON_KEY}
  command: uvicorn whiteboard_main:app --host 0.0.0.0 --port 8000
```

#### Service : whiteboard-render-worker

```yaml
whiteboard-render-worker:
  build: .
  image: academia-whiteboard-backend:latest
  container_name: whiteboard-render-worker
  restart: unless-stopped
  volumes:
    - /tmp/whiteboard_render:/tmp
  environment:
    - SUPABASE_URL=${SUPABASE_URL}
    - SUPABASE_SERVICE_KEY=${SUPABASE_SERVICE_KEY}
    - SUPABASE_ANON_KEY=${SUPABASE_ANON_KEY}
    - WORKER_LOOP=1
    - WORKER_INTERVAL_SECONDS=2
    - WORKER_MAX_JOBS=3
  command: python -u whiteboard_render_worker.py
```

### 3.3 Backend Python

**Fichier** : `whiteboard_main.py`

**Endpoints** :

#### Endpoint : /health

```python
@app.get("/health")
async def health():
    return {"status": "ok", "service": "whiteboard-backend"}
```

#### Endpoint : /whiteboard/render

```python
@app.post("/whiteboard/render")
async def render_whiteboard(request: RenderRequest):
    """
    Rendu Storyboard JSON → MP4
    """
    try:
        # Télécharger Storyboard JSON
        storyboard = await download_storyboard(request.project_id)
        
        # Télécharger narration audio
        narration_url = storyboard.get('narration', {}).get('audio_url')
        if narration_url:
            narration_path = await download_audio(narration_url)
        else:
            narration_path = None
        
        # Générer images PNG
        images = generate_images_from_storyboard(storyboard)
        
        # Assembler MP4
        video_path = assemble_video(images, narration_path)
        
        # Upload MP4
        video_url = await upload_video(video_path, request.project_id)
        
        # Mettre à jour le statut
        await update_render_status(request.render_id, 'done', video_url)
        
        return {"success": True, "video_url": video_url}
    
    except Exception as e:
        await update_render_status(request.render_id, 'failed', None, str(e))
        raise HTTPException(status_code=500, detail=str(e))
```

### 3.4 Worker

**Fichier** : `whiteboard_render_worker.py`

**Fonction** : Polling des jobs de rendu

```python
import asyncio
import time
from supabase import create_client

supabase = create_client(SUPABASE_URL, SUPABASE_SERVICE_KEY)

def poll_renders():
    while True:
        try:
            # Récupérer les jobs en attente
            response = supabase.rpc('app_whiteboard_list_queued_renders')
            
            for render in response:
                # Marquer comme processing
                supabase.table('whiteboard_renders').update({'status': 'processing'}).eq('id', render['id']).execute()
                
                # Appeler le endpoint de rendu
                requests.post(
                    'http://whiteboard-backend:8000/whiteboard/render',
                    json={'render_id': render['id'], 'project_id': render['project_id']}
                )
        
        except Exception as e:
            print(f"Error polling renders: {e}")
        
        time.sleep(int(os.getenv('WORKER_INTERVAL_SECONDS', '2')))

if __name__ == '__main__':
    poll_renders()
```

### 3.5 Génération d'images

**Fichier** : `image_generator.py`

**Fonction** : Génération d'images PNG depuis Storyboard JSON

```python
from PIL import Image, ImageDraw, ImageFont
import matplotlib.pyplot as plt

def generate_images_from_storyboard(storyboard):
    images = []
    
    for scene in storyboard['scenes']:
        for block in scene['blocks']:
            if block['type'] == 'title':
                image = generate_title_image(block['content'], block['style'])
            elif block['type'] == 'paragraph':
                image = generate_paragraph_image(block['content'], block['style'])
            elif block['type'] == 'formula':
                image = generate_formula_image(block['content'], block['style'])
            elif block['type'] == 'definition':
                image = generate_definition_image(block['content'], block['style'])
            elif block['type'] == 'exercise':
                image = generate_exercise_image(block['content'], block['style'])
            elif block['type'] == 'correction':
                image = generate_correction_image(block['content'], block['style'])
            
            images.append(image)
    
    return images

def generate_title_image(text, style):
    image = Image.new('RGB', (1080, 1920), color='white')
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype('Roboto.ttf', style['font_size'])
    
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    x = (1080 - text_width) / 2
    y = (1920 - text_height) / 2
    
    draw.text((x, y), text, font=font, fill=style['color'])
    return image

def generate_formula_image(latex, style):
    fig, ax = plt.subplots(figsize=(10.8, 19.2))
    ax.text(0.5, 0.5, f'${latex}$', fontsize=style['font_size'], 
            ha='center', va='center', color=style['color'])
    ax.axis('off')
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', pad_inches=0)
    buf.seek(0)
    image = Image.open(buf)
    plt.close(fig)
    
    return image
```

### 3.6 Assemblage vidéo

**Fichier** : `video_assembler.py`

**Fonction** : Assemblage images + audio → MP4

```python
import subprocess

def assemble_video(images, narration_path):
    # Sauvegarder les images
    for i, image in enumerate(images):
        image.save(f'/tmp/frame_{i}.png')
    
    # Assembler avec FFmpeg
    if narration_path:
        cmd = [
            'ffmpeg',
            '-framerate', '30',
            '-i', '/tmp/frame_%d.png',
            '-i', narration_path,
            '-c:v', 'libx264',
            '-c:a', 'aac',
            '-shortest',
            '/tmp/output.mp4'
        ]
    else:
        cmd = [
            'ffmpeg',
            '-framerate', '30',
            '-i', '/tmp/frame_%d.png',
            '-c:v', 'libx264',
            '/tmp/output.mp4'
        ]
    
    subprocess.run(cmd, check=True)
    
    return '/tmp/output.mp4'
```

### 3.7 Ressources estimées

| Ressource | Estimation | Justification |
|-----------|------------|---------------|
| **CPU** | 10-20% par rendu | Génération images légère, FFmpeg optimisé |
| **RAM** | 1-2 Go par rendu | Pillow + FFmpeg sont légers |
| **Stockage** | 50-100 Mo temporaire | Images PNG + audio + MP4 final |
| **Temps de rendu** | 10-30 secondes | 4 scènes simples, 30 fps |

---

## PARTIE 4 – STORYBOARD FINAL

### 4.1 Architecture obligatoire

```
Storyboard
  ↓
Scenes
  ↓
Blocks
```

### 4.2 Structure JSON

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T14:00:00Z",
  "created_by": "user_id",
  "subject": "Photosynthèse",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "tts",
  "export_settings": {
    "format": "mp4",
    "resolution": {
      "width": 1080,
      "height": 1920
    },
    "frame_rate": 30
  },
  "scenes": [
    {
      "id": "scene_001",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "blocks": []
    }
  ]
}
```

### 4.3 Blocs V1 autorisés

| Type | Description |
|------|-------------|
| title | Titre principal |
| paragraph | Paragraphe de texte |
| formula | Formule mathématique (LaTeX) |
| definition | Définition d'un concept |
| exercise | Exercice |
| correction | Correction d'exercice |

### 4.4 Structure des blocs

#### Title

```json
{
  "type": "title",
  "content": "Photosynthèse",
  "style": {
    "font_size": 48,
    "font_weight": "bold",
    "color": "#000000"
  }
}
```

#### Paragraph

```json
{
  "type": "paragraph",
  "content": "La photosynthèse est le processus par lequel les plantes convertissent la lumière en énergie chimique.",
  "style": {
    "font_size": 24,
    "color": "#000000"
  }
}
```

#### Formula

```json
{
  "type": "formula",
  "content": "6CO_2 + 6H_2O \\rightarrow C_6H_{12}O_6 + 6O_2",
  "format": "latex",
  "style": {
    "font_size": 28,
    "color": "#0000FF"
  }
}
```

#### Definition

```json
{
  "type": "definition",
  "term": "Photosynthèse",
  "definition": "Processus par lequel les plantes convertissent la lumière en énergie chimique.",
  "example": "Les feuilles absorbent la lumière solaire pour produire du glucose.",
  "style": {
    "term_color": "#0000FF",
    "definition_color": "#000000",
    "example_color": "#666666"
  }
}
```

#### Exercise

```json
{
  "type": "exercise",
  "question": "Quelle est l'équation de la photosynthèse ?",
  "hint": "Pense aux réactifs et produits",
  "solution": "6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂",
  "style": {
    "question_color": "#000000",
    "hint_color": "#666666",
    "solution_color": "#008000"
  }
}
```

#### Correction

```json
{
  "type": "correction",
  "exercise_id": "exercise_uuid",
  "steps": [
    "Identifiez les réactifs",
    "Identifiez les produits",
    "Équilibrez l'équation"
  ],
  "explanation": "La photosynthèse utilise le CO₂ et l'eau pour produire du glucose et de l'oxygène.",
  "style": {
    "step_number_color": "#0000FF",
    "explanation_color": "#000000"
  }
}
```

### 4.5 Métadonnées V1

| Métadonnée | Description |
|------------|-------------|
| narration_mode | Mode de narration (none, tts, user) |
| renderer | Renderer utilisé (scientific, notebook) |
| theme | Thème utilisé (scientific, notebook) |
| export_settings | Paramètres d'export (format, résolution, frame_rate) |

---

## PARTIE 5 – RENDERERS V1

### 5.1 Renderers minimum

| Renderer | Description |
|----------|-------------|
| notebook | Style cahier avec lignes |
| scientific | Style scientifique |

### 5.2 Renderer Scientific

```json
{
  "id": "scientific",
  "name": "Scientifique",
  "background": {
    "type": "solid",
    "color": "#FFFFFF"
  },
  "text": {
    "primary_color": "#000000",
    "font_family": "Roboto"
  },
  "blocks": {
    "title": {
      "font_size": 48,
      "font_weight": "bold",
      "color": "#000000"
    },
    "paragraph": {
      "font_size": 24,
      "font_weight": "normal",
      "color": "#000000"
    },
    "formula": {
      "font_size": 28,
      "color": "#0000FF"
    },
    "definition": {
      "term_color": "#0000FF",
      "definition_color": "#000000",
      "example_color": "#666666"
    },
    "exercise": {
      "question_color": "#000000",
      "hint_color": "#666666",
      "solution_color": "#008000"
    },
    "correction": {
      "step_number_color": "#0000FF",
      "explanation_color": "#000000"
    }
  }
}
```

### 5.3 Renderer Notebook

```json
{
  "id": "notebook",
  "name": "Cahier",
  "background": {
    "type": "image",
    "image_url": "https://example.com/notebook.png",
    "color": "#FFFFFF"
  },
  "text": {
    "primary_color": "#000000",
    "font_family": "HandwritingFont"
  },
  "blocks": {
    "title": {
      "font_size": 44,
      "font_weight": "bold",
      "color": "#000000"
    },
    "paragraph": {
      "font_size": 22,
      "font_weight": "normal",
      "color": "#000000"
    },
    "formula": {
      "font_size": 26,
      "color": "#0000FF"
    }
  }
}
```

### 5.4 Indépendance contenu/thème

Le contenu (Storyboard JSON) reste indépendant du renderer. Le renderer est appliqué au moment du rendu.

---

## PARTIE 6 – FLUX COMPLET

### 6.1 Flux utilisateur

```
Feed Challenge
  ↓
+
  ↓
Smart Whiteboard IA
  ↓
Sujet
  ↓
Bobodo
  ↓
Storyboard
  ↓
Édition
  ↓
Narration
  ↓
Kamatera Renderer
  ↓
MP4
  ↓
Description
  ↓
Compression existante
  ↓
Publication existante
```

### 6.2 Flux technique

```
Flutter (SmartWhiteboardInputScreen)
  ↓
Bobodo (Edge Function bobodo-chat)
  ↓
Storyboard JSON
  ↓
Flutter (SmartWhiteboardEditorScreen)
  ↓
Édition des blocs
  ↓
Flutter (SmartWhiteboardPreviewScreen)
  ↓
Narration (TTS ou utilisateur)
  ↓
RPC app_whiteboard_create_render_job
  ↓
Supabase (whiteboard_renders)
  ↓
Worker Kamatera (poll)
  ↓
Supabase (whiteboard_projects)
  ↓
Supabase Storage (whiteboard-narrations)
  ↓
Python (Pillow + matplotlib)
  ↓
Images PNG
  ↓
FFmpeg
  ↓
MP4
  ↓
Supabase Storage (whiteboard-renders)
  ↓
Supabase (whiteboard_renders)
  ↓
Flutter (polling)
  ↓
video_publish_screen (existant, PROTÉGÉ)
  ↓
Pipeline Challenge existant
```

---

## PARTIE 7 – RENDERER V1

### 7.1 Architecture validée

```
Storyboard JSON
  ↓
Python
  ↓
Pillow
  ↓
PNG
  ↓
FFmpeg
  ↓
MP4
```

### 7.2 Génération PNG

**Bibliothèques** :
- Pillow : Génération d'images depuis texte
- matplotlib : Génération d'images depuis LaTeX

**Processus** :
1. Parser le Storyboard JSON
2. Pour chaque bloc, générer une image PNG
3. Appliquer le renderer (couleurs, polices)
4. Sauvegarder l'image PNG

### 7.3 Assemblage vidéo

**FFmpeg** :
- Assembler les images PNG en vidéo
- Ajouter la narration audio
- Encoder en MP4 (H.264 + AAC)

**Commande** :
```bash
ffmpeg -framerate 30 -i frame_%d.png -i audio.mp3 -c:v libx264 -c:a aac -shortest output.mp4
```

### 7.4 Ajout narration

**Sources** :
- TTS : Généré côté Flutter (flutter_tts)
- Utilisateur : Enregistré côté Flutter (flutter_sound)

**Upload** :
- Upload vers Supabase Storage (whiteboard-narrations)
- URL stockée dans Storyboard JSON

### 7.5 Sortie MP4

**Format** :
- Codec vidéo : H.264
- Codec audio : AAC
- Résolution : 1080x1920 (9:16)
- Frame rate : 30 fps

**Upload** :
- Upload vers Supabase Storage (whiteboard-renders)
- URL stockée dans whiteboard_renders

---

## PARTIE 8 – PLAN DE DÉVELOPPEMENT

### Étape 1 : Storyboard (1 semaine)

**Objectif** : Définir et valider le format Storyboard JSON

**Tâches** :
- ✅ Schéma JSON déjà défini (SMART_WHITEBOARD_STORYBOARD_SCHEMA.md)
- Validation du schéma avec JSON Schema
- Documentation des types de blocs
- Documentation des renderers

**Livrables** :
- Schéma JSON validé
- Documentation complète

**Validation** : Schéma JSON valide

**Risque** : Faible

---

### Étape 2 : Supabase (1 semaine)

**Objectif** : Créer les tables et RPCs Supabase

**Tâches** :
- Utiliser les RPC Python administrateurs dans `.windsurf` pour vérifier l'état actuel
- Créer les tables (whiteboard_projects, whiteboard_renders)
- Créer les RPCs (7 RPCs)
- Créer les buckets Storage (whiteboard-narrations, whiteboard-renders)
- Créer les RLS policies
- Tester les RPCs via RPC Python administrateur

**Livrables** :
- Tables créées
- RPCs créés
- Buckets créés
- Tests validés

**Validation** : RPCs fonctionnels

**Risque** : Moyen

---

### Étape 3 : Flutter (2 semaines)

**Objectif** : Créer les écrans Flutter pour le Smart Whiteboard

**Tâches** :
- Créer smart_whiteboard_input_screen.dart
- Créer smart_whiteboard_editor_screen.dart
- Créer smart_whiteboard_preview_screen.dart
- Créer whiteboard_block_widget.dart
- Créer SmartWhiteboardProvider
- Créer SmartWhiteboardService
- Créer SmartWhiteboardNarrationService
- Ajouter les routes dans main.dart
- Intégrer avec l'onglet Challenge existant

**Livrables** :
- 3 écrans créés
- 1 widget créé
- 1 provider créé
- 2 services créés
- Intégration validée

**Validation** : Écrans fonctionnels

**Risque** : Moyen

---

### Étape 4 : Bobodo (1 semaine)

**Objectif** : Intégrer Bobodo pour la génération de contenu

**Tâches** :
- Créer le prompt système pour génération Storyboard
- Adapter l'Edge Function bobodo-chat pour générer Storyboard JSON
- Tester la génération de Storyboard depuis sujet
- Valider le format JSON généré

**Livrables** :
- Prompt système validé
- Edge Function adaptée
- Tests validés

**Validation** : Bobodo génère un Storyboard JSON valide

**Risque** : Moyen

---

### Étape 5 : Renderer Kamatera (2 semaines)

**Objectif** : Déployer le renderer sur Kamatera

**Tâches** :
- Utiliser les RPC Python administrateurs dans `.windsurf` pour valider Kamatera
- Déployer le backend Python sur Kamatera
- Créer le moteur de rendu Storyboard (Pillow + matplotlib)
- Créer l'endpoint Storyboard → MP4
- Créer le worker de rendu vidéo
- Configurer Docker Compose sur Kamatera
- Tester le rendu complet
- Optimiser les performances

**Livrables** :
- Backend déployé sur Kamatera
- Moteur de rendu fonctionnel
- Worker fonctionnel
- Tests validés

**Validation** : Rendu Storyboard → MP4 fonctionnel

**Risque** : Élevé

---

### Étape 6 : Intégration pipeline (1 semaine)

**Objectif** : Intégrer le Smart Whiteboard avec le pipeline existant

**Tâches** :
- Intégrer smart_whiteboard_preview_screen.dart avec video_publish_screen.dart
- Passer le MP4 généré au pipeline existant
- Tester le flux complet
- Valider que les parcours Filmer et Importer ne sont pas modifiés

**Livrables** :
- Intégration validée
- Flux complet testé
- Parcours existants non modifiés

**Validation** : Flux complet fonctionnel

**Risque** : Faible

---

### Résumé du plan

| Étape | Durée | Risque | Dépendances |
|-------|-------|--------|-------------|
| Étape 1 – Storyboard | 1 semaine | Faible | Aucune |
| Étape 2 – Supabase | 1 semaine | Moyen | Étape 1 |
| Étape 3 – Flutter | 2 semaines | Moyen | Étape 2 |
| Étape 4 – Bobodo | 1 semaine | Moyen | Étape 1 |
| Étape 5 – Renderer Kamatera | 2 semaines | Élevé | Étape 2 |
| Étape 6 – Intégration pipeline | 1 semaine | Faible | Étape 3, 5 |
| **Total** | **8 semaines** | **Moyen** | **Séquentiel** |

---

## OBJECTIF FINAL

Ajouter une troisième option dans le Feed Challenge :

```
Filmer

Importer une vidéo

Smart Whiteboard IA
```

Sans modifier le comportement existant des deux premiers parcours.

Le seul résultat visible pour l'utilisateur doit être l'apparition d'un nouveau mode de création de contenu pédagogique piloté par Bobodo, Flutter, Supabase et Kamatera Cloud.

---

**Fin du document**
