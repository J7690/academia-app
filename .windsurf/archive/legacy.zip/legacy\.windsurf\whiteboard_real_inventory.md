# WHITEBOARD REAL INVENTORY

**Source**: pg_proc (catalogue système PostgreSQL)
**Date**: 2026-06-25
**Nombre total de fonctions**: 43

---

## FONCTIONS TRIGGER (CONSERVER)

### app.update_whiteboard_projects_updated_at

**SCHEMA**: app
**FUNCTION**: update_whiteboard_projects_updated_at
**ARGUMENTS**: (vide)
**DECISION**: KEEP
**JUSTIFICATION**: Fonction trigger pour updated_at sur whiteboard_projects

---

### app.whiteboard_ai_generations_updated_at

**SCHEMA**: app
**FUNCTION**: whiteboard_ai_generations_updated_at
**ARGUMENTS**: (vide)
**DECISION**: KEEP
**JUSTIFICATION**: Fonction trigger pour updated_at sur whiteboard_ai_generations

---

### app.whiteboard_projects_updated_at

**SCHEMA**: app
**FUNCTION**: whiteboard_projects_updated_at
**ARGUMENTS**: (vide)
**DECISION**: KEEP
**JUSTIFICATION**: Fonction trigger pour updated_at sur whiteboard_projects

---

## FONCTIONS WORKER (CONSERVER DANS PUBLIC)

### app.app_whiteboard_fetch_queued_jobs

**SCHEMA**: app
**FUNCTION**: app_whiteboard_fetch_queued_jobs
**ARGUMENTS**: p_limit integer
**DECISION**: DELETE
**JUSTIFICATION**: Version préfixée "app_" dans schéma app, doublon de public.whiteboard_fetch_queued_jobs

---

### app.whiteboard_fetch_queued_jobs

**SCHEMA**: app
**FUNCTION**: whiteboard_fetch_queued_jobs
**ARGUMENTS**: p_limit integer
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, doublon de public.whiteboard_fetch_queued_jobs

---

### public.whiteboard_fetch_queued_jobs

**SCHEMA**: public
**FUNCTION**: whiteboard_fetch_queued_jobs
**ARGUMENTS**: p_limit integer
**DECISION**: KEEP
**JUSTIFICATION**: Version officielle dans schéma public pour Worker Python

---

### app.app_whiteboard_mark_done

**SCHEMA**: app
**FUNCTION**: app_whiteboard_mark_done
**ARGUMENTS**: p_job_id uuid, p_video_url text, p_duration_ms integer
**DECISION**: DELETE
**JUSTIFICATION**: Version préfixée "app_" dans schéma app, doublon de public.whiteboard_mark_done

---

### app.whiteboard_mark_done

**SCHEMA**: app
**FUNCTION**: whiteboard_mark_done
**ARGUMENTS**: p_job_id uuid, p_video_url text, p_duration_ms integer
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, doublon de public.whiteboard_mark_done

---

### public.whiteboard_mark_done

**SCHEMA**: public
**FUNCTION**: whiteboard_mark_done
**ARGUMENTS**: p_job_id uuid, p_video_url text, p_duration_ms integer
**DECISION**: KEEP
**JUSTIFICATION**: Version officielle dans schéma public pour Worker Python

---

### app.app_whiteboard_mark_failed

**SCHEMA**: app
**FUNCTION**: app_whiteboard_mark_failed
**ARGUMENTS**: p_job_id uuid, p_error_message text
**DECISION**: DELETE
**JUSTIFICATION**: Version préfixée "app_" dans schéma app, doublon de public.whiteboard_mark_failed

---

### app.whiteboard_mark_failed

**SCHEMA**: app
**FUNCTION**: whiteboard_mark_failed
**ARGUMENTS**: p_job_id uuid, p_error_message text
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, doublon de public.whiteboard_mark_failed

---

### public.whiteboard_mark_failed

**SCHEMA**: public
**FUNCTION**: whiteboard_mark_failed
**ARGUMENTS**: p_job_id uuid, p_error_message text
**DECISION**: KEEP
**JUSTIFICATION**: Version officielle dans schéma public pour Worker Python

---

### app.app_whiteboard_mark_processing

**SCHEMA**: app
**FUNCTION**: app_whiteboard_mark_processing
**ARGUMENTS**: p_job_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version préfixée "app_" dans schéma app, doublon de public.whiteboard_mark_processing

---

### app.whiteboard_mark_processing

**SCHEMA**: app
**FUNCTION**: whiteboard_mark_processing
**ARGUMENTS**: p_job_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, doublon de public.whiteboard_mark_processing

---

### public.whiteboard_mark_processing

**SCHEMA**: public
**FUNCTION**: whiteboard_mark_processing
**ARGUMENTS**: p_job_id uuid
**DECISION**: KEEP
**JUSTIFICATION**: Version officielle dans schéma public pour Worker Python

---

### public.whiteboard_get_any_student_id

**SCHEMA**: public
**FUNCTION**: whiteboard_get_any_student_id
**ARGUMENTS**: (vide)
**DECISION**: KEEP
**JUSTIFICATION**: Fonction utilitaire pour Worker Python

---

## FONCTIONS FLUTTER - whiteboard_create_project

### app.app_whiteboard_create_project

**SCHEMA**: app
**FUNCTION**: app_whiteboard_create_project
**ARGUMENTS**: p_student_id uuid, p_subject character varying, p_renderer_id character varying, p_theme_id character varying, p_narration_mode character varying, p_storyboard_json jsonb
**DECISION**: DELETE
**JUSTIFICATION**: Version préfixée "app_" dans schéma app, doublon

---

### app.whiteboard_create_project (version 1)

**SCHEMA**: app
**FUNCTION**: whiteboard_create_project
**ARGUMENTS**: p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec p_student_id en dernier, ordre non standard

---

### app.whiteboard_create_project (version 2)

**SCHEMA**: app
**FUNCTION**: whiteboard_create_project
**ARGUMENTS**: p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app sans p_student_id, ne correspond pas au contrat Flutter

---

### public.whiteboard_create_project (version 1)

**SCHEMA**: public
**FUNCTION**: whiteboard_create_project
**ARGUMENTS**: p_student_id uuid, p_subject character varying, p_renderer_id character varying, p_theme_id character varying, p_narration_mode character varying, p_storyboard_json jsonb
**DECISION**: DELETE
**JUSTIFICATION**: Version avec character varying au lieu de text, type non standard

---

### public.whiteboard_create_project (version 2)

**SCHEMA**: public
**FUNCTION**: whiteboard_create_project
**ARGUMENTS**: p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version avec p_student_id en dernier, ordre non standard

---

**CONCLUSION**: AUCUNE version de whiteboard_create_project ne correspond exactement au contrat Flutter. Il faut créer une nouvelle version conforme.

---

## FONCTIONS FLUTTER - whiteboard_create_render_job

### app.whiteboard_create_render_job (version 1)

**SCHEMA**: app
**FUNCTION**: whiteboard_create_render_job
**ARGUMENTS**: p_project_id uuid, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec p_student_id, ne correspond pas au contrat Flutter

---

### app.whiteboard_create_render_job (version 2)

**SCHEMA**: app
**FUNCTION**: whiteboard_create_render_job
**ARGUMENTS**: p_project_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, ne correspond pas au contrat Flutter (nécessite wrapper public)

---

### public.whiteboard_create_render_job

**SCHEMA**: public
**FUNCTION**: whiteboard_create_render_job
**ARGUMENTS**: p_project_id uuid, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version avec p_student_id, ne correspond pas au contrat Flutter

---

**CONCLUSION**: Aucune version de whiteboard_create_render_job ne correspond exactement au contrat Flutter. Il faut créer une nouvelle version conforme.

---

## FONCTIONS FLUTTER - whiteboard_delete_project

### app.whiteboard_delete_project (version 1)

**SCHEMA**: app
**FUNCTION**: whiteboard_delete_project
**ARGUMENTS**: p_project_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, ne correspond pas au contrat Flutter (nécessite wrapper public)

---

### app.whiteboard_delete_project (version 2)

**SCHEMA**: app
**FUNCTION**: whiteboard_delete_project
**ARGUMENTS**: p_project_id uuid, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec p_student_id, ne correspond pas au contrat Flutter

---

### public.whiteboard_delete_project

**SCHEMA**: public
**FUNCTION**: whiteboard_delete_project
**ARGUMENTS**: p_project_id uuid, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version avec p_student_id, ne correspond pas au contrat Flutter

---

**CONCLUSION**: Aucune version de whiteboard_delete_project ne correspond exactement au contrat Flutter. Il faut créer une nouvelle version conforme.

---

## FONCTIONS FLUTTER - whiteboard_get_project

### app.whiteboard_get_project (version 1)

**SCHEMA**: app
**FUNCTION**: whiteboard_get_project
**ARGUMENTS**: p_project_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, ne correspond pas au contrat Flutter (nécessite wrapper public)

---

### app.whiteboard_get_project (version 2)

**SCHEMA**: app
**FUNCTION**: whiteboard_get_project
**ARGUMENTS**: p_project_id uuid, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec p_student_id, ne correspond pas au contrat Flutter

---

### public.whiteboard_get_project

**SCHEMA**: public
**FUNCTION**: whiteboard_get_project
**ARGUMENTS**: p_project_id uuid, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version avec p_student_id, ne correspond pas au contrat Flutter

---

**CONCLUSION**: Aucune version de whiteboard_get_project ne correspond exactement au contrat Flutter. Il faut créer une nouvelle version conforme.

---

## FONCTIONS FLUTTER - whiteboard_get_render_status

### app.whiteboard_get_render_status (version 1)

**SCHEMA**: app
**FUNCTION**: whiteboard_get_render_status
**ARGUMENTS**: p_render_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, ne correspond pas au contrat Flutter (nécessite wrapper public)

---

### app.whiteboard_get_render_status (version 2)

**SCHEMA**: app
**FUNCTION**: whiteboard_get_render_status
**ARGUMENTS**: p_render_id uuid, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec p_student_id, ne correspond pas au contrat Flutter

---

### public.whiteboard_get_render_status

**SCHEMA**: public
**FUNCTION**: whiteboard_get_render_status
**ARGUMENTS**: p_render_id uuid, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version avec p_student_id, ne correspond pas au contrat Flutter

---

**CONCLUSION**: Aucune version de whiteboard_get_render_status ne correspond exactement au contrat Flutter. Il faut créer une nouvelle version conforme.

---

## FONCTIONS FLUTTER - whiteboard_list_projects

### app.whiteboard_list_projects (version 1)

**SCHEMA**: app
**FUNCTION**: whiteboard_list_projects
**ARGUMENTS**: p_student_id uuid, p_status text
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec p_student_id, ne correspond pas au contrat Flutter

---

### app.whiteboard_list_projects (version 2)

**SCHEMA**: app
**FUNCTION**: whiteboard_list_projects
**ARGUMENTS**: p_status text, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec p_student_id, ordre inversé, ne correspond pas au contrat Flutter

---

### app.whiteboard_list_projects (version 3)

**SCHEMA**: app
**FUNCTION**: whiteboard_list_projects
**ARGUMENTS**: p_status text
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, ne correspond pas au contrat Flutter (nécessite wrapper public)

---

### app.whiteboard_list_projects (version 4)

**SCHEMA**: app
**FUNCTION**: whiteboard_list_projects
**ARGUMENTS**: p_status character varying
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec character varying, type non standard

---

### public.whiteboard_list_projects (version 1)

**SCHEMA**: public
**FUNCTION**: whiteboard_list_projects
**ARGUMENTS**: p_status character varying
**DECISION**: DELETE
**JUSTIFICATION**: Version avec character varying, type non standard

---

### public.whiteboard_list_projects (version 2)

**SCHEMA**: public
**FUNCTION**: whiteboard_list_projects
**ARGUMENTS**: p_status text, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version avec p_student_id, ne correspond pas au contrat Flutter

---

**CONCLUSION**: Aucune version de whiteboard_list_projects ne correspond exactement au contrat Flutter. Il faut créer une nouvelle version conforme.

---

## FONCTIONS FLUTTER - whiteboard_update_project

### app.whiteboard_update_project (version 1)

**SCHEMA**: app
**FUNCTION**: whiteboard_update_project
**ARGUMENTS**: p_project_id uuid, p_subject character varying, p_status character varying, p_renderer_id character varying, p_theme_id character varying, p_narration_mode character varying, p_storyboard_json jsonb
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec character varying, type non standard

---

### app.whiteboard_update_project (version 2)

**SCHEMA**: app
**FUNCTION**: whiteboard_update_project
**ARGUMENTS**: p_project_id uuid, p_subject text, p_status text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app, ne correspond pas au contrat Flutter (nécessite wrapper public)

---

### app.whiteboard_update_project (version 3)

**SCHEMA**: app
**FUNCTION**: whiteboard_update_project
**ARGUMENTS**: p_project_id uuid, p_subject text, p_status text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version dans schéma app avec p_student_id, ne correspond pas au contrat Flutter

---

### public.whiteboard_update_project

**SCHEMA**: public
**FUNCTION**: whiteboard_update_project
**ARGUMENTS**: p_project_id uuid, p_subject text, p_status text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid
**DECISION**: DELETE
**JUSTIFICATION**: Version avec p_student_id, ne correspond pas au contrat Flutter

---

**CONCLUSION**: Aucune version de whiteboard_update_project ne correspond exactement au contrat Flutter. Il faut créer une nouvelle version conforme.

---

## RÉSUMÉ

**Total fonctions**: 43
**Fonctions trigger à conserver**: 3
**Fonctions worker à conserver**: 5
**Fonctions Flutter à supprimer**: 35 (aucune ne correspond au contrat)
**Fonctions Flutter à créer**: 7 (nouvelles versions conformes au contrat)

**Liste KEEP**:
1. app.update_whiteboard_projects_updated_at
2. app.whiteboard_ai_generations_updated_at
3. app.whiteboard_projects_updated_at
4. public.whiteboard_fetch_queued_jobs
5. public.whiteboard_mark_done
6. public.whiteboard_mark_failed
7. public.whiteboard_mark_processing
8. public.whiteboard_get_any_student_id

**Liste DELETE**: 35 fonctions (toutes les versions non conformes du contrat Flutter)

**Action requise**:
1. Supprimer les 35 fonctions non conformes
2. Créer les 7 nouvelles RPCs Flutter conformes au contrat
