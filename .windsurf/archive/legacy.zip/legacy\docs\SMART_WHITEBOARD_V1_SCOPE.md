# SMART WHITEBOARD IA V1 – PÉRIMÈTRE

**Version** : 1.0  
**Date** : 23 Juin 2026  
**Mode** : LECTURE SEULE  
**Objectif** : Définir précisément le périmètre V1

---

## PRINCIPE

La V1 est un MVP minimal.

Tout élément non indispensable est **EXCLU**.

Les fonctionnalités V2, V3, V4, V5 ne sont **PAS** incluses.

---

## 1. ÉCRANS EXACTS DE LA V1

### 1.1 Écran 1 : Smart Whiteboard Input

**Fichier** : `smart_whiteboard_input_screen.dart`

**Fonction** : Saisie du sujet

**Composants** :
- TextField pour saisir le sujet
- Bouton "Générer avec Bobodo"
- Indicateur de chargement

**Action** :
- Appel Bobodo pour générer le Storyboard JSON
- Navigation vers l'écran d'édition

**Exclus** :
- ❌ Sélection de template
- ❌ Sélection de thème
- ❌ Import de contenu existant

---

### 1.2 Écran 2 : Smart Whiteboard Editor

**Fichier** : `smart_whiteboard_editor_screen.dart`

**Fonction** : Édition du contenu généré

**Composants** :
- Liste des blocs générés
- Édition du texte de chaque bloc
- Réorganisation des blocs (drag & drop ou boutons haut/bas)
- Suppression de blocs
- Ajout de blocs (types limités V1)
- Bouton "Prévisualiser"

**Types de blocs ajoutables** :
- title
- paragraph
- formula

**Exclus** :
- ❌ Édition des animations
- ❌ Édition des styles avancés
- ❌ Édition des transitions
- ❌ Édition de la narration

---

### 1.3 Écran 3 : Smart Whiteboard Preview

**Fichier** : `smart_whiteboard_preview_screen.dart`

**Fonction** : Prévisualisation et narration

**Composants** :
- Affichage progressif des blocs (fade_in)
- Bouton "Enregistrer narration"
- Bouton "Utiliser TTS"
- Bouton "Générer MP4"
- Indicateur de progression du rendu

**Actions** :
- Enregistrement audio utilisateur (flutter_sound)
- Génération TTS (flutter_tts)
- Appel RPC pour créer un job de rendu
- Polling du statut de rendu
- Navigation vers l'écran de publication

**Exclus** :
- ❌ Édition du contenu
- ❌ Modification des animations
- ❌ Synchronisation mot par mot
- ❌ Zoom
- ❌ Surlignage

---

## 2. BLOCS EXACTS DE LA V1

### 2.1 Types de blocs V1

| Type | Inclus | Description |
|------|--------|-------------|
| title | ✅ | Titre principal |
| subtitle | ❌ | Sous-titre (exclus V1) |
| paragraph | ✅ | Paragraphe de texte |
| bullet_list | ❌ | Liste à puces (exclus V1) |
| numbered_list | ❌ | Liste numérotée (exclus V1) |
| formula | ✅ | Formule mathématique (LaTeX) |
| image | ❌ | Image (exclus V1) |
| quote | ❌ | Citation (exclus V1) |
| divider | ❌ | Séparateur (exclus V1) |
| definition | ❌ | Définition (exclus V1) |
| theorem | ❌ | Théorème (exclus V1) |
| exercise | ❌ | Exercice (exclus V1) |
| correction | ❌ | Correction (exclus V1) |
| quiz | ❌ | Quiz (exclus V1) |
| important_note | ❌ | Note importante (exclus V1) |
| warning | ❌ | Avertissement (exclus V1) |
| handwriting | ❌ | Écriture manuscrite (V3) |
| code_block | ❌ | Bloc de code (exclus V1) |
| table | ❌ | Tableau (exclus V1) |
| callout | ❌ | Encadré (exclus V1) |
| diagram | ❌ | Diagramme (exclus V1) |

### 2.2 Structure des blocs V1

#### Title

```json
{
  "type": "title",
  "content": "Photosynthèse",
  "style": {
    "font_size": 48,
    "font_weight": "bold",
    "color": "#000000"
  }
}
```

#### Paragraph

```json
{
  "type": "paragraph",
  "content": "La photosynthèse est le processus par lequel les plantes convertissent la lumière en énergie chimique.",
  "style": {
    "font_size": 24,
    "color": "#000000"
  }
}
```

#### Formula

```json
{
  "type": "formula",
  "content": "6CO_2 + 6H_2O \\rightarrow C_6H_{12}O_6 + 6O_2",
  "format": "latex",
  "style": {
    "font_size": 28,
    "color": "#0000FF"
  }
}
```

### 2.3 Propriétés communes V1

```json
{
  "id": "block_uuid",
  "type": "title|paragraph|formula",
  "content": "Contenu",
  "order": 0,
  "visible": true,
  "animation": {
    "type": "fade_in",
    "duration_ms": 500
  },
  "position": {
    "x": 0.5,
    "y": 0.1
  },
  "style": {
    "font_size": 24,
    "color": "#000000"
  }
}
```

**Exclus** :
- ❌ keyframes
- ❌ transform (scale, rotate, opacity)
- ❌ highlight
- ❌ zoom

---

## 3. ANIMATIONS EXACTES DE LA V1

### 3.1 Types d'animations V1

| Animation | Inclus | Description |
|-----------|--------|-------------|
| fade_in | ✅ | Apparition en fondu |
| fade_out | ❌ | Disparition en fondu (exclus V1) |
| slide_up | ❌ | Glissement vers le haut (exclus V1) |
| slide_down | ❌ | Glissement vers le bas (exclus V1) |
| slide_left | ❌ | Glissement vers la gauche (exclus V1) |
| slide_right | ❌ | Glissement vers la droite (exclus V1) |
| zoom_in | ❌ | Zoom avant (exclus V1) |
| zoom_out | ❌ | Zoom arrière (exclus V1) |
| typewriter | ❌ | Effet machine à écrire (exclus V1) |
| bounce | ❌ | Rebond (exclus V1) |
| elastic | ❌ | Élastique (exclus V1) |
| write_progressive | ❌ | Écriture progressive (V3) |
| stroke_draw | ❌ | Dessin de trait (V3) |
| word_by_word | ❌ | Mot par mot (V5) |
| character_by_character | ❌ | Caractère par caractère (V5) |
| sync_to_audio | ❌ | Synchronisation audio (V5) |

### 3.2 Structure de l'animation V1

```json
{
  "type": "fade_in",
  "duration_ms": 500,
  "delay_ms": 0,
  "easing": "ease_in_out"
}
```

**Exclus** :
- ❌ iterations
- ❌ direction
- ❌ fill_mode
- ❌ custom_params

---

## 4. RENDERERS EXACTS DE LA V1

### 4.1 Renderers V1

| Renderer | Inclus | Description |
|----------|--------|-------------|
| notebook | ❌ | Style cahier (exclus V1) |
| scientific | ✅ | Style scientifique |
| blackboard | ❌ | Style tableau noir (exclus V1) |
| minimal | ❌ | Style minimaliste (exclus V1) |

### 4.2 Renderer Scientific V1

```json
{
  "id": "scientific",
  "name": "Scientifique",
  "background": {
    "type": "solid",
    "color": "#FFFFFF"
  },
  "text": {
    "primary_color": "#000000",
    "font_family": "Roboto"
  },
  "blocks": {
    "title": {
      "font_size": 48,
      "font_weight": "bold",
      "color": "#000000"
    },
    "paragraph": {
      "font_size": 24,
      "font_weight": "normal",
      "color": "#000000"
    },
    "formula": {
      "font_size": 28,
      "color": "#0000FF"
    }
  }
}
```

**Exclus** :
- ❌ background image
- ❌ gradient
- ❌ secondary_color
- ❌ accent colors

---

## 5. TABLES SUPABASE EXACTES DE LA V1

### 5.1 Table : whiteboard_projects

```sql
CREATE TABLE app.whiteboard_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES app.students(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  storyboard_json JSONB NOT NULL,
  theme_id TEXT NOT NULL DEFAULT 'scientific',
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

**Colonnes** :
- id
- student_id
- subject
- storyboard_json
- theme_id
- status (draft, completed)
- created_at
- updated_at

**Exclus** :
- ❌ metadata
- ❌ tags
- ❌ shared_with

### 5.2 Table : whiteboard_renders

```sql
CREATE TABLE app.whiteboard_renders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES app.whiteboard_projects(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'queued',
  video_url TEXT,
  duration_ms INTEGER,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);
```

**Colonnes** :
- id
- project_id
- status (queued, processing, done, failed)
- video_url
- duration_ms
- error_message
- created_at
- completed_at

**Exclus** :
- ❌ export_config
- ❌ thumbnail_url
- ❌ metadata

### 5.3 Tables exclues V1

| Table | Exclus | Raison |
|-------|--------|--------|
| whiteboard_scenes | ❌ | Scenes non nécessaires V1 (blocs directement dans storyboard) |
| whiteboard_narrations | ❌ | Narration stockée dans Supabase Storage, pas de table dédiée |

---

## 6. BUCKETS EXACTS DE LA V1

### 6.1 Bucket : whiteboard-narrations

**Rôle** : Stockage des fichiers audio de narration

**Contenu** :
- Fichiers audio TTS (MP3)
- Fichiers audio utilisateur (MP3, WAV)

**Structure** :
```
whiteboard-narrations/
  {project_id}/
    narration.mp3
```

### 6.2 Bucket : whiteboard-renders

**Rôle** : Stockage des MP4 générés

**Contenu** :
- Fichiers MP4 rendus

**Structure** :
```
whiteboard-renders/
  {project_id}/
    render.mp4
```

### 6.3 Buckets exclus V1

| Bucket | Exclus | Raison |
|--------|--------|--------|
| whiteboard-projects | ❌ | Storyboards stockés dans Supabase (JSONB), pas besoin de bucket |

---

## 7. SERVICES FLUTTER EXACTS DE LA V1

### 7.1 Service : SmartWhiteboardService

**Fichier** : `smart_whiteboard_service.dart`

**Fonctions** :
- `generateStoryboard(subject)` : Appel Bobodo pour générer Storyboard JSON
- `createProject(subject, storyboardJson)` : Créer un projet via RPC
- `updateProject(projectId, storyboardJson)` : Mettre à jour un projet via RPC
- `getProject(projectId)` : Récupérer un projet via RPC
- `listProjects(studentId)` : Lister les projets d'un étudiant via RPC
- `deleteProject(projectId)` : Supprimer un projet via RPC

**Exclus** :
- ❌ Gestion des thèmes
- ❌ Gestion des templates
- ❌ Gestion des scènes

### 7.2 Service : SmartWhiteboardNarrationService

**Fichier** : `smart_whiteboard_narration_service.dart`

**Fonctions** :
- `recordNarration()` : Enregistrement audio utilisateur (flutter_sound)
- `generateTTS(text)` : Génération TTS (flutter_tts)
- `uploadNarration(projectId, audioFile)` : Upload audio vers Supabase Storage

**Exclus** :
- ❌ Mixage audio
- ❌ Effets audio
- ❌ Synchronisation audio

### 7.3 Service : SmartWhiteboardRenderService

**Fichier** : `smart_whiteboard_render_service.dart`

**Fonctions** :
- `createRenderJob(projectId)` : Créer un job de rendu via RPC
- `getRenderStatus(renderId)` : Récupérer le statut d'un rendu via RPC
- `pollRenderStatus(renderId)` : Polling du statut de rendu

**Exclus** :
- ❌ Annulation de rendu
- ❌ Priorité de rendu
- ❌ Historique de rendus

### 7.4 Services exclus V1

| Service | Exclus | Raison |
|---------|--------|--------|
| SmartWhiteboardThemeService | ❌ | Thèmes non nécessaires V1 (1 seul renderer) |
| SmartWhiteboardSceneService | ❌ | Scènes non nécessaires V1 |
| SmartWhiteboardAnimationService | ❌ | Animations non éditables V1 |

---

## 8. SERVICES KAMATERA EXACTS DE LA V1

### 8.1 Endpoint : /whiteboard/render

**Fichier** : `whiteboard_renderer.py` (nouveau)

**Fonction** : Rendu Storyboard JSON → MP4

**Paramètres** :
- `project_id` : UUID du projet
- `storyboard_json` : Storyboard JSON
- `narration_url` : URL de la narration audio

**Retour** :
- `video_url` : URL du MP4 généré
- `duration_ms` : Durée du MP4

**Implémentation** :
- Télécharger Storyboard JSON depuis Supabase
- Télécharger narration audio depuis Supabase Storage
- Générer images PNG depuis blocs (Pillow)
- Générer images pour formules LaTeX (matplotlib)
- Assembler images + audio → MP4 (FFmpeg)
- Upload MP4 vers Supabase Storage

**Exclus** :
- ❌ Génération d'animations complexes
- ❌ Génération d'écriture manuscrite
- ❌ Génération de zoom
- ❌ Génération de surlignage

### 8.2 Worker : WhiteboardRenderWorker

**Fichier** : `whiteboard_render_worker.py` (nouveau)

**Fonction** : Polling des jobs de rendu

**Implémentation** :
- Poll `whiteboard_renders` (status=queued)
- Marque job comme processing
- Appel endpoint `/whiteboard/render`
- Met à jour `whiteboard_renders` (status=done, video_url)
- Marque job comme done

**Exclus** :
- ❌ Gestion de priorité
- ❌ Gestion de retry
- ❌ Gestion de timeout

### 8.3 Services exclus V1

| Service | Exclus | Raison |
|---------|--------|--------|
| /whiteboard/generate-tts | ❌ | TTS généré côté Flutter (flutter_tts) |
| /whiteboard/mix-audio | ❌ | Mixage non nécessaire V1 |
| /whiteboard/generate-thumbnail | ❌ | Thumbnails non nécessaires V1 |

---

## 9. FLUX COMPLET DE RENDU

### 9.1 Flux utilisateur

```
1. Écran Input
   ↓
2. Saisir sujet
   ↓
3. Bouton "Générer avec Bobodo"
   ↓
4. Bobodo génère Storyboard JSON
   ↓
5. Écran Editor
   ↓
6. Éditer les blocs (title, paragraph, formula)
   ↓
7. Réorganiser les blocs
   ↓
8. Bouton "Prévisualiser"
   ↓
9. Écran Preview
   ↓
10. Enregistrer narration OU utiliser TTS
    ↓
11. Bouton "Générer MP4"
    ↓
12. RPC app_whiteboard_create_render_job
    ↓
13. Supabase → whiteboard_renders (status=queued)
    ↓
14. Worker Kamatera (poll)
    ↓
15. Worker télécharge Storyboard JSON
    ↓
16. Worker télécharge narration audio
    ↓
17. Python (Pillow) génère images PNG
    ↓
18. Python (matplotlib) génère images LaTeX
    ↓
19. FFmpeg assemble images + audio → MP4
    ↓
20. Worker upload MP4 vers Supabase Storage
    ↓
21. Worker met à jour whiteboard_renders (status=done, video_url)
    ↓
22. Flutter poll le statut de rendu
    ↓
23. Flutter récupère video_url
    ↓
24. Navigation vers video_publish_screen (existant)
    ↓
25. Pipeline Challenge existant (description, compression, publication)
```

### 9.2 Flux technique

```
Flutter
  ↓
RPC app_whiteboard_create_render_job
  ↓
Supabase (whiteboard_renders)
  ↓
Worker Kamatera (poll)
  ↓
Supabase (whiteboard_projects)
  ↓
Supabase Storage (whiteboard-narrations)
  ↓
Python (Pillow + matplotlib)
  ↓
FFmpeg
  ↓
Supabase Storage (whiteboard-renders)
  ↓
Supabase (whiteboard_renders)
  ↓
Flutter
  ↓
video_publish_screen (existant)
  ↓
Pipeline Challenge existant
```

---

## 10. POINTS D'INTÉGRATION AVEC LE PIPELINE CHALLENGE

### 10.1 Point d'intégration unique

**Écran** : `video_publish_screen.dart` (existant, PROTÉGÉ)

**Action** : Passer le MP4 généré à l'écran de description

**Implémentation** :
- Navigation depuis `smart_whiteboard_preview_screen.dart` vers `video_publish_screen.dart`
- Passage du `video_url` via navigation argument
- Le reste du pipeline reste inchangé

### 10.2 Flux d'intégration

```
smart_whiteboard_preview_screen.dart
  ↓
Génération MP4 terminée
  ↓
Navigator.pushNamed(context, '/video-publish', arguments: {'video_url': video_url})
  ↓
video_publish_screen.dart (existant, PROTÉGÉ)
  ↓
Description, hashtags, visibilité
  ↓
Compression Kamatera (existant, PROTÉGÉ)
  ↓
Publication (existant, PROTÉGÉ)
```

### 10.3 Contraintes d'intégration

**Interdictions** :
- ❌ Modifier `video_publish_screen.dart`
- ❌ Modifier `videoasset_upload_service.dart`
- ❌ Modifier les tables Challenge
- ❌ Modifier les RPCs Challenge
- ❌ Modifier les Edge Functions Challenge

**Autorisations** :
- ✅ Passer un `video_url` à `video_publish_screen.dart` via navigation argument
- ✅ Utiliser le pipeline existant tel quel

---

## 11. EXCLUSIONS V1

### 11.1 Fonctionnalités exclues V1

| Fonctionnalité | Version | Raison |
|----------------|---------|--------|
| Écriture manuscrite | V3 | Non indispensable MVP |
| Synchronisation mot par mot | V5 | Non indispensable MVP |
| Zoom intelligent | V4 | Non indispensable MVP |
| Surlignage intelligent | V2 | Non indispensable MVP |
| Main virtuelle | - | Non indispensable MVP |
| Animations complexes (slide, bounce, elastic) | V2+ | Non indispensable MVP |
| Scènes | - | Non indispensable MVP (blocs directs) |
| Thèmes multiples | - | Non indispensable MVP (1 seul renderer) |
| Templates | - | Non indispensable MVP |
| Import de contenu existant | - | Non indispensable MVP |
| Édition des animations | - | Non indispensable MVP |
- Édition des styles avancés | - | Non indispensable MVP |
- Mixage audio | - | Non indispensable MVP |
- Effets audio | - | Non indispensable MVP |
- Thumbnails | - | Non indispensable MVP |
- Historique de rendus | - | Non indispensable MVP |
- Partage de projets | - | Non indispensable MVP |
- Tags | - | Non indispensable MVP |

### 11.2 Composants exclus V1

| Composant | Exclus | Raison |
|-----------|--------|--------|
| whiteboard_scenes (table) | ❌ | Scènes non nécessaires V1 |
| whiteboard_narrations (table) | ❌ | Narration stockée dans Storage |
| whiteboard-projects (bucket) | ❌ | Storyboards stockés dans Supabase |
| SmartWhiteboardThemeService | ❌ | 1 seul renderer V1 |
| SmartWhiteboardSceneService | ❌ | Scènes non nécessaires V1 |
| SmartWhiteboardAnimationService | ❌ | Animations non éditables V1 |
| /whiteboard/generate-tts | ❌ | TTS généré côté Flutter |
| /whiteboard/mix-audio | ❌ | Mixage non nécessaire V1 |
| /whiteboard/generate-thumbnail | ❌ | Thumbnails non nécessaires V1 |

---

## 12. RÉSUMÉ DU PÉRIMÈTRE V1

### 12.1 Écrans (3)
- smart_whiteboard_input_screen.dart
- smart_whiteboard_editor_screen.dart
- smart_whiteboard_preview_screen.dart

### 12.2 Blocs (3)
- title
- paragraph
- formula

### 12.3 Animations (1)
- fade_in

### 12.4 Renderers (1)
- scientific

### 12.5 Tables Supabase (2)
- whiteboard_projects
- whiteboard_renders

### 12.6 Buckets (2)
- whiteboard-narrations
- whiteboard-renders

### 12.7 Services Flutter (3)
- SmartWhiteboardService
- SmartWhiteboardNarrationService
- SmartWhiteboardRenderService

### 12.8 Services Kamatera (2)
- /whiteboard/render (endpoint)
- WhiteboardRenderWorker (worker)

### 12.9 Point d'intégration (1)
- video_publish_screen.dart (existant, PROTÉGÉ)

---

## 13. ESTIMATION DE CHARGE V1

| Composant | Estimation |
|-----------|------------|
| Écrans Flutter | 2 semaines |
| Services Flutter | 1 semaine |
| Tables Supabase | 3 jours |
- RPCs Supabase | 2 jours |
- Buckets Supabase | 1 jour |
- Endpoint Kamatera | 1 semaine |
- Worker Kamatera | 3 jours |
- Intégration pipeline | 2 jours |
- Tests | 3 jours |
| **Total** | **4-5 semaines** |

---

**Fin du document**
