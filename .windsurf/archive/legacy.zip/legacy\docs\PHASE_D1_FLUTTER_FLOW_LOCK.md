# PHASE D.1 – FLUTTER FLOW LOCK

**Date** : 23 Juin 2026  
**Phase** : D.1 – Flutter Flow Lock  
**Mode** : CONCEPTION  
**Objectif** : Verrouiller le flux Flutter complet du Smart Whiteboard avant toute implémentation

---

## DIRECTIVE

**AUCUNE MODIFICATION DU CODE EXISTANT**  
**AUCUN COMMIT**  
**AUCUNE ÉCRITURE D'ÉCRAN**

**Composants PROTÉGÉS** :
- student_challenges_tab.dart
- challenge_camera_capture_screen.dart
- student_challenge_video_editor_screen.dart
- video_publish_screen.dart
- videoasset_upload_service.dart

---

## PARTIE 1 – EXPÉRIENCE UTILISATEUR

### Flux complet

```
1. Clic sur bouton + (Challenge Feed)
   ↓
2. Modal choix (Filmer / Importer / Smart Whiteboard)
   ↓
3. Clic sur "Smart Whiteboard"
   ↓
4. SmartWhiteboardInputScreen
   - Saisie du sujet
   - Sélection du thème (scientific / notebook)
   - Sélection du renderer (scientific / notebook)
   - Sélection du mode narration (none / tts / user_recording)
   ↓
5. Appel Bobodo (Edge Function)
   - Génération du storyboard initial
   - Suggestion de scènes et blocs
   ↓
6. SmartWhiteboardStoryboardEditorScreen
   - Édition des scènes
   - Édition des blocs
   - Réorganisation
   - Ajustement des styles
   ↓
7. SmartWhiteboardNarrationEditorScreen (si narration != none)
   - TTS : sélection voix, génération audio
   - user_recording : enregistrement audio
   ↓
8. SmartWhiteboardPreviewScreen
   - Prévisualisation du storyboard
   - Validation finale
   ↓
9. Création Render Job
   - Envoi du storyboard à Supabase
   - Création du job dans whiteboard_renders
   ↓
10. SmartWhiteboardRenderMonitorScreen
    - Polling du statut de rendu
    - Affichage de la progression
    - Attente du MP4
    ↓
11. Rendu terminé (status = done)
    ↓
12. VideoPublishScreen (réutilisation)
    - Saisie de la description
    - Ajout de hashtags
    - Sélection de la visibilité
    - Publication
    ↓
13. Pipeline existant
    - Compression Kamatera
    - Upload Storage
    - Publication Challenge Feed
```

### Points de décision

**Modal choix** : Filmer / Importer / Smart Whiteboard  
**Narration** : none / tts / user_recording  
**Validation** : Continuer / Modifier / Annuler

---

## PARTIE 2 – ÉCRANS SMART WHITEBOARD

### Écran 1 : SmartWhiteboardInputScreen

**Rôle** : Saisie des paramètres initiaux du projet

**Données d'entrée** : Aucune

**Données de sortie** :
- subject (String)
- theme (ThemeId)
- renderer (RendererId)
- narration_mode (NarrationMode)

**Provider utilisé** : SmartWhiteboardProvider

**Services utilisés** : SmartWhiteboardService

---

### Écran 2 : SmartWhiteboardStoryboardEditorScreen

**Rôle** : Édition du storyboard (scènes et blocs)

**Données d'entrée** :
- storyboard (Storyboard)
- theme (ThemeId)
- renderer (RendererId)

**Données de sortie** :
- storyboard (Storyboard) modifié

**Provider utilisé** : SmartWhiteboardProvider

**Services utilisés** : SmartWhiteboardService

---

### Écran 3 : SmartWhiteboardNarrationEditorScreen

**Rôle** : Édition de la narration

**Données d'entrée** :
- narration_mode (NarrationMode)
- storyboard (Storyboard)

**Données de sortie** :
- narration (Narration)
- audio_url (String) si tts ou user_recording

**Provider utilisé** : SmartWhiteboardProvider

**Services utilisés** : SmartWhiteboardNarrationService

---

### Écran 4 : SmartWhiteboardPreviewScreen

**Rôle** : Prévisualisation et validation du storyboard

**Données d'entrée** :
- storyboard (Storyboard)
- narration (Narration)
- export_settings (ExportSettings)

**Données de sortie** :
- validated (bool)

**Provider utilisé** : SmartWhiteboardProvider

**Services utilisés** : Aucun

---

### Écran 5 : SmartWhiteboardRenderMonitorScreen

**Rôle** : Suivi du rendu vidéo

**Données d'entrée** :
- render_job_id (UUID)

**Données de sortie** :
- render_job (RenderJob)
- video_url (String) si done

**Provider utilisé** : SmartWhiteboardProvider

**Services utilisés** : SmartWhiteboardRenderService

---

## PARTIE 3 – SMARTWHITEBOARDPROVIDER

### États

```dart
enum SmartWhiteboardState {
  idle,
  loading,
  bobodoGenerating,
  editing,
  narrating,
  previewing,
  rendering,
  done,
  error,
}
```

### Méthodes

**Création** :
- `createProject(subject, theme, renderer, narration_mode)` → Future<WhiteboardProject>
- `generateStoryboard(project)` → Future<Storyboard>

**Édition** :
- `addScene(scene)` → void
- `updateScene(scene)` → void
- `deleteScene(sceneId)` → void
- `reorderScenes(sceneIds)` → void
- `addBlock(sceneId, block)` → void
- `updateBlock(sceneId, block)` → void
- `deleteBlock(sceneId, blockId)` → void

**Narration** :
- `generateTTS(text, voice)` → Future<String> (audio_url)
- `recordNarration()` → Future<String> (audio_url)

**Rendu** :
- `createRenderJob(storyboard)` → Future<RenderJob>
- `pollRenderJob(renderJobId)` → Future<RenderJob>

**Suppression** :
- `deleteProject(projectId)` → Future<void>
- `cancelRenderJob(renderJobId)` → Future<void>

### Transitions

```
idle → loading → bobodoGenerating → editing → narrating → previewing → rendering → done
  ↓
error → idle
```

---

## PARTIE 4 – SERVICES FLUTTER

### Service 1 : SmartWhiteboardService

**Responsabilités** :
- CRUD sur whiteboard_projects
- CRUD sur storyboards
- Communication avec Bobodo (Edge Function)

**Dépendances** :
- Supabase client
- Edge Function (prep-tutor-chat ou dédiée)

**RPC utilisées** :
- Aucune (utilise Edge Function)

**Buckets utilisés** :
- Aucun

---

### Service 2 : SmartWhiteboardRenderService

**Responsabilités** :
- Création de Render Jobs
- Polling du statut de rendu
- Récupération du MP4 généré

**Dépendances** :
- Supabase client

**RPC utilisées** :
- whiteboard_fetch_queued_jobs (non utilisé côté Flutter)
- whiteboard_mark_processing (non utilisé côté Flutter)
- whiteboard_mark_done (non utilisé côté Flutter)
- whiteboard_mark_failed (non utilisé côté Flutter)
- app_whiteboard_create_render_job (à créer)
- app_whiteboard_get_render_job (à créer)

**Buckets utilisés** :
- whiteboard-renders

---

### Service 3 : SmartWhiteboardNarrationService

**Responsabilités** :
- Génération TTS
- Upload audio narration
- Gestion des fichiers audio locaux

**Dépendances** :
- Supabase client
- Edge Function (TTS)

**RPC utilisées** :
- Aucune (utilise Edge Function)

**Buckets utilisés** :
- whiteboard-narrations (à créer)

---

## PARTIE 5 – FLUX STORYBOARD

### Étape 1 : Sujet

**Objet** : `subject` (String)

**Action** : Saisie utilisateur

**Validation** : Non vide, longueur minimale 3 caractères

---

### Étape 2 : Bobodo

**Objet** : `subject` (String)

**Action** : Appel Edge Function

**Sortie** : `Storyboard` initial avec scènes et blocs suggérés

**Validation** : Structure conforme au Data Contract

---

### Étape 3 : Storyboard

**Objet** : `Storyboard`

**Action** : Stockage dans provider

**Validation** : Au moins 1 scène, au moins 1 bloc par scène

---

### Étape 4 : Édition

**Objet** : `Storyboard`

**Action** : Modification des scènes et blocs

**Validation** : Structure conforme au Data Contract

---

### Étape 5 : Validation

**Objet** : `Storyboard`

**Action** : Vérification finale avant rendu

**Validation** : Structure conforme, données complètes

---

## PARTIE 6 – FLUX RENDER

### Étape 1 : Storyboard

**Objet** : `Storyboard`

**Action** : Sérialisation JSON

**Validation** : JSON valide

---

### Étape 2 : Render Job

**Objet** : `RenderJob`

**Action** : Création dans Supabase (status = queued)

**Validation** : ID généré, status = queued

---

### Étape 3 : Polling

**Objet** : `RenderJob`

**Action** : Polling toutes les 5 secondes

**États** :
- queued → processing → done
- queued → processing → failed

**Validation** : Status change, progression mise à jour

---

### Étape 4 : MP4

**Objet** : `video_url` (String)

**Action** : Récupération depuis Supabase

**Validation** : URL valide, fichier accessible

---

### Étape 5 : VideoPublishScreen

**Objet** : `video_url` (String)

**Action** : Passage à VideoPublishScreen

**Validation** : URL non vide

---

### Gestion des erreurs

**Échec render** :
- Comportement : Afficher message d'erreur, proposer de réessayer
- Message utilisateur : "Le rendu a échoué. Veuillez réessayer."
- Reprise : Bouton "Réessayer" recrée le Render Job

**Timeout Kamatera** :
- Comportement : Afficher message d'erreur après 5 minutes
- Message utilisateur : "Le rendu prend trop de temps. Veuillez réessayer."
- Reprise : Bouton "Réessayer" recrée le Render Job

---

## PARTIE 7 – GESTION DES ERREURS

### Cas 1 : Bobodo échoue

**Comportement** :
- Afficher message d'erreur
- Proposer de réessayer
- Permettre de créer un storyboard manuellement

**Message utilisateur** : "La génération automatique a échoué. Vous pouvez créer votre storyboard manuellement."

**Reprise** :
- Bouton "Réessayer" → relance Bobodo
- Bouton "Manuel" → ouvre StoryboardEditor avec storyboard vide

---

### Cas 2 : Réseau coupé

**Comportement** :
- Afficher message d'erreur
- Sauvegarder localement le storyboard
- Permettre de continuer hors ligne

**Message utilisateur** : "Connexion perdue. Votre storyboard est sauvegardé localement."

**Reprise** :
- Sauvegarde locale
- Synchronisation automatique au retour de connexion

---

### Cas 3 : Render échoue

**Comportement** :
- Afficher message d'erreur avec détails
- Proposer de réessayer
- Permettre de modifier le storyboard

**Message utilisateur** : "Le rendu a échoué : {error_message}. Veuillez vérifier votre storyboard et réessayer."

**Reprise** :
- Bouton "Réessayer" → recrée le Render Job
- Bouton "Modifier" → retour au StoryboardEditor

---

### Cas 4 : Timeout Kamatera

**Comportement** :
- Afficher message d'erreur après 5 minutes
- Proposer de réessayer
- Contacter support si persiste

**Message utilisateur** : "Le rendu prend trop de temps. Veuillez réessayer ou contacter le support."

**Reprise** :
- Bouton "Réessayer" → recrée le Render Job
- Bouton "Support" → ouvre écran support

---

### Cas 5 : Upload narration échoue

**Comportement** :
- Afficher message d'erreur
- Proposer de réessayer
- Permettre de changer de mode narration

**Message utilisateur** : "L'upload de la narration a échoué. Veuillez réessayer."

**Reprise** :
- Bouton "Réessayer" → relance l'upload
- Bouton "Changer de mode" → retour au NarrationEditor

---

## PARTIE 8 – NAVIGATION FLUTTER

### Écran 1 : Challenge Feed

**Action** : Clic sur bouton +

**Navigation** : showModalBottomSheet (Modal choix)

---

### Écran 2 : Modal choix

**Action** : Clic sur "Smart Whiteboard"

**Navigation** : Navigator.push (SmartWhiteboardInputScreen)

---

### Écran 3 : SmartWhiteboardInputScreen

**Action** : Clic sur "Continuer"

**Navigation** : Navigator.push (SmartWhiteboardStoryboardEditorScreen)

**Action** : Clic sur "Annuler"

**Navigation** : Navigator.pop

---

### Écran 4 : SmartWhiteboardStoryboardEditorScreen

**Action** : Clic sur "Narration"

**Navigation** : Navigator.push (SmartWhiteboardNarrationEditorScreen)

**Action** : Clic sur "Prévisualiser"

**Navigation** : Navigator.push (SmartWhiteboardPreviewScreen)

**Action** : Clic sur "Retour"

**Navigation** : Navigator.pop

---

### Écran 5 : SmartWhiteboardNarrationEditorScreen

**Action** : Clic sur "Terminer"

**Navigation** : Navigator.pop (retour StoryboardEditor)

**Action** : Clic sur "Annuler"

**Navigation** : Navigator.pop (retour StoryboardEditor)

---

### Écran 6 : SmartWhiteboardPreviewScreen

**Action** : Clic sur "Rendre"

**Navigation** : Navigator.push (SmartWhiteboardRenderMonitorScreen)

**Action** : Clic sur "Modifier"

**Navigation** : Navigator.pop (retour StoryboardEditor)

**Action** : Clic sur "Annuler"

**Navigation** : Navigator.popUntil (retour Challenge Feed)

---

### Écran 7 : SmartWhiteboardRenderMonitorScreen

**Action** : Rendu terminé (status = done)

**Navigation** : Navigator.pushReplacement (VideoPublishScreen)

**Action** : Clic sur "Annuler"

**Navigation** : Navigator.popUntil (retour Challenge Feed)

---

### Écran 8 : VideoPublishScreen

**Action** : Publication réussie

**Navigation** : Navigator.popUntil (retour Challenge Feed)

**Action** : Clic sur "Annuler"

**Navigation** : Navigator.pop (retour RenderMonitorScreen)

---

## PARTIE 9 – MATRICE DE DÉPENDANCES

### Écran ↔ Provider

| Écran | Provider |
|-------|----------|
| SmartWhiteboardInputScreen | SmartWhiteboardProvider |
| SmartWhiteboardStoryboardEditorScreen | SmartWhiteboardProvider |
| SmartWhiteboardNarrationEditorScreen | SmartWhiteboardProvider |
| SmartWhiteboardPreviewScreen | SmartWhiteboardProvider |
| SmartWhiteboardRenderMonitorScreen | SmartWhiteboardProvider |

---

### Provider ↔ Service

| Provider | Service |
|----------|---------|
| SmartWhiteboardProvider | SmartWhiteboardService |
| SmartWhiteboardProvider | SmartWhiteboardRenderService |
| SmartWhiteboardProvider | SmartWhiteboardNarrationService |

---

### Service ↔ RPC

| Service | RPC |
|---------|-----|
| SmartWhiteboardService | Aucune (Edge Function) |
| SmartWhiteboardRenderService | app_whiteboard_create_render_job (à créer) |
| SmartWhiteboardRenderService | app_whiteboard_get_render_job (à créer) |
| SmartWhiteboardNarrationService | Aucune (Edge Function) |

---

### Service ↔ Bucket

| Service | Bucket |
|---------|--------|
| SmartWhiteboardService | Aucun |
| SmartWhiteboardRenderService | whiteboard-renders |
| SmartWhiteboardNarrationService | whiteboard-narrations (à créer) |

---

## PARTIE 10 – LOTS FLUTTER

### Lot D.2 : Infrastructure

**Ordre** : 1

**Contenu** :
- SmartWhiteboardProvider
- SmartWhiteboardService
- SmartWhiteboardRenderService
- SmartWhiteboardNarrationService

**Dépendances** : Aucune

---

### Lot D.3 : Écrans de base

**Ordre** : 2

**Contenu** :
- SmartWhiteboardInputScreen
- SmartWhiteboardStoryboardEditorScreen
- SmartWhiteboardNarrationEditorScreen

**Dépendances** : Lot D.2

---

### Lot D.4 : Écrans avancés

**Ordre** : 3

**Contenu** :
- SmartWhiteboardPreviewScreen
- SmartWhiteboardRenderMonitorScreen

**Dépendances** : Lot D.3

---

### Lot D.5 : Intégration

**Ordre** : 4

**Contenu** :
- Modal choix (modification student_challenges_tab.dart)
- Navigation complète
- Tests E2E

**Dépendances** : Lot D.4

---

## CONCLUSION

### Résumé

**Expérience utilisateur** : Définie de bout à bout  
**Écrans** : 5 écrans définis avec rôles, entrées, sorties  
**Provider** : SmartWhiteboardProvider avec états et méthodes  
**Services** : 3 services définis avec responsabilités  
**Flux Storyboard** : 5 étapes définies  
**Flux Render** : 5 étapes définies  
**Gestion des erreurs** : 5 cas définis  
**Navigation** : 8 écrans avec navigation définie  
**Matrice de dépendances** : Complète  
**Lots Flutter** : 4 lots avec ordre d'exécution

### Critère de réussite

**✅ Être capable de construire tous les écrans Flutter sans réinterpréter l'architecture et sans revenir modifier le Backend ou le Renderer.**

---

**Fin du Flutter Flow Lock**
