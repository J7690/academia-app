-- CLEANUP WHITEBOARD DUPLICATES - REAL
-- Date: 2026-06-25
-- Source: pg_proc (43 fonctions trouvées)
-- Purpose: Supprimer les 35 fonctions whiteboard non conformes au contrat Flutter

-- ============================================
-- FONCTIONS TRIGGER À CONSERVER (3)
-- ============================================
-- app.update_whiteboard_projects_updated_at
-- app.whiteboard_ai_generations_updated_at
-- app.whiteboard_projects_updated_at

-- ============================================
-- FONCTIONS WORKER À CONSERVER (5)
-- ============================================
-- public.whiteboard_fetch_queued_jobs
-- public.whiteboard_mark_done
-- public.whiteboard_mark_failed
-- public.whiteboard_mark_processing
-- public.whiteboard_get_any_student_id

-- ============================================
-- FONCTIONS À SUPPRIMER (35)
-- ============================================

-- Schéma app - Versions préfixées "app_"
DROP FUNCTION IF EXISTS app.app_whiteboard_create_project CASCADE;
DROP FUNCTION IF EXISTS app.app_whiteboard_fetch_queued_jobs CASCADE;
DROP FUNCTION IF EXISTS app.app_whiteboard_mark_done CASCADE;
DROP FUNCTION IF EXISTS app.app_whiteboard_mark_failed CASCADE;
DROP FUNCTION IF EXISTS app.app_whiteboard_mark_processing CASCADE;

-- Schéma app - whiteboard_create_project (3 versions)
DROP FUNCTION IF EXISTS app.whiteboard_create_project(p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_create_project(p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb) CASCADE;

-- Schéma app - whiteboard_create_render_job (2 versions)
DROP FUNCTION IF EXISTS app.whiteboard_create_render_job(p_project_id uuid, p_student_id uuid) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_create_render_job(p_project_id uuid) CASCADE;

-- Schéma app - whiteboard_delete_project (2 versions)
DROP FUNCTION IF EXISTS app.whiteboard_delete_project(p_project_id uuid) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_delete_project(p_project_id uuid, p_student_id uuid) CASCADE;

-- Schéma app - whiteboard_fetch_queued_jobs
DROP FUNCTION IF EXISTS app.whiteboard_fetch_queued_jobs(p_limit integer) CASCADE;

-- Schéma app - whiteboard_get_project (2 versions)
DROP FUNCTION IF EXISTS app.whiteboard_get_project(p_project_id uuid) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_get_project(p_project_id uuid, p_student_id uuid) CASCADE;

-- Schéma app - whiteboard_get_render_status (2 versions)
DROP FUNCTION IF EXISTS app.whiteboard_get_render_status(p_render_id uuid) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_get_render_status(p_render_id uuid, p_student_id uuid) CASCADE;

-- Schéma app - whiteboard_list_projects (4 versions)
DROP FUNCTION IF EXISTS app.whiteboard_list_projects(p_student_id uuid, p_status text) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_list_projects(p_status text, p_student_id uuid) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_list_projects(p_status text) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_list_projects(p_status character varying) CASCADE;

-- Schéma app - whiteboard_mark_done
DROP FUNCTION IF EXISTS app.whiteboard_mark_done(p_job_id uuid, p_video_url text, p_duration_ms integer) CASCADE;

-- Schéma app - whiteboard_mark_failed
DROP FUNCTION IF EXISTS app.whiteboard_mark_failed(p_job_id uuid, p_error_message text) CASCADE;

-- Schéma app - whiteboard_mark_processing
DROP FUNCTION IF EXISTS app.whiteboard_mark_processing(p_job_id uuid) CASCADE;

-- Schéma app - whiteboard_update_project (3 versions)
DROP FUNCTION IF EXISTS app.whiteboard_update_project(p_project_id uuid, p_subject character varying, p_status character varying, p_renderer_id character varying, p_theme_id character varying, p_narration_mode character varying, p_storyboard_json jsonb) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_update_project(p_project_id uuid, p_subject text, p_status text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb) CASCADE;
DROP FUNCTION IF EXISTS app.whiteboard_update_project(p_project_id uuid, p_subject text, p_status text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid) CASCADE;

-- Schéma public - whiteboard_create_project (2 versions)
DROP FUNCTION IF EXISTS public.whiteboard_create_project(p_student_id uuid, p_subject character varying, p_renderer_id character varying, p_theme_id character varying, p_narration_mode character varying, p_storyboard_json jsonb) CASCADE;
DROP FUNCTION IF EXISTS public.whiteboard_create_project(p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid) CASCADE;

-- Schéma public - whiteboard_create_render_job
DROP FUNCTION IF EXISTS public.whiteboard_create_render_job(p_project_id uuid, p_student_id uuid) CASCADE;

-- Schéma public - whiteboard_delete_project
DROP FUNCTION IF EXISTS public.whiteboard_delete_project(p_project_id uuid, p_student_id uuid) CASCADE;

-- Schéma public - whiteboard_get_project
DROP FUNCTION IF EXISTS public.whiteboard_get_project(p_project_id uuid, p_student_id uuid) CASCADE;

-- Schéma public - whiteboard_get_render_status
DROP FUNCTION IF EXISTS public.whiteboard_get_render_status(p_render_id uuid, p_student_id uuid) CASCADE;

-- Schéma public - whiteboard_list_projects (2 versions)
DROP FUNCTION IF EXISTS public.whiteboard_list_projects(p_status character varying) CASCADE;
DROP FUNCTION IF EXISTS public.whiteboard_list_projects(p_status text, p_student_id uuid) CASCADE;

-- Schéma public - whiteboard_update_project
DROP FUNCTION IF EXISTS public.whiteboard_update_project(p_project_id uuid, p_subject text, p_status text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb, p_student_id uuid) CASCADE;

-- ============================================
-- VÉRIFICATION APRÈS NETTOYAGE
-- ============================================
-- Exécuter cette requête pour vérifier qu'il ne reste que les 8 fonctions à conserver:
/*
SELECT
    n.nspname AS schema_name,
    p.proname AS function_name,
    pg_get_function_identity_arguments(p.oid) AS arguments
FROM pg_proc p
JOIN pg_namespace n
ON n.oid = p.pronamespace
WHERE p.proname ILIKE '%whiteboard%'
ORDER BY
    n.nspname,
    p.proname;
*/
-- Résultat attendu: 8 fonctions (3 triggers + 5 worker)
