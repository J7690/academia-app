-- RPC publique whiteboard_create_project (wrapper autour de app_whiteboard_create_project)
-- Cette fonction est appelée par Flutter via l'API REST PostgREST

CREATE OR REPLACE FUNCTION public.whiteboard_create_project(
  p_student_id UUID,
  p_subject VARCHAR,
  p_renderer_id VARCHAR,
  p_theme_id VARCHAR,
  p_narration_mode VARCHAR,
  p_storyboard_json JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN app.app_whiteboard_create_project(
    p_student_id,
    p_subject,
    p_renderer_id,
    p_theme_id,
    p_narration_mode,
    p_storyboard_json
  );
END;
$$;

-- RPC publique whiteboard_list_projects (wrapper autour de app.whiteboard_list_projects)
CREATE OR REPLACE FUNCTION public.whiteboard_list_projects(p_status VARCHAR DEFAULT NULL)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN app.whiteboard_list_projects(p_status);
END;
$$;
