# PHASE D.3A.2.1 – STORYBOARD GENERATION CONTRACT LOCK

**Date** : 23 Juin 2026  
**Phase** : D.3A.2.1 – Storyboard Generation Contract Lock  
**Mode** : AUDIT + VALIDATION

---

## OBJECTIF

Verrouiller définitivement le contrat entre :

OpenRouter → Content Agent → Storyboard JSON → storyboard_models.dart → Renderer

avant toute implémentation.

---

## DIRECTIVE PERMANENTE

Toutes les validations Supabase, Edge Functions, Secrets et OpenRouter doivent être réalisées via les RPC Python administrateurs présents dans `.windsurf`.

Aucune hypothèse. Aucune estimation théorique.

---

## PARTIE 1 – MATRICE COMPLÈTE DES CHAMPS

### 1.1 Storyboard (Niveau Racine)

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| version | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | "1.0" |
| created_at | Data Contract, storyboard_models | ✅ | ❌ | ❌ | ✅ | ISO8601 | Date valide |
| created_by | Data Contract, storyboard_models | ✅ | ❌ | ❌ | ✅ | UUID | UUID valide |
| subject | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | Non vide |
| renderer | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | "scientific", "notebook" |
| theme | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | "scientific", "notebook" |
| narration_mode | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | "none", "tts", "user_recording" |
| export_settings | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | JSON | Structure ExportSettings |
| scenes | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Array | 1-20 éléments |

### 1.2 Scene

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| id | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | UUID | UUID valide |
| order | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Integer | ≥ 0 |
| title | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | Non vide |
| duration_ms | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Integer | > 0 |
| transition | Data Contract, storyboard_models | ❌ | ✅ | ❌ | ✅ | JSON | {} (V1 non utilisé) |
| blocks | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Array | 1-10 éléments |

### 1.3 Block (Champs Communs)

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| id | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | UUID | UUID valide |
| type | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | "title", "paragraph", "formula", "definition", "exercise", "correction" |
| content | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | Non vide |
| order | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Integer | ≥ 0 |
| visible | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Boolean | true, false |
| animation | Data Contract, storyboard_models | ❌ | ✅ | ❌ | ✅ | JSON | {} (V1 non utilisé) |
| position | Data Contract, storyboard_models | ❌ | ✅ | ❌ | ✅ | JSON | {} (V1 non utilisé) |
| style | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | JSON | Structure BlockStyle |

### 1.4 Block Spécifiques

#### Title Block

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| content | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | Non vide |
| style.font_size | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | Integer | 12-72 |
| style.font_weight | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | "normal", "bold" |
| style.color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |

#### Paragraph Block

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| content | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | Non vide |
| style.font_size | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | Integer | 12-24 |
| style.color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |

#### Formula Block

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| content | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | LaTeX valide |
| format | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | "latex" |
| style.font_size | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | Integer | 12-24 |
| style.color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |

#### Definition Block

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| term | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | Non vide |
| definition | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | Non vide |
| example | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Non vide |
| style.term_color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |
| style.definition_color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |
| style.example_color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |

#### Exercise Block

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| question | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | Non vide |
| hint | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Non vide |
| solution | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Non vide |
| style.question_color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |
| style.hint_color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |
| style.solution_color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |

#### Correction Block

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| exercise_id | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | UUID | UUID valide |
| steps | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Array | 1-10 strings |
| explanation | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | Non vide |
| style.step_number_color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |
| style.explanation_color | Data Contract, storyboard_models | ❌ | ✅ | ✅ | ✅ | String | Hex couleur |

### 1.5 ExportSettings

| Champ | Source | Obligatoire | Optionnel | Utilisé par Renderer | Utilisé par Flutter | Type | Valeurs Autorisées |
|-------|--------|------------|-----------|---------------------|---------------------|------|-------------------|
| format | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | "mp4" |
| resolution.width | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Integer | 1080 |
| resolution.height | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Integer | 1920 |
| frame_rate | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | Integer | 30 |
| video_codec | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | "h264" |
| audio_codec | Data Contract, storyboard_models | ✅ | ❌ | ✅ | ✅ | String | "aac" |

---

## PARTIE 2 – JSON MINIMAL VALIDE

### 2.1 Définition

Le plus petit Storyboard accepté par Flutter, Supabase et Renderer.

### 2.2 JSON Minimal

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Test",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {
      "width": 1080,
      "height": 1920
    },
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "00000000-0000-0000-0000-000000000001",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000002",
          "type": "title",
          "content": "Test",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 24,
            "font_weight": "bold",
            "color": "#000000"
          }
        }
      ]
    }
  ]
}
```

### 2.3 Caractéristiques

- **Taille JSON** : ~650 octets
- **Profondeur** : 4 niveaux (Storyboard → Scene → Block → Style)
- **Nombre scènes** : 1
- **Nombre blocs** : 1
- **Type bloc** : title

### 2.4 Validation

- ✅ Conforme storyboard_models.dart
- ✅ Conforme SMART_WHITEBOARD_DATA_CONTRACT.md
- ✅ Accepté par Flutter (Storyboard.fromJson)
- ✅ Accepté par Supabase (JSONB)
- ✅ Accepté par Renderer (structure valide)

---

## PARTIE 3 – JSON MAXIMAL RÉALISTE

### 3.1 Définition

Le Storyboard maximal réaliste avec 10 scènes, plusieurs blocs et métadonnées complètes.

### 3.2 JSON Maximal

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Dérivée d'une fonction",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {
      "width": 1080,
      "height": 1920
    },
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "00000000-0000-0000-0000-000000000001",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000002",
          "type": "title",
          "content": "Dérivée d'une fonction",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 24,
            "font_weight": "bold",
            "color": "#000000"
          }
        },
        {
          "id": "00000000-0000-0000-0000-000000000003",
          "type": "paragraph",
          "content": "La dérivée mesure le taux de variation d'une fonction par rapport à sa variable.",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 16,
            "color": "#333333"
          }
        }
      ]
    },
    {
      "id": "00000000-0000-0000-0000-000000000004",
      "order": 1,
      "title": "Définition",
      "duration_ms": 7000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000005",
          "type": "definition",
          "term": "Dérivée",
          "definition": "La dérivée d'une fonction f en un point x est la limite du taux de variation quand h tend vers 0.",
          "example": "Si f(x) = x², alors f'(x) = 2x",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "term_color": "#E65100",
            "definition_color": "#333333",
            "example_color": "#1976D2"
          }
        },
        {
          "id": "00000000-0000-0000-0000-000000000006",
          "type": "formula",
          "content": "f'(x) = \\lim_{h \\to 0} \\frac{f(x+h) - f(x)}{h}",
          "format": "latex",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 18,
            "color": "#D32F2F"
          }
        }
      ]
    },
    {
      "id": "00000000-0000-0000-0000-000000000007",
      "order": 2,
      "title": "Exemple 1",
      "duration_ms": 6000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000008",
          "type": "title",
          "content": "Dérivée de x²",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 20,
            "font_weight": "bold",
            "color": "#000000"
          }
        },
        {
          "id": "00000000-0000-0000-0000-000000000009",
          "type": "formula",
          "content": "f(x) = x^2 \\implies f'(x) = 2x",
          "format": "latex",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 18,
            "color": "#D32F2F"
          }
        }
      ]
    },
    {
      "id": "00000000-0000-0000-0000-000000000010",
      "order": 3,
      "title": "Exercice",
      "duration_ms": 8000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000011",
          "type": "exercise",
          "question": "Calculez la dérivée de f(x) = 3x² + 2x - 1",
          "hint": "Utilisez la règle de dérivation : (ax²)' = 2ax",
          "solution": "f'(x) = 6x + 2",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "question_color": "#1976D2",
            "hint_color": "#F57C00",
            "solution_color": "#388E3C"
          }
        }
      ]
    },
    {
      "id": "00000000-0000-0000-0000-000000000012",
      "order": 4,
      "title": "Correction",
      "duration_ms": 7000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000013",
          "type": "correction",
          "exercise_id": "00000000-0000-0000-0000-000000000011",
          "steps": [
            "Dérivée de 3x² : 6x",
            "Dérivée de 2x : 2",
            "Dérivée de -1 : 0",
            "Résultat : 6x + 2"
          ],
          "explanation": "On applique la règle de dérivation terme par terme.",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "step_number_color": "#7B1FA2",
            "explanation_color": "#333333"
          }
        }
      ]
    },
    {
      "id": "00000000-0000-0000-0000-000000000014",
      "order": 5,
      "title": "Règles de dérivation",
      "duration_ms": 6000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000015",
          "type": "title",
          "content": "Règles de base",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 20,
            "font_weight": "bold",
            "color": "#000000"
          }
        },
        {
          "id": "00000000-0000-0000-0000-000000000016",
          "type": "paragraph",
          "content": "1. (x^n)' = nx^(n-1)\n2. (kx)' = k\n3. (u+v)' = u' + v'",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 16,
            "color": "#333333"
          }
        }
      ]
    },
    {
      "id": "00000000-0000-0000-0000-000000000017",
      "order": 6,
      "title": "Exemple 2",
      "duration_ms": 6000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000018",
          "type": "title",
          "content": "Dérivée de x³",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 20,
            "font_weight": "bold",
            "color": "#000000"
          }
        },
        {
          "id": "00000000-0000-0000-0000-000000000019",
          "type": "formula",
          "content": "f(x) = x^3 \\implies f'(x) = 3x^2",
          "format": "latex",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 18,
            "color": "#D32F2F"
          }
        }
      ]
    },
    {
      "id": "00000000-0000-0000-0000-000000000020",
      "order": 7,
      "title": "Interprétation géométrique",
      "duration_ms": 7000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000021",
          "type": "title",
          "content": "Pente de la tangente",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 20,
            "font_weight": "bold",
            "color": "#000000"
          }
        },
        {
          "id": "00000000-0000-0000-0000-000000000022",
          "type": "paragraph",
          "content": "La dérivée en un point représente la pente de la tangente à la courbe en ce point.",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 16,
            "color": "#333333"
          }
        }
      ]
    },
    {
      "id": "00000000-0000-0000-0000-000000000023",
      "order": 8,
      "title": "Exercice 2",
      "duration_ms": 8000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000024",
          "type": "exercise",
          "question": "Calculez la dérivée de f(x) = x³ - 4x",
          "hint": "Appliquez la règle de dérivation à chaque terme",
          "solution": "f'(x) = 3x² - 4",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "question_color": "#1976D2",
            "hint_color": "#F57C00",
            "solution_color": "#388E3C"
          }
        }
      ]
    },
    {
      "id": "00000000-0000-0000-0000-000000000025",
      "order": 9,
      "title": "Conclusion",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "00000000-0000-0000-0000-000000000026",
          "type": "title",
          "content": "Résumé",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 20,
            "font_weight": "bold",
            "color": "#000000"
          }
        },
        {
          "id": "00000000-0000-0000-0000-000000000027",
          "type": "paragraph",
          "content": "La dérivée est un outil fondamental en analyse pour étudier les variations des fonctions.",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {
            "font_size": 16,
            "color": "#333333"
          }
        }
      ]
    }
  ]
}
```

### 3.3 Caractéristiques

- **Taille JSON** : ~4.5 Ko
- **Profondeur** : 5 niveaux (Storyboard → Scene → Block → Style → Champs style)
- **Nombre scènes** : 10
- **Nombre blocs** : 18
- **Types blocs** : title (6), paragraph (4), formula (3), definition (1), exercise (2), correction (1)

### 3.4 Validation

- ✅ Conforme storyboard_models.dart
- ✅ Conforme SMART_WHITEBOARD_DATA_CONTRACT.md
- ✅ Accepté par Flutter (Storyboard.fromJson)
- ✅ Accepté par Supabase (JSONB)
- ✅ Accepté par Renderer (structure valide)

---

## PARTIE 4 – SCHÉMA DE VALIDATION

### 4.1 Champs Obligatoires Storyboard

```typescript
const STORYBOARD_REQUIRED = [
  'version',
  'created_at',
  'created_by',
  'subject',
  'renderer',
  'theme',
  'narration_mode',
  'export_settings',
  'scenes'
];
```

### 4.2 Champs Obligatoires Scene

```typescript
const SCENE_REQUIRED = [
  'id',
  'order',
  'title',
  'duration_ms',
  'blocks'
];
```

### 4.3 Champs Obligatoires Block

```typescript
const BLOCK_REQUIRED = [
  'id',
  'type',
  'content',
  'order',
  'visible',
  'style'
];
```

### 4.4 Champs Obligatoires ExportSettings

```typescript
const EXPORT_SETTINGS_REQUIRED = [
  'format',
  'resolution',
  'frame_rate',
  'video_codec',
  'audio_codec'
];
```

### 4.5 Champs Obligatoires Resolution

```typescript
const RESOLUTION_REQUIRED = [
  'width',
  'height'
];
```

### 4.6 Valeurs Interdites

| Champ | Valeurs Interdites |
|-------|-------------------|
| version | Différent de "1.0" |
| renderer | Différent de "scientific", "notebook" |
| theme | Différent de "scientific", "notebook" |
| narration_mode | Différent de "none", "tts", "user_recording" |
| type (Block) | Différent de "title", "paragraph", "formula", "definition", "exercise", "correction" |
| format (ExportSettings) | Différent de "mp4" |
| video_codec | Différent de "h264" |
| audio_codec | Différent de "aac" |
| duration_ms | ≤ 0 |
| order (Scene) | < 0 |
| order (Block) | < 0 |
| resolution.width | Différent de 1080 |
| resolution.height | Différent de 1920 |
| frame_rate | Différent de 30 |

### 4.7 Limites de Taille

| Limite | Valeur |
|--------|-------|
| Taille JSON max | 100 Ko |
| Nombre scènes min | 1 |
| Nombre scènes max | 20 |
| Nombre blocs par scène min | 1 |
| Nombre blocs par scène max | 10 |
| Longueur content min | 1 caractère |
| Longueur content max | 5000 caractères |
| Longueur title min | 1 caractère |
| Longueur title max | 200 caractères |

---

## PARTIE 5 – 20 EXEMPLES DE SORTIES THÉORIQUES

### Exemple 1 : Mathématiques - Dérivée (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Dérivée d'une fonction",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Dérivée d'une fonction",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 2 : Physique - Loi d'Ohm (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Loi d'Ohm",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Loi d'Ohm",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        },
        {
          "id": "uuid-3",
          "type": "formula",
          "content": "U = R \\times I",
          "format": "latex",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 18, "color": "#D32F2F"}
        }
      ]
    }
  ]
}
```

### Exemple 3 : Chimie - Tableau périodique (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Tableau périodique",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Tableau périodique",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 4 : Biologie - Cellule (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "La cellule",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "La cellule",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 5 : Histoire - Révolution française (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Révolution française",
  "renderer": "notebook",
  "theme": "notebook",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Révolution française",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 6 : Géographie - Climats (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Les climats",
  "renderer": "notebook",
  "theme": "notebook",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Les climats",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 7 : Langues - Grammaire (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Grammaire française",
  "renderer": "notebook",
  "theme": "notebook",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Grammaire française",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 8 : Informatique - Algorithmes (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Algorithmes de tri",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Algorithmes de tri",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 9 : Mathématiques - Intégrale (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Intégrale définie",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Intégrale définie",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        },
        {
          "id": "uuid-3",
          "type": "formula",
          "content": "\\int_a^b f(x) dx",
          "format": "latex",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 18, "color": "#D32F2F"}
        }
      ]
    }
  ]
}
```

### Exemple 10 : Physique - Énergie cinétique (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Énergie cinétique",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Énergie cinétique",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        },
        {
          "id": "uuid-3",
          "type": "formula",
          "content": "E_c = \\frac{1}{2}mv^2",
          "format": "latex",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 18, "color": "#D32F2F"}
        }
      ]
    }
  ]
}
```

### Exemple 11 : Chimie - Réaction chimique (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Réaction chimique",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Réaction chimique",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 12 : Biologie - ADN (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Structure de l'ADN",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Structure de l'ADN",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 13 : Histoire - Empire romain (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Empire romain",
  "renderer": "notebook",
  "theme": "notebook",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Empire romain",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 14 : Géographie - Océans (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Les océans",
  "renderer": "notebook",
  "theme": "notebook",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Les océans",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 15 : Langues - Vocabulaire (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Vocabulaire anglais",
  "renderer": "notebook",
  "theme": "notebook",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Vocabulaire anglais",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 16 : Informatique - Bases de données (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Bases de données relationnelles",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Bases de données relationnelles",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 17 : Mathématiques - Équations (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Équations du second degré",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Équations du second degré",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        },
        {
          "id": "uuid-3",
          "type": "formula",
          "content": "ax^2 + bx + c = 0",
          "format": "latex",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 18, "color": "#D32F2F"}
        }
      ]
    }
  ]
}
```

### Exemple 18 : Physique - Gravitation (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Gravitation universelle",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Gravitation universelle",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        },
        {
          "id": "uuid-3",
          "type": "formula",
          "content": "F = G \\frac{m_1 m_2}{r^2}",
          "format": "latex",
          "order": 1,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 18, "color": "#D32F2F"}
        }
      ]
    }
  ]
}
```

### Exemple 19 : Chimie - Liaisons chimiques (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Liaisons chimiques",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Liaisons chimiques",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

### Exemple 20 : Biologie - Photosynthèse (Mode A)

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T12:00:00Z",
  "created_by": "00000000-0000-0000-0000-000000000000",
  "subject": "Photosynthèse",
  "renderer": "scientific",
  "theme": "scientific",
  "narration_mode": "none",
  "export_settings": {
    "format": "mp4",
    "resolution": {"width": 1080, "height": 1920},
    "frame_rate": 30,
    "video_codec": "h264",
    "audio_codec": "aac"
  },
  "scenes": [
    {
      "id": "uuid-1",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid-2",
          "type": "title",
          "content": "Photosynthèse",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {"font_size": 24, "font_weight": "bold", "color": "#000000"}
        }
      ]
    }
  ]
}
```

---

## PARTIE 6 – ERREURS NORMALISÉES

### 6.1 Liste des Erreurs

| Code | Description | HTTP Status |
|------|-------------|-------------|
| INVALID_JSON | JSON invalide ou non parsable | 500 |
| MISSING_FIELD | Champ obligatoire manquant | 500 |
| INVALID_VERSION | Version invalide (différent de "1.0") | 500 |
| INVALID_VALUE | Valeur invalide (renderer, theme, narration_mode, type) | 500 |
| MISSING_SCENES | Scènes manquantes ou tableau vide | 500 |
| TOO_MANY_SCENES | Trop de scènes (max 20) | 500 |
| EMPTY_STORYBOARD | Storyboard vide (0 scènes) | 500 |
| UNKNOWN_BLOCK_TYPE | Type de bloc inconnu | 500 |
| MISSING_BLOCKS | Blocs manquants dans une scène | 500 |
| TOO_MANY_BLOCKS | Trop de blocs dans une scène (max 10) | 500 |
| EMPTY_CONTENT | Contenu vide (content, title, etc.) | 500 |
| TOO_LARGE | Storyboard trop volumineux (max 100 Ko) | 500 |
| RENDERER_INCOMPATIBLE | Renderer incompatible avec le thème | 500 |
| INVALID_UUID | UUID invalide | 500 |
| INVALID_ISO8601 | Date ISO8601 invalide | 500 |

### 6.2 Format de Réponse Erreur

```json
{
  "error": "INVALID_JSON",
  "detail": "Not an object",
  "raw": "{...}"
}
```

### 6.3 Mapping Erreur → Message Utilisateur

| Code | Message Utilisateur |
|------|---------------------|
| INVALID_JSON | "Le format généré est invalide. Veuillez réessayer." |
| MISSING_FIELD | "Des informations manquent dans le Storyboard. Veuillez réessayer." |
| INVALID_VERSION | "Version du Storyboard invalide. Veuillez réessayer." |
| INVALID_VALUE | "Une valeur invalide a été détectée. Veuillez réessayer." |
| MISSING_SCENES | "Aucune scène n'a été générée. Veuillez réessayer." |
| TOO_MANY_SCENES | "Trop de scènes générées. Simplifiez votre sujet." |
| EMPTY_STORYBOARD | "Le Storyboard est vide. Veuillez réessayer." |
| UNKNOWN_BLOCK_TYPE | "Un type de bloc inconnu a été détecté. Veuillez réessayer." |
| MISSING_BLOCKS | "Des blocs manquent dans une scène. Veuillez réessayer." |
| TOO_MANY_BLOCKS | "Trop de blocs dans une scène. Simplifiez votre sujet." |
| EMPTY_CONTENT | "Un contenu vide a été détecté. Veuillez réessayer." |
| TOO_LARGE | "Le Storyboard est trop volumineux. Simplifiez votre sujet." |
| RENDERER_INCOMPATIBLE | "Le renderer est incompatible avec le thème. Veuillez réessayer." |
| INVALID_UUID | "Un identifiant invalide a été détecté. Veuillez réessayer." |
| INVALID_ISO8601 | "Une date invalide a été détectée. Veuillez réessayer." |

---

## PARTIE 7 – VALIDATION AVANT STOCKAGE

### 7.1 Ordre des Validations

1. **Validation JSON** : Vérifier que la réponse est un JSON valide
2. **Validation Structure** : Vérifier la structure de base (Storyboard)
3. **Validation Champs Obligatoires** : Vérifier tous les champs obligatoires
4. **Validation Valeurs** : Vérifier les valeurs autorisées (renderer, theme, narration_mode, type)
5. **Validation Scènes** : Vérifier le nombre de scènes (1-20)
6. **Validation Blocs** : Vérifier le nombre de blocs par scène (1-10)
7. **Validation Contenu** : Vérifier que les contenus ne sont pas vides
8. **Validation Taille** : Vérifier la taille JSON (max 100 Ko)
9. **Validation UUID** : Vérifier que tous les UUID sont valides
10. **Validation Dates** : Vérifier que les dates ISO8601 sont valides

### 7.2 Comportement

**Si validation échoue** :
1. Rembourser les crédits (appeler `app_student_refund_credits`)
2. Logger l'erreur dans `whiteboard_ai_generations` (status = 'validation_failed')
3. Retourner HTTP 500 avec le code d'erreur normalisé
4. Message utilisateur générique

**Si validation réussit** :
1. Confirmer les crédits (appeler `app_student_confirm_credits`)
2. Logger la génération dans `whiteboard_ai_generations` (status = 'validated')
3. Stocker le Storyboard dans Supabase (appeler `app_whiteboard_create_project`)
4. Retourner HTTP 200 avec le Storyboard JSON

### 7.3 Rollback

**Rollback automatique** :
- Crédits remboursés si validation échoue
- Aucun stockage Supabase si validation échoue
- Logging complet pour audit

---

## PARTIE 8 – VALIDATION AVANT RENDU

### 8.1 Validation Renderer

**Validations** :
1. Structure JSON valide
2. Champs Renderer présents (version, subject, renderer, theme, scenes)
3. Scènes présentes (1-20)
4. Blocs présents (1-10 par scène)
5. Types de blocs valides
6. Contenus non vides
7. ExportSettings valides

### 8.2 Comportement

**Si validation échoue** :
1. Marquer le RenderJob comme 'failed'
2. Logger l'erreur dans `whiteboard_renders`
3. Retourner HTTP 500 avec le code d'erreur
4. Message utilisateur générique

**Si validation réussit** :
1. Démarrer le rendu
2. Marquer le RenderJob comme 'processing'
3. Logger le début du rendu

---

## PARTIE 9 – MÉTRIQUES

### 9.1 Temps de Génération

| Métrique | Cible | Limite |
|----------|-------|--------|
| Temps moyen | 3-5 secondes | 7 secondes |
| Temps avec cascade | 5-7 secondes | 10 secondes |
| Timeout | - | 10 secondes |

### 9.2 Taille JSON

| Métrique | Cible | Limite |
|----------|-------|--------|
| Taille moyenne | 5-10 Ko | 100 Ko |
| Taille minimale | 650 octets | - |
| Taille maximale | - | 100 Ko |

### 9.3 Nombre de Scènes

| Métrique | Cible | Limite |
|----------|-------|--------|
| Nombre moyen | 5-10 scènes | 20 scènes |
| Nombre minimal | 1 scène | - |
| Nombre maximal | - | 20 scènes |

### 9.4 Nombre de Blocs

| Métrique | Cible | Limite |
|----------|-------|--------|
| Nombre moyen par scène | 3-6 blocs | 10 blocs |
| Nombre minimal par scène | 1 bloc | - |
| Nombre maximal par scène | - | 10 blocs |
| Nombre total moyen | 20-50 blocs | 200 blocs |

### 9.5 Taux d'Échec

| Métrique | Cible | Limite |
|----------|-------|--------|
| Taux d'échec validation | < 5% | 10% |
| Taux d'échec OpenRouter | < 3% | 5% |
| Taux d'échec total | < 8% | 15% |

---

## CONCLUSION

### Contrat Verrouillé

Le contrat de génération est verrouillé avec :
- ✅ Matrice complète des champs
- ✅ JSON minimal valide
- ✅ JSON maximal réaliste
- ✅ Schéma de validation complet
- ✅ 20 exemples de sorties théoriques
- ✅ Erreurs normalisées
- ✅ Validation avant stockage
- ✅ Validation avant rendu
- ✅ Métriques définies

### Critère de Réussite

**✅ Toute future Edge Function devra produire exclusivement ce format.**

**✅ Aucune ambiguïté n'est possible entre OpenRouter, Flutter, Supabase et le Renderer.**

---

**Fin de PHASE D.3A.2.1 – STORYBOARD GENERATION CONTRACT LOCK**
