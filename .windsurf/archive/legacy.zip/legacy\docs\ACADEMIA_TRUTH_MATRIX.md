# ACADEMIA TRUTH MATRIX

**Date** : 24 Juin 2026  
**Version** : 1.0

---

## MATRICE DE VÉRITÉ

**Légende** :
- **A** = Existe et vérifié
- **B** = Existe mais non vérifié
- **C** = Codé mais non déployé
- **D** = Déployé puis disparu
- **E** = N'existe pas

---

## SMART WHITEBOARD

### Tables Supabase

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| app.whiteboard_projects | A | Table créée via execute_ddl, 10 colonnes vérifiées | 24 Juin 2026 |
| app.whiteboard_renders | A | Table créée via execute_ddl, 14 colonnes vérifiées | 24 Juin 2026 |
| app.whiteboard_ai_generations | A | Table créée via execute_ddl, 12 colonnes vérifiées | 24 Juin 2026 |

### RPCs Supabase

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| public.whiteboard_fetch_queued_jobs | A | RPC créée via execute_ddl, 41 RPCs whiteboard trouvées | 24 Juin 2026 |
| public.whiteboard_mark_processing | A | RPC créée via execute_ddl, 41 RPCs whiteboard trouvées | 24 Juin 2026 |
| public.whiteboard_mark_done | A | RPC créée via execute_ddl, 41 RPCs whiteboard trouvées | 24 Juin 2026 |
| public.whiteboard_mark_failed | A | RPC créée via execute_ddl, 41 RPCs whiteboard trouvées | 24 Juin 2026 |
| public.whiteboard_get_any_student_id | A | RPC créée via execute_ddl, 41 RPCs whiteboard trouvées | 24 Juin 2026 |
| app.whiteboard_get_project | A | RPC créée via execute_ddl, 41 RPCs whiteboard trouvées | 24 Juin 2026 |
| app.whiteboard_update_project | A | RPC créée via execute_ddl, 41 RPCs whiteboard trouvées | 24 Juin 2026 |
| app.whiteboard_list_projects | A | RPC créée via execute_ddl, 41 RPCs whiteboard trouvées | 24 Juin 2026 |
| app.whiteboard_delete_project | A | RPC créée via execute_ddl, 41 RPCs whiteboard trouvées | 24 Juin 2026 |
| app.app_whiteboard_create_project | A | RPC créée via execute_ddl, confirmée via information_schema | 24 Juin 2026 |

### Storage Supabase

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| whiteboard-renders | A | Bucket existe via Supabase Dashboard | 24 Juin 2026 |
| whiteboard-narrations | A | Bucket existe via Supabase Dashboard | 24 Juin 2026 |

### Edge Functions

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| whiteboard-generate-storyboard | A | Déployée via Supabase CLI | 24 Juin 2026 |

### Kamatera

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| /opt/whiteboard-worker/whiteboard_render_worker.py | A | Fichier présent, MD5: 96274c246a4ba3e3cb4f2dc076707b20, module importé avec succès | 24 Juin 2026 |
| /opt/whiteboard-worker/whiteboard_png_renderer.py | A | Fichier présent, MD5: 62a604fdabbe7f065f0ca5acb76195b0 | 24 Juin 2026 |
| /opt/whiteboard-worker/whiteboard_ffmpeg_assembler.py | A | Fichier présent, MD5: 766b27b1c0440b838959c5b96daea486 | 24 Juin 2026 |
| /opt/whiteboard-worker/whiteboard_upload_renderer.py | A | Fichier présent, MD5: 547a0d66ad175c9d8f100566166e928f | 24 Juin 2026 |
| Worker process | A | Processus actif (PID 395272), 28.9M RAM, boucle de polling active | 24 Juin 2026 |
| Worker service | A | Service systemd configuré, enabled, active (running) | 24 Juin 2026 |

### Pipeline

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| Render job | A | Job fd9e3969-be64-45a9-8e95-00606ac51446 traité avec succès | 24 Juin 2026 |
| PNG généré | A | Logs worker confirment génération PNG pour le job | 24 Juin 2026 |
| MP4 généré | A | MP4 4320 bytes généré, header valide détecté | 24 Juin 2026 |
| URL Storage | A | URL accessible via HTTP 200, Content-Type: video/mp4 | 24 Juin 2026 |

### Flutter

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| SmartWhiteboardService | B | Code existe, non testé en production | 24 Juin 2026 |
| SmartWhiteboardRenderService | B | Code existe, non testé en production | 24 Juin 2026 |
| SmartWhiteboardProvider | B | Code existe, non testé en production | 24 Juin 2026 |
| SmartWhiteboardInputScreen | B | Code existe, routé via bouton + | 24 Juin 2026 |
| SmartWhiteboardStoryboardEditorScreen | C | Code existe, non routé dans main.dart | 24 Juin 2026 |
| SmartWhiteboardPreviewScreen | E | N'existe pas | 24 Juin 2026 |
| SmartWhiteboardProjectsListScreen | E | N'existe pas | 24 Juin 2026 |
| Routes main.dart | C | Routes manquantes pour Smart Whiteboard | 24 Juin 2026 |
| Bouton + Challenge Feed | B | Menu de création implémenté, navigation OK | 24 Juin 2026 |

### Économie

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| Coûts réels | A | Calculés dans PHASE_D6F_ECONOMICS_AUDIT.md | 24 Juin 2026 |
| Modèle de prix | A | Défini dans PHASE_D6F_ECONOMICS_AUDIT.md | 24 Juin 2026 |
| Marge bénéficiaire | A | Calculée dans PHASE_D6F_ECONOMICS_AUDIT.md | 24 Juin 2026 |
| Point mort | A | Calculé dans PHASE_D6F_ECONOMICS_AUDIT.md | 24 Juin 2026 |
| Viabilité | A | Validée dans PHASE_D6F_ECONOMICS_AUDIT.md | 24 Juin 2026 |

---

## CRÉDITS

### Tables Supabase

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| app.student_credits | A | Table existe et fonctionnelle | 7 Avril 2026 |
| app.credit_transactions | A | Table existe et fonctionnelle | 7 Avril 2026 |
| app.credit_packs | A | Table existe et fonctionnelle | 7 Avril 2026 |
| app.ai_action_prices | A | Table existe et fonctionnelle | 7 Avril 2026 |
| app.credit_reservations | A | Table existe et fonctionnelle | 7 Avril 2026 |

### RPCs Supabase

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| app_student_get_credit_balance | A | RPC fonctionnelle | 7 Avril 2026 |
| app_student_check_ai_access | A | RPC fonctionnelle | 7 Avril 2026 |
| app_student_reserve_credits | A | RPC fonctionnelle | 7 Avril 2026 |
| app_student_confirm_credits | A | RPC fonctionnelle | 7 Avril 2026 |
| app_student_refund_credits | A | RPC fonctionnelle | 7 Avril 2026 |
| app_student_purchase_credits | A | RPC fonctionnelle | 7 Avril 2026 |
| app_student_claim_weekly_bonus | A | RPC fonctionnelle | 7 Avril 2026 |
| app_admin_get_ai_usage_stats | A | RPC fonctionnelle | 7 Avril 2026 |
| app_admin_manage_credit_pack | A | RPC fonctionnelle | 7 Avril 2026 |
| app_admin_manage_ai_action_price | A | RPC fonctionnelle | 7 Avril 2026 |

---

## CHALLENGE FEED

### Tables Supabase

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| app.prep_news_sources | A | Table existe et fonctionnelle | 6 Avril 2026 |
| app.prep_news_articles | A | Table existe et fonctionnelle | 6 Avril 2026 |

### RPCs Supabase

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| app_admin_prep_list_news_sources | A | RPC fonctionnelle | 6 Avril 2026 |
| app_admin_prep_list_news_articles | A | RPC fonctionnelle | 6 Avril 2026 |
| app_admin_prep_news_stats | A | RPC fonctionnelle | 6 Avril 2026 |

### Edge Functions

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| prep-feed-actuality | A | Déployée et fonctionnelle | 6 Avril 2026 |

---

## PAIEMENTS

### Tables Supabase

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| app.application_payments | A | Table existe et fonctionnelle | 19 Mars 2026 |
| app.payment_receipts | A | Table existe et fonctionnelle | 19 Mars 2026 |
| app.payment_proofs | A | Table existe et fonctionnelle | 19 Mars 2026 |
| app.marketplace_payments | A | Table existe et fonctionnelle | 19 Mars 2026 |

### RPCs Supabase

| Composant | Statut | Preuve | Date |
| --------- | ------ | ------ | ---- |
| app_student_declare_payment | A | RPC fonctionnelle | 19 Mars 2026 |
| app_create_application_payment | A | RPC fonctionnelle | 19 Mars 2026 |
| app_student_create_profile_payment | A | RPC fonctionnelle | 19 Mars 2026 |
| app_admin_verify_payment | A | RPC fonctionnelle | 19 Mars 2026 |
| app_admin_confirm_payment | A | RPC fonctionnelle | 19 Mars 2026 |
| app_admin_get_payment_detail | A | RPC fonctionnelle | 19 Mars 2026 |
| app_admin_list_payments_with_context | A | RPC fonctionnelle | 19 Mars 2026 |
| app_admin_list_payment_receipts_with_context | A | RPC fonctionnelle | 19 Mars 2026 |
| app_university_list_payments | A | RPC fonctionnelle | 19 Mars 2026 |

---

## MISES À JOUR

Ce document doit être mis à jour après chaque phase.

---

**Fin de ACADEMIA_TRUTH_MATRIX.md**
