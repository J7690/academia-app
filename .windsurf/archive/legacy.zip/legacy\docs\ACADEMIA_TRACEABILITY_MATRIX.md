# ACADEMIA TRACEABILITY MATRIX

**Date** : 24 Juin 2026  
**Version** : 1.0  
**Statut** : ACTIF

---

## OBJECTIF

Ce document est la référence officielle permettant de retrouver immédiatement l'origine de n'importe quel composant du projet Academia. Il ne décrit pas le fonctionnement mais les liens entre exigences, ADR, contrats, Edge Functions, RPC, tables, Flutter, Workers et documents.

---

## STRUCTURE

Pour chaque fonctionnalité importante, une fiche contient :
- Besoin métier
- ADR concernés
- Contrats concernés
- Edge Functions
- RPC
- Tables
- Buckets
- Worker Kamatera
- Flutter (Provider, Services, Écrans)
- Tests
- Rapports
- Dernière modification
- Dernière phase
- Classification Truth Matrix

---

## MATRICE DE TRAÇABILITÉ PAR FONCTIONNALITÉ

### SMART WHITEBOARD

**Besoin métier** : Permettre aux étudiants de générer des vidéos pédagogiques à partir de sujets d'examen ou de cours.

**ADR concernés** :
- ADR-001 : Séparation Bobodo / Smart Whiteboard
- ADR-002 : Utilisation d'OpenRouter comme moteur de génération pédagogique
- ADR-003 : Kamatera responsable du rendu vidéo
- ADR-004 : Flutter ne génère jamais les vidéos
- ADR-005 : Supabase orchestre tout le pipeline

**Contrats concernés** :
- CONTRAT-001 : Flutter → Edge Function
- CONTRAT-002 : Edge Function → OpenRouter
- CONTRAT-003 : OpenRouter → Validation
- CONTRAT-004 : Contrat Storyboard
- CONTRAT-005 : Storyboard → Renderer
- CONTRAT-006 : Renderer → Kamatera
- CONTRAT-007 : Kamatera → Storage
- CONTRAT-008 : Storage → Flutter
- CONTRAT-009 : RPC whiteboard_create_project
- CONTRAT-010 : RPC whiteboard_create_render_job
- CONTRAT-011 : RPC whiteboard_get_render_status
- CONTRAT-012 : Table whiteboard_projects
- CONTRAT-013 : Table whiteboard_renders
- CONTRAT-014 : Provider SmartWhiteboardProvider
- CONTRAT-015 : Navigation Flutter Smart Whiteboard

**Edge Functions** :
- whiteboard-generate-storyboard

**RPC** :
- app_whiteboard_create_project
- whiteboard_create_render_job
- whiteboard_get_render_status
- whiteboard_fetch_queued_jobs
- whiteboard_mark_processing
- whiteboard_mark_done
- whiteboard_mark_failed
- whiteboard_get_any_student_id
- app_whiteboard_get_project
- app_whiteboard_update_project
- app_whiteboard_list_projects
- app_whiteboard_delete_project

**Tables** :
- app.whiteboard_projects
- app.whiteboard_renders
- app.whiteboard_ai_generations

**Buckets** :
- whiteboard-renders
- whiteboard-narrations

**Worker Kamatera** :
- /opt/whiteboard-worker/whiteboard_render_worker.py
- /opt/whiteboard-worker/whiteboard_png_renderer.py
- /opt/whiteboard-worker/whiteboard_ffmpeg_assembler.py
- /opt/whiteboard-worker/whiteboard_upload_renderer.py

**Flutter** :
- Provider : SmartWhiteboardProvider
- Services : SmartWhiteboardService, SmartWhiteboardRenderService
- Écrans : SmartWhiteboardInputScreen, SmartWhiteboardStoryboardEditorScreen, SmartWhiteboardPreviewScreen, SmartWhiteboardProjectsListScreen

**Tests** :
- .windsurf/test_whiteboard_modes.py

**Rapports** :
- PHASE_D5I_PRODUCTION_ACTIVATION_REPORT.md
- PHASE_D6A_FLUTTER_INTEGRATION_AUDIT.md
- PHASE_D6B_REAL_USER_FLOW_TESTS.md
- PHASE_D6F_ECONOMICS_AUDIT.md

**Dernière modification** : 24 Juin 2026

**Dernière phase** : D.6I – Project Checkpoint System

**Classification Truth Matrix** :
- Infrastructure : A (Production validée)
- Flutter : B (Intégration partielle)

---

### BOBODO ASSISTANT

**Besoin métier** : Assistant utilisateur pour l'orientation, l'aide plateforme et l'accompagnement étudiant.

**ADR concernés** :
- ADR-001 : Séparation Bobodo / Smart Whiteboard

**Contrats concernés** : (à documenter)

**Edge Functions** : (à documenter)

**RPC** : (à documenter)

**Tables** : (à documenter)

**Buckets** : (à documenter)

**Worker Kamatera** : Aucun

**Flutter** :
- Provider : BobodoProvider
- Services : BobodoService
- Écrans : (à documenter)

**Tests** : (à documenter)

**Rapports** : (à documenter)

**Dernière modification** : N/A

**Dernière phase** : N/A

**Classification Truth Matrix** : B (Existe mais non vérifié)

---

### CHALLENGE FEED

**Besoin métier** : Diffusion et publication de vidéos challenges.

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** : (à documenter)

**RPC** : (à documenter)

**Tables** :
- app.challenges
- app.challenge_participants
- app.challenge_submissions

**Buckets** :
- challenge-videos
- challenge-thumbnails

**Worker Kamatera** :
- Compression vidéo

**Flutter** :
- Provider : ChallengeProvider
- Services : ChallengeService
- Écrans : StudentChallengesTab, ChallengeDetailScreen

**Tests** : (à documenter)

**Rapports** :
- video_challenge_studio_etat_des_lieux.md

**Dernière modification** : (à documenter)

**Dernière phase** : (à documenter)

**Classification Truth Matrix** : B (Existe mais non vérifié)

---

### CRÉDITS

**Besoin métier** : Système de monétisation et d'accès aux fonctionnalités IA.

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** : (à documenter)

**RPC** :
- app_reserve_credits
- app_confirm_credits
- app_refund_credits
- app_get_student_credits

**Tables** :
- app.student_credits
- app.credit_transactions

**Buckets** : Aucun

**Worker Kamatera** : Aucun

**Flutter** :
- Provider : CreditsProvider
- Services : CreditsService
- Écrans : CreditsScreen, PurchaseCreditsScreen

**Tests** : (à documenter)

**Rapports** : (à documenter)

**Dernière modification** : (à documenter)

**Dernière phase** : (à documenter)

**Classification Truth Matrix** : A (Existe et vérifié)

---

### PRÉPARATION CONCOURS

**Besoin métier** : Module de préparation aux concours avec quiz et flashcards.

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** :
- prep-generate-quiz
- prep-generate-flashcards

**RPC** :
- app_prep_create_quiz
- app_prep_get_quiz
- app_prep_submit_answer

**Tables** :
- app.prep_quizzes
- app.prep_questions
- app.prep_flashcards
- app.prep_quiz_attempts

**Buckets** :
- prep-documents

**Worker Kamatera** : Aucun

**Flutter** :
- Provider : PrepProvider
- Services : PrepService
- Écrans : PrepQuizScreen, PrepFlashcardsScreen

**Tests** : (à documenter)

**Rapports** : (à documenter)

**Dernière modification** : (à documenter)

**Dernière phase** : (à documenter)

**Classification Truth Matrix** : B (Existe mais non vérifié)

---

### TRAVAUX DIRIGÉS (TD)

**Besoin métier** : Module de travaux dirigés avec scan et correction IA.

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** :
- td-scan-subject

**RPC** :
- app_td_admin_import_questions_json
- app_td_admin_import_text_bulk

**Tables** :
- app.td_questions
- app.td_source_documents
- app.td_doc_chunks
- app.td_scan_logs

**Buckets** :
- td-documents

**Worker Kamatera** : Aucun

**Flutter** :
- Provider : TDProvider
- Services : TDService
- Écrans : TDScanSubjectScreen, TDQuizTab, AdminTDDirectImportScreen

**Tests** : (à documenter)

**Rapports** :
- audit_td_supabase_deep.py

**Dernière modification** : (à documenter)

**Dernière phase** : (à documenter)

**Classification Truth Matrix** : B (Existe mais non vérifié)

---

### JEUX ÉCONOMIQUES

**Besoin métier** : Jeux éducatifs sur les concepts économiques.

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** : Aucun

**RPC** :
- tournament_create
- tournament_list_available
- tournament_register
- tournament_get_details
- tournament_get_standings
- tournament_start
- tournament_report_match_result
- generate_tournament_bracket
- league_create
- league_list_available
- league_join
- league_get_standings
- league_report_match_result

**Tables** :
- tournaments
- tournament_participants
- tournament_matches
- tournament_rewards
- leagues
- league_participations
- league_matches

**Buckets** : Aucun

**Worker Kamatera** : Aucun

**Flutter** :
- Provider : GamesProvider
- Services : GamesService
- Écrans : GamesHubScreen, GamesMenuScreen, TournamentListScreen

**Tests** : (à documenter)

**Rapports** :
- kellenge_flame_engine_audit.md
- kellenge_implementation_phases.md

**Dernière modification** : 14 Mars 2026

**Dernière phase** : Audit Jeux Économiques

**Classification Truth Matrix** : B (Existe mais non vérifié)

---

### STREAMING

**Besoin métier** : Diffusion en direct de contenus éducatifs.

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** : (à documenter)

**RPC** : (à documenter)

**Tables** : (à documenter)

**Buckets** :
- streaming-videos

**Worker Kamatera** :
- Streaming server

**Flutter** :
- Provider : StreamingProvider
- Services : StreamingService
- Écrans : StreamingScreen

**Tests** : (à documenter)

**Rapports** : (à documenter)

**Dernière modification** : N/A

**Dernière phase** : N/A

**Classification Truth Matrix** : C (Codé mais non déployé)

---

### MARKETPLACE

**Besoin métier** : Place de marché pour les ressources pédagogiques.

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** : (à documenter)

**RPC** : (à documenter)

**Tables** : (à documenter)

**Buckets** :
- marketplace-resources

**Worker Kamatera** : Aucun

**Flutter** :
- Provider : MarketplaceProvider
- Services : MarketplaceService
- Écrans : MarketplaceScreen

**Tests** : (à documenter)

**Rapports** : (à documenter)

**Dernière modification** : N/A

**Dernière phase** : N/A

**Classification Truth Matrix** : C (Codé mais non déployé)

---

### LIVEKIT

**Besoin métier** : Infrastructure de communication en temps réel.

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** : Aucun

**RPC** : Aucun

**Tables** : Aucun

**Buckets** : Aucun

**Worker Kamatera** : Aucun

**Flutter** :
- Provider : LiveKitProvider
- Services : LiveKitService
- Écrans : (à documenter)

**Tests** : (à documenter)

**Rapports** : (à documenter)

**Dernière modification** : N/A

**Dernière phase** : N/A

**Classification Truth Matrix** : B (Existe mais non vérifié)

---

### UPLOAD

**Besoin métier** : Upload de fichiers (images, vidéos, documents).

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** : (à documenter)

**RPC** : (à documenter)

**Tables** : (à documenter)

**Buckets** :
- uploads

**Worker Kamatera** :
- Compression Kamatera

**Flutter** :
- Provider : UploadProvider
- Services : UploadService
- Écrans : UploadScreen

**Tests** : (à documenter)

**Rapports** : (à documenter)

**Dernière modification** : N/A

**Dernière phase** : N/A

**Classification Truth Matrix** : A (Existe et vérifié)

---

### PUBLICATION

**Besoin métier** : Publication de contenus (vidéos, posts).

**ADR concernés** : (à documenter)

**Contrats concernés** : (à documenter)

**Edge Functions** : (à documenter)

**RPC** : (à documenter)

**Tables** : (à documenter)

**Buckets** :
- publications

**Worker Kamatera** : Aucun

**Flutter** :
- Provider : PublicationProvider
- Services : PublicationService
- Écrans : PublicationScreen

**Tests** : (à documenter)

**Rapports** : (à documenter)

**Dernière modification** : N/A

**Dernière phase** : N/A

**Classification Truth Matrix** : A (Existe et vérifié)

---

## RECHERCHE INVERSE

### whiteboard-generate-storyboard (Edge Function)

**Contrat** : CONTRAT-001, CONTRAT-002

**ADR** : ADR-002, ADR-005

**Flutter** : SmartWhiteboardProvider, SmartWhiteboardInputScreen

**Worker** : Aucun

**Rapports** : PHASE_D5I_PRODUCTION_ACTIVATION_REPORT.md, PHASE_D6A_FLUTTER_INTEGRATION_AUDIT.md

**Dernière modification** : 24 Juin 2026

---

### app.whiteboard_projects (Table)

**Contrat** : CONTRAT-012

**ADR** : ADR-005, ADR-007

**Edge Functions** : whiteboard-generate-storyboard

**RPC** : app_whiteboard_create_project, app_whiteboard_get_project, app_whiteboard_update_project, app_whiteboard_list_projects, app_whiteboard_delete_project

**Flutter** : SmartWhiteboardProvider

**Worker** : Aucun

**Rapports** : PHASE_D5I_PRODUCTION_ACTIVATION_REPORT.md

**Dernière modification** : 24 Juin 2026

---

### app.whiteboard_renders (Table)

**Contrat** : CONTRAT-013

**ADR** : ADR-003, ADR-005

**Edge Functions** : Aucun

**RPC** : whiteboard_create_render_job, whiteboard_get_render_status

**Flutter** : SmartWhiteboardRenderService

**Worker** : /opt/whiteboard-worker/whiteboard_render_worker.py

**Rapports** : PHASE_D5I_PRODUCTION_ACTIVATION_REPORT.md

**Dernière modification** : 24 Juin 2026

---

### SmartWhiteboardProvider (Flutter Provider)

**Contrat** : CONTRAT-014

**ADR** : ADR-005

**Edge Functions** : whiteboard-generate-storyboard

**RPC** : app_whiteboard_create_project, app_whiteboard_get_project, app_whiteboard_update_project

**Tables** : app.whiteboard_projects

**Worker** : Aucun

**Rapports** : PHASE_D6A_FLUTTER_INTEGRATION_AUDIT.md

**Dernière modification** : 24 Juin 2026

---

### /opt/whiteboard-worker/whiteboard_render_worker.py (Worker Kamatera)

**Contrat** : CONTRAT-005, CONTRAT-006, CONTRAT-007

**ADR** : ADR-003

**Edge Functions** : Aucun

**RPC** : whiteboard_fetch_queued_jobs, whiteboard_mark_processing, whiteboard_mark_done, whiteboard_mark_failed

**Tables** : app.whiteboard_renders

**Flutter** : SmartWhiteboardRenderService

**Rapports** : PHASE_D5I_PRODUCTION_ACTIVATION_REPORT.md

**Dernière modification** : 24 Juin 2026

---

### whiteboard-renders (Bucket)

**Contrat** : CONTRAT-007, CONTRAT-008

**ADR** : ADR-003

**Edge Functions** : Aucun

**RPC** : Aucun

**Tables** : app.whiteboard_renders

**Worker** : /opt/whiteboard-worker/whiteboard_upload_renderer.py

**Flutter** : SmartWhiteboardPreviewScreen

**Rapports** : PHASE_D5I_PRODUCTION_ACTIVATION_REPORT.md

**Dernière modification** : 24 Juin 2026

---

## TRAÇABILITÉ DES PHASES

### PHASE D.6H – Knowledge Preservation Lock

**Fonctionnalités concernées** : Toutes

**ADR concernés** : Aucun (création de documents permanents)

**Contrats concernés** : Aucun (création de documents permanents)

**Composants concernés** : Aucun (création de documents permanents)

**Rapports concernés** : PHASE_D6H_KNOWLEDGE_PRESERVATION_LOCK.md

**Documents permanents mis à jour** :
- ACADEMIA_PROJECT_STATE.md
- ACADEMIA_MASTER_INDEX.md
- ACADEMIA_TRUTH_MATRIX.md
- ACADEMIA_CHANGELOG.md

---

### PHASE D.6I – Project Checkpoint System

**Fonctionnalités concernées** : Toutes

**ADR concernés** : Aucun (création de documents permanents)

**Contrats concernés** : Aucun (création de documents permanents)

**Composants concernés** : Aucun (création de documents permanents)

**Rapports concernés** : PHASE_D6I_PROJECT_CHECKPOINT_SYSTEM.md

**Documents permanents mis à jour** :
- ACADEMIA_CURRENT_CHECKPOINT.md
- ACADEMIA_PROJECT_STATE.md
- ACADEMIA_MASTER_INDEX.md
- ACADEMIA_CHANGELOG.md

---

### PHASE D.6J – Protocole Permanent d'Exécution

**Fonctionnalités concernées** : Toutes

**ADR concernés** : Aucun (création de documents permanents)

**Contrats concernés** : Aucun (création de documents permanents)

**Composants concernés** : Aucun (création de documents permanents)

**Rapports concernés** : ACADEMIA_PERMANENT_EXECUTION_PROTOCOL.md

**Documents permanents mis à jour** :
- ACADEMIA_MASTER_INDEX.md
- ACADEMIA_PROJECT_STATE.md
- ACADEMIA_CHANGELOG.md

---

### PHASE D.6K – Constitution Technique Academia

**Fonctionnalités concernées** : Toutes

**ADR concernés** : Aucun (création de documents permanents)

**Contrats concernés** : Aucun (création de documents permanents)

**Composants concernés** : Aucun (création de documents permanents)

**Rapports concernés** : ACADEMIA_TECHNICAL_CONSTITUTION.md

**Documents permanents mis à jour** :
- ACADEMIA_MASTER_INDEX.md
- ACADEMIA_PROJECT_STATE.md
- ACADEMIA_CHANGELOG.md
- ACADEMIA_CURRENT_CHECKPOINT.md

---

### PHASE D.6L – Registre des Décisions d'Architecture (ADR)

**Fonctionnalités concernées** : Toutes

**ADR concernés** : ADR-001 à ADR-010 (création)

**Contrats concernés** : Aucun (création de documents permanents)

**Composants concernés** : Aucun (création de documents permanents)

**Rapports concernés** : ACADEMIA_ARCHITECTURE_DECISIONS.md

**Documents permanents mis à jour** :
- ACADEMIA_MASTER_INDEX.md
- ACADEMIA_PROJECT_STATE.md
- ACADEMIA_CHANGELOG.md
- ACADEMIA_CURRENT_CHECKPOINT.md
- ACADEMIA_TECHNICAL_CONSTITUTION.md

---

### PHASE D.6M – Registre des Contrats Techniques

**Fonctionnalités concernées** : Smart Whiteboard

**ADR concernés** : Aucun (création de documents permanents)

**Contrats concernés** : CONTRAT-001 à CONTRAT-015 (création)

**Composants concernés** : Aucun (création de documents permanents)

**Rapports concernés** : ACADEMIA_CONTRACT_REGISTRY.md

**Documents permanents mis à jour** :
- ACADEMIA_MASTER_INDEX.md
- ACADEMIA_PROJECT_STATE.md
- ACADEMIA_CHANGELOG.md
- ACADEMIA_CURRENT_CHECKPOINT.md
- ACADEMIA_TECHNICAL_CONSTITUTION.md

---

## RÈGLE ABSOLUE

Aucun développement ne peut être considéré terminé tant qu'il n'est pas référencé dans la matrice de traçabilité.

---

## RÈGLE DE DÉMARRAGE

Avant toute modification importante, retrouver le composant concerné dans la matrice afin d'identifier immédiatement :
- Les ADR impactés
- Les contrats impactés
- Les Edge Functions impactées
- Les RPC impactées
- Les tables impactées
- Les écrans Flutter impactés
- Les services impactés
- Les documents à mettre à jour

Aucune modification ne doit être réalisée sans cette analyse de traçabilité.

---

## HISTORIQUE DES MODIFICATIONS

### 24 Juin 2026
- Création de la matrice de traçabilité Academia
- Documentation de 12 fonctionnalités (Smart Whiteboard, Bobodo, Challenge, Crédits, Préparation Concours, TD, Jeux, Streaming, Marketplace, LiveKit, Upload, Publication)
- Création de la recherche inverse (whiteboard-generate-storyboard, app.whiteboard_projects, app.whiteboard_renders, SmartWhiteboardProvider, whiteboard_render_worker.py, whiteboard-renders bucket)
- Documentation de la traçabilité des phases (D.6H à D.6M)
- Définition de la règle absolue
- Définition de la règle de démarrage

---

**Fin de ACADEMIA_TRACEABILITY_MATRIX.md**
