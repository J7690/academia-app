import requests

url = "https://thevdfcwlcqzdoybfvgs.supabase.co"
headers = {
    "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRoZXZkZmN3bGNxemRveWJmdmdzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MzA1NjU2MCwiZXhwIjoyMDc4NjMyNTYwfQ.U0xz7oHnUISnxzAG8ehm_gRzoOlQPucj61i2f-1FjgM",
    "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRoZXZkZmN3bGNxemRveWJmdmdzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MzA1NjU2MCwiZXhwIjoyMDc4NjMyNTYwfQ.U0xz7oHnUISnxzAG8ehm_gRzoOlQPucj61i2f-1FjgM",
}

print("Vérification directe des tables whiteboard...")

# Vérifier whiteboard_projects
print("\n1. Vérification table whiteboard_projects...")
resp = requests.get(f"{url}/rest/v1/app_whiteboard_projects?limit=1", headers=headers, timeout=30)
print(f"STATUS: {resp.status_code}")
if resp.status_code == 200:
    print("✅ Table whiteboard_projects existe (via app_whiteboard_projects)")
elif resp.status_code == 404:
    print("❌ Table whiteboard_projects non trouvée")
else:
    print(f"⚠️ Status: {resp.status_code}")

# Vérifier whiteboard_renders
print("\n2. Vérification table whiteboard_renders...")
resp = requests.get(f"{url}/rest/v1/app_whiteboard_renders?limit=1", headers=headers, timeout=30)
print(f"STATUS: {resp.status_code}")
if resp.status_code == 200:
    print("✅ Table whiteboard_renders existe (via app_whiteboard_renders)")
elif resp.status_code == 404:
    print("❌ Table whiteboard_renders non trouvée")
else:
    print(f"⚠️ Status: {resp.status_code}")

# Vérifier buckets
print("\n3. Vérification bucket whiteboard-renders...")
resp = requests.get(f"{url}/storage/v1/bucket/whiteboard-renders", headers=headers, timeout=30)
print(f"STATUS: {resp.status_code}")
if resp.status_code == 200:
    print("✅ Bucket whiteboard-renders existe")
elif resp.status_code == 404:
    print("❌ Bucket whiteboard-renders non trouvé")
else:
    print(f"⚠️ Status: {resp.status_code}")

print("\n4. Vérification bucket whiteboard-narrations...")
resp = requests.get(f"{url}/storage/v1/bucket/whiteboard-narrations", headers=headers, timeout=30)
print(f"STATUS: {resp.status_code}")
if resp.status_code == 200:
    print("✅ Bucket whiteboard-narrations existe")
elif resp.status_code == 404:
    print("❌ Bucket whiteboard-narrations non trouvé")
else:
    print(f"⚠️ Status: {resp.status_code}")
