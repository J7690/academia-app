# ACADEMIA CONTRACT REGISTRY

**Date** : 24 Juin 2026  
**Version** : 1.0  
**Statut** : ACTIF

---

## OBJECTIF

Ce document est la référence officielle de tous les contrats techniques entre les composants du projet Academia. Il complète la Constitution Technique et les ADR. Il ne décrit pas le code mais exclusivement les interfaces entre les systèmes.

---

## FORMAT DE CONTRAT

Pour chaque contrat, documenter obligatoirement :

- **Nom du contrat**
- **Composants concernés**
- **Entrées**
- **Sorties**
- **Préconditions**
- **Postconditions**
- **Erreurs possibles**
- **Version**
- **Compatibilité**
- **Références**

---

## REGISTRE DES CONTRATS

### CONTRAT-001 : Flutter → Edge Function (Smart Whiteboard)

**Nom** : SmartWhiteboardProvider → whiteboard-generate-storyboard

**Composants concernés** :
- SmartWhiteboardProvider (Flutter)
- whiteboard-generate-storyboard (Edge Function Supabase)

**Entrées** :
```json
{
  "project_id": "UUID",
  "subject": "string",
  "content": "string | null",
  "mode": "simple | full_text | plan | existing_course",
  "theme_id": "string",
  "renderer_id": "string",
  "narration_mode": "none | tts | recording"
}
```

**Sorties** :
```json
{
  "success": true,
  "storyboard": {
    "scenes": [
      {
        "id": "UUID",
        "order": 0,
        "title": "string",
        "blocks": [
          {
            "id": "UUID",
            "type": "text | image | diagram",
            "content": "string",
            "position": {"x": 0, "y": 0},
            "size": {"width": 100, "height": 100}
          }
        ]
      }
    ]
  }
}
```

**Préconditions** :
- Utilisateur authentifié
- Crédits suffisants (15 crédits)
- project_id existe dans app.whiteboard_projects
- mode est valide (simple, full_text, plan, existing_course)

**Postconditions** :
- Storyboard généré et stocké dans app.whiteboard_ai_generations
- Crédits déduits du solde utilisateur
- project_id mis à jour avec le storyboard_id

**Erreurs possibles** :
- `CREDITS_INSUFFICIENTS` : Solde insuffisant
- `PROJECT_NOT_FOUND` : project_id invalide
- `MODE_INVALIDE` : mode non reconnu
- `THEME_INVALIDE` : theme_id invalide
- `RENDERER_INVALIDE` : renderer_id invalide
- `NARRATION_MODE_INVALIDE` : narration_mode non reconnu
- `OPENROUTER_ERROR` : Erreur OpenRouter
- `TIMEOUT` : Timeout Edge Function

**Version** : 1.0

**Compatibilité** : Flutter 3.0+, Supabase Edge Functions

**Références** :
- ADR-002 : Utilisation d'OpenRouter comme moteur de génération pédagogique
- ADR-005 : Supabase orchestre tout le pipeline

---

### CONTRAT-002 : Edge Function → OpenRouter

**Nom** : whiteboard-generate-storyboard → OpenRouter

**Composants concernés** :
- whiteboard-generate-storyboard (Edge Function Supabase)
- OpenRouter API

**Entrées** :
```json
{
  "model": "anthropic/claude-3.5-sonnet",
  "messages": [
    {
      "role": "system",
      "content": "Tu es un expert pédagogique..."
    },
    {
      "role": "user",
      "content": "Génère un storyboard pour le sujet : {subject}"
    }
  ],
  "max_tokens": 4000,
  "temperature": 0.7
}
```

**Sorties** :
```json
{
  "id": "chatcmpl-xxx",
  "choices": [
    {
      "message": {
        "content": "{\"scenes\": [...]}"
      }
    }
  ],
  "usage": {
    "prompt_tokens": 1000,
    "completion_tokens": 2000,
    "total_tokens": 3000
  }
}
```

**Préconditions** :
- Clé API OpenRouter valide
- Modèle disponible
- Solde OpenRouter suffisant

**Postconditions** :
- Storyboard JSON généré
- Tokens consommés
- Coût calculé

**Erreurs possibles** :
- `API_KEY_INVALIDE` : Clé API invalide
- `MODEL_UNAVAILABLE` : Modèle non disponible
- `RATE_LIMIT_EXCEEDED` : Limite de taux dépassée
- `INSUFFICIENT_FUNDS` : Solde insuffisant
- `TIMEOUT` : Timeout OpenRouter

**Version** : 1.0

**Compatibilité** : OpenRouter API v1

**Références** :
- ADR-002 : Utilisation d'OpenRouter comme moteur de génération pédagogique

---

### CONTRAT-003 : OpenRouter → Validation

**Nom** : Storyboard JSON Validation

**Composants concernés** :
- whiteboard-generate-storyboard (Edge Function Supabase)
- Validation Logic

**Entrées** :
```json
{
  "scenes": [
    {
      "id": "UUID",
      "order": 0,
      "title": "string",
      "blocks": [...]
    }
  ]
}
```

**Sorties** :
```json
{
  "valid": true,
  "errors": []
}
```

**Préconditions** :
- JSON valide
- Structure conforme au contrat Storyboard

**Postconditions** :
- Storyboard validé
- Erreurs identifiées si invalides

**Règles de validation** :
1. `scenes` est un tableau non vide
2. Chaque scène a un `id` UUID valide
3. Chaque scène a un `order` unique
4. Chaque scène a un `title` non vide
5. Chaque scène a un `blocks` tableau non vide
6. Chaque bloc a un `id` UUID valide
7. Chaque bloc a un `type` valide (text, image, diagram)
8. Chaque bloc a un `content` non vide si type = text
9. Chaque bloc a un `position` valide (x, y)
10. Chaque bloc a un `size` valide (width, height)

**Erreurs possibles** :
- `JSON_INVALIDE` : JSON invalide
- `SCENES_VIDE` : scenes vide
- `SCENE_ID_INVALIDE` : scene_id invalide
- `ORDER_DUPLIQUE` : order dupliqué
- `TITLE_VIDE` : title vide
- `BLOCKS_VIDE` : blocks vide
- `BLOCK_TYPE_INVALIDE` : block_type invalide
- `CONTENT_VIDE` : content vide
- `POSITION_INVALIDE` : position invalide
- `SIZE_INVALIDE` : size invalide

**Version** : 1.0

**Compatibilité** : JSON Schema

**Références** :
- CONTRAT-004 : Contrat Storyboard

---

### CONTRAT-004 : Contrat Storyboard

**Nom** : Storyboard Data Contract

**Composants concernés** :
- Smart Whiteboard (tous composants)

**Structure** :
```json
{
  "id": "UUID",
  "project_id": "UUID",
  "scenes": [
    {
      "id": "UUID",
      "order": 0,
      "title": "string",
      "duration": 30,
      "blocks": [
        {
          "id": "UUID",
          "type": "text | image | diagram",
          "content": "string",
          "position": {"x": 0, "y": 0},
          "size": {"width": 100, "height": 100},
          "animation": "fade_in | slide_left | slide_right | zoom_in",
          "timing": {"start": 0, "end": 5}
        }
      ]
    }
  ],
  "metadata": {
    "total_duration": 300,
    "total_blocks": 50,
    "created_at": "ISO8601"
  }
}
```

**Types** :
- `id` : UUID v4
- `order` : integer >= 0
- `title` : string, max 200 caractères
- `duration` : integer >= 0 (secondes)
- `type` : enum (text, image, diagram)
- `content` : string, max 5000 caractères
- `position` : {x: integer, y: integer}
- `size` : {width: integer, height: integer}
- `animation` : enum (fade_in, slide_left, slide_right, zoom_in)
- `timing` : {start: integer, end: integer}

**Contraintes** :
- `scenes` : 1 à 50 scènes
- `blocks` : 1 à 20 blocs par scène
- `duration` : 10 à 300 secondes par scène
- `position` : 0 à 1920 (x), 0 à 1080 (y)
- `size` : 100 à 1920 (width), 100 à 1080 (height)

**Version** : 1.0

**Compatibilité** : JSON

**Références** :
- ADR-002 : Utilisation d'OpenRouter comme moteur de génération pédagogique

---

### CONTRAT-005 : Storyboard → Renderer

**Nom** : Storyboard to Renderer Contract

**Composants concernés** :
- Storyboard (JSON)
- Renderer (Kamatera)

**Entrées** :
```json
{
  "storyboard_id": "UUID",
  "project_id": "UUID",
  "renderer_id": "string",
  "theme_id": "string"
}
```

**Sorties** :
```json
{
  "render_id": "UUID",
  "status": "queued"
}
```

**Préconditions** :
- storyboard_id existe
- project_id existe
- renderer_id valide
- theme_id valide

**Postconditions** :
- Job de rendu créé dans app.whiteboard_renders
- Status = "queued"

**Erreurs possibles** :
- `STORYBOARD_NOT_FOUND` : storyboard_id invalide
- `PROJECT_NOT_FOUND` : project_id invalide
- `RENDERER_INVALIDE` : renderer_id invalide
- `THEME_INVALIDE` : theme_id invalide

**Version** : 1.0

**Compatibilité** : Kamatera Worker

**Références** :
- ADR-003 : Kamatera responsable du rendu vidéo

---

### CONTRAT-006 : Renderer → Kamatera

**Nom** : PNG → FFmpeg → MP4

**Composants concernés** :
- Renderer (Kamatera)
- FFmpeg
- Storage

**Entrées** :
- Storyboard JSON
- Renderer configuration
- Theme configuration

**Sorties** :
- MP4 file
- Duration
- Resolution
- FPS

**Formats** :
- **PNG** : 1920x1080, 24-bit color
- **MP4** : H.264 codec, AAC audio, 1920x1080, 30fps

**Résolution** :
- Input : 1920x1080 (Full HD)
- Output : 1920x1080 (Full HD)

**FPS** :
- Input : 30 fps
- Output : 30 fps

**Codecs** :
- Video : H.264 (libx264)
- Audio : AAC (aac)

**Bitrate** :
- Video : 5-10 Mbps
- Audio : 128 kbps

**Préconditions** :
- Storyboard valide
- Renderer disponible
- Espace disque suffisant

**Postconditions** :
- MP4 généré
- MP4 uploadé dans Storage
- URL accessible

**Erreurs possibles** :
- `STORYBOARD_INVALIDE` : Storyboard invalide
- `RENDERER_UNAVAILABLE` : Renderer indisponible
- `DISK_FULL` : Espace disque insuffisant
- `FFMPEG_ERROR` : Erreur FFmpeg
- `UPLOAD_ERROR` : Erreur upload Storage

**Version** : 1.0

**Compatibilité** : FFmpeg 4.0+, Kamatera

**Références** :
- ADR-003 : Kamatera responsable du rendu vidéo
- ADR-004 : Flutter ne génère jamais les vidéos

---

### CONTRAT-007 : Kamatera → Storage

**Nom** : Upload to Storage Contract

**Composants concernés** :
- Kamatera Worker
- Supabase Storage

**Entrées** :
- MP4 file
- project_id
- render_id

**Sorties** :
- Storage URL
- File path
- Metadata

**Upload** :
- Bucket : whiteboard-renders
- Path : /{project_id}/{render_id}.mp4
- Method : PUT

**Nommage** :
- Format : {render_id}.mp4
- Unique : Oui (UUID)

**Buckets** :
- whiteboard-renders : Vidéos MP4
- whiteboard-narrations : Fichiers audio (narration)

**Métadonnées** :
```json
{
  "project_id": "UUID",
  "render_id": "UUID",
  "duration": 300,
  "resolution": "1920x1080",
  "fps": 30,
  "codec": "h264",
  "created_at": "ISO8601"
}
```

**Préconditions** :
- MP4 file valide
- Bucket existe
- Permissions suffisantes

**Postconditions** :
- Fichier uploadé
- URL accessible
- Métadonnées stockées

**Erreurs possibles** :
- `FILE_INVALIDE` : Fichier invalide
- `BUCKET_NOT_FOUND` : Bucket inexistant
- `PERMISSION_DENIED` : Permissions insuffisantes
- `UPLOAD_FAILED` : Upload échoué

**Version** : 1.0

**Compatibilité** : Supabase Storage API

**Références** :
- ADR-003 : Kamatera responsable du rendu vidéo

---

### CONTRAT-008 : Storage → Flutter

**Nom** : Storage to Flutter Contract

**Composants concernés** :
- Supabase Storage
- Flutter (video_player)

**Entrées** :
- Storage URL
- project_id
- render_id

**Sorties** :
- VideoPlayer controller
- Duration
- Resolution

**URL** :
- Format : https://{bucket}.supabase.co/storage/v1/object/{path}
- TTL : 1 heure (signé URL)

**Lecture** :
- Streaming : Oui
- Download : Oui
- Cache : Flutter cache (video_player)

**Erreurs possibles** :
- `URL_INVALIDE` : URL invalide
- `FILE_NOT_FOUND` : Fichier introuvable
- `PERMISSION_DENIED` : Permissions insuffisantes
- `NETWORK_ERROR` : Erreur réseau
- `PLAYER_ERROR` : Erreur lecteur vidéo

**Cache** :
- Flutter cache : 100 MB max
- Cache duration : 24 heures
- Cache key : URL

**Version** : 1.0

**Compatibilité** : Flutter 3.0+, video_player 2.8.0+

**Références** :
- ADR-004 : Flutter ne génère jamais les vidéos

---

### CONTRAT-009 : RPC Whiteboard

**Nom** : app_whiteboard_create_project

**Composants concernés** :
- Flutter (SmartWhiteboardProvider)
- Supabase (RPC)

**Paramètres** :
```sql
p_user_id UUID
p_subject TEXT
p_content TEXT
p_mode TEXT
p_theme_id TEXT
p_renderer_id TEXT
p_narration_mode TEXT
```

**Retour** :
```json
{
  "id": "UUID",
  "user_id": "UUID",
  "subject": "string",
  "content": "string",
  "mode": "string",
  "theme_id": "string",
  "renderer_id": "string",
  "narration_mode": "string",
  "status": "draft",
  "created_at": "ISO8601"
}
```

**Erreurs possibles** :
- `USER_NOT_FOUND` : user_id invalide
- `MODE_INVALIDE` : mode invalide
- `THEME_INVALIDE` : theme_id invalide
- `RENDERER_INVALIDE` : renderer_id invalide
- `NARRATION_MODE_INVALIDE` : narration_mode invalide

**Version** : 1.0

**Compatibilité** : Supabase RPC

**Références** :
- ADR-005 : Supabase orchestre tout le pipeline
- ADR-007 : execute_ddl est la méthode officielle pour les opérations DDL

---

### CONTRAT-010 : RPC Whiteboard

**Nom** : whiteboard_create_render_job

**Composants concernés** :
- Flutter (SmartWhiteboardRenderService)
- Supabase (RPC)

**Paramètres** :
```sql
p_project_id UUID
```

**Retour** :
```json
{
  "id": "UUID",
  "project_id": "UUID",
  "status": "queued",
  "created_at": "ISO8601"
}
```

**Erreurs possibles** :
- `PROJECT_NOT_FOUND` : project_id invalide
- `STORYBOARD_NOT_FOUND` : storyboard_id invalide
- `RENDERER_INVALIDE` : renderer_id invalide

**Version** : 1.0

**Compatibilité** : Supabase RPC

**Références** :
- ADR-003 : Kamatera responsable du rendu vidéo
- ADR-005 : Supabase orchestre tout le pipeline

---

### CONTRAT-011 : RPC Whiteboard

**Nom** : whiteboard_get_render_status

**Composants concernés** :
- Flutter (SmartWhiteboardRenderService)
- Supabase (RPC)

**Paramètres** :
```sql
p_render_id UUID
```

**Retour** :
```json
{
  "id": "UUID",
  "project_id": "UUID",
  "status": "queued | processing | done | failed",
  "video_url": "string | null",
  "duration": "integer | null",
  "error_message": "string | null",
  "created_at": "ISO8601",
  "updated_at": "ISO8601"
}
```

**Erreurs possibles** :
- `RENDER_NOT_FOUND` : render_id invalide

**Version** : 1.0

**Compatibilité** : Supabase RPC

**Références** :
- ADR-003 : Kamatera responsable du rendu vidéo
- ADR-005 : Supabase orchestre tout le pipeline

---

### CONTRAT-012 : Base de données - Table whiteboard_projects

**Nom** : app.whiteboard_projects

**Composants concernés** :
- Supabase (Database)
- Flutter (SmartWhiteboardProvider)

**Colonnes** :
```sql
id UUID PRIMARY KEY
user_id UUID NOT NULL
subject TEXT NOT NULL
content TEXT
mode TEXT NOT NULL
theme_id TEXT NOT NULL
renderer_id TEXT NOT NULL
narration_mode TEXT NOT NULL
storyboard_id UUID
status TEXT NOT NULL
created_at TIMESTAMPTZ NOT NULL
updated_at TIMESTAMPTZ
```

**Contraintes** :
- `user_id` : FK vers auth.users
- `mode` : CHECK (mode IN ('simple', 'full_text', 'plan', 'existing_course'))
- `status` : CHECK (status IN ('draft', 'generating', 'ready', 'editing', 'rendering', 'done', 'failed'))

**Index** :
- `idx_user_id` : user_id
- `idx_status` : status
- `idx_created_at` : created_at

**RLS** :
- `SELECT` : Utilisateur peut voir ses propres projets
- `INSERT` : Utilisateur peut créer ses propres projets
- `UPDATE` : Utilisateur peut modifier ses propres projets
- `DELETE` : Utilisateur peut supprimer ses propres projets

**Relations** :
- `user_id` → auth.users(id)
- `storyboard_id` → app.whiteboard_ai_generations(id)

**Version** : 1.0

**Compatibilité** : PostgreSQL 15+

**Références** :
- ADR-005 : Supabase orchestre tout le pipeline
- ADR-007 : execute_ddl est la méthode officielle pour les opérations DDL

---

### CONTRAT-013 : Base de données - Table whiteboard_renders

**Nom** : app.whiteboard_renders

**Composants concernés** :
- Supabase (Database)
- Kamatera (Worker)
- Flutter (SmartWhiteboardRenderService)

**Colonnes** :
```sql
id UUID PRIMARY KEY
project_id UUID NOT NULL
status TEXT NOT NULL
video_url TEXT
duration INTEGER
error_message TEXT
created_at TIMESTAMPTZ NOT NULL
updated_at TIMESTAMPTZ
```

**Contraintes** :
- `project_id` : FK vers app.whiteboard_projects(id)
- `status` : CHECK (status IN ('queued', 'processing', 'done', 'failed'))

**Index** :
- `idx_project_id` : project_id
- `idx_status` : status
- `idx_created_at` : created_at

**RLS** :
- `SELECT` : Utilisateur peut voir ses propres rendus
- `INSERT` : Kamatera peut créer des rendus (via service role)
- `UPDATE` : Kamatera peut modifier des rendus (via service role)

**Relations** :
- `project_id` → app.whiteboard_projects(id)

**Version** : 1.0

**Compatibilité** : PostgreSQL 15+

**Références** :
- ADR-003 : Kamatera responsable du rendu vidéo
- ADR-005 : Supabase orchestre tout le pipeline
- ADR-007 : execute_ddl est la méthode officielle pour les opérations DDL

---

### CONTRAT-014 : Providers Flutter - SmartWhiteboardProvider

**Nom** : SmartWhiteboardProvider State Machine

**Composants concernés** :
- Flutter (SmartWhiteboardProvider)
- Flutter (SmartWhiteboardInputScreen)
- Flutter (SmartWhiteboardStoryboardEditorScreen)

**États** :
- `idle` : Aucune opération en cours
- `loading` : Chargement en cours
- `bobodoGenerating` : Génération du storyboard en cours
- `editing` : Édition du storyboard en cours
- `rendering` : Rendu vidéo en cours
- `done` : Vidéo générée avec succès
- `error` : Erreur survenue

**Transitions** :
- `idle` → `loading` : Chargement d'un projet existant
- `loading` → `idle` : Chargement terminé
- `loading` → `error` : Erreur de chargement
- `idle` → `bobodoGenerating` : Création d'un nouveau projet
- `bobodoGenerating` → `editing` : Génération terminée avec succès
- `bobodoGenerating` → `error` : Erreur de génération
- `editing` → `rendering` : Lancement du rendu
- `rendering` → `done` : Rendu terminé avec succès
- `rendering` → `error` : Erreur de rendu
- `done` → `idle` : Retour à l'état initial
- `error` → `idle` : Retour à l'état initial

**Événements** :
- `loadProject(project_id)` : Charger un projet existant
- `createProject(params)` : Créer un nouveau projet
- `generateStoryboard()` : Générer le storyboard
- `updateStoryboard(storyboard)` : Mettre à jour le storyboard
- `createRenderJob()` : Créer un job de rendu
- `pollRenderStatus()` : Poller le statut du rendu

**Erreurs** :
- `CREDITS_INSUFFICIENTS` : Solde insuffisant
- `PROJECT_NOT_FOUND` : Projet introuvable
- `GENERATION_FAILED` : Échec de la génération
- `RENDER_FAILED` : Échec du rendu

**Version** : 1.0

**Compatibilité** : Flutter 3.0+, Provider 6.0+

**Références** :
- ADR-005 : Supabase orchestre tout le pipeline

---

### CONTRAT-015 : Navigation Flutter - Smart Whiteboard

**Nom** : Smart Whiteboard Navigation Contract

**Composants concernés** :
- Flutter (student_challenges_tab.dart)
- Flutter (SmartWhiteboardInputScreen)
- Flutter (SmartWhiteboardStoryboardEditorScreen)
- Flutter (SmartWhiteboardPreviewScreen)
- Flutter (SmartWhiteboardProjectsListScreen)

**Écrans** :
1. **SmartWhiteboardInputScreen**
   - Entrée : Bouton + Challenge Feed
   - Sortie : SmartWhiteboardStoryboardEditorScreen (après génération)
   - Paramètres : project_id

2. **SmartWhiteboardStoryboardEditorScreen**
   - Entrée : SmartWhiteboardInputScreen
   - Sortie : SmartWhiteboardPreviewScreen (après sauvegarde)
   - Paramètres : project_id, storyboard_id

3. **SmartWhiteboardPreviewScreen**
   - Entrée : SmartWhiteboardStoryboardEditorScreen
   - Sortie : Retour à SmartWhiteboardStoryboardEditorScreen ou fermeture
   - Paramètres : project_id, render_id, video_url

4. **SmartWhiteboardProjectsListScreen**
   - Entrée : Menu principal ou SmartWhiteboardInputScreen
   - Sortie : SmartWhiteboardStoryboardEditorScreen (sélection projet)
   - Paramètres : Aucun

**Routes** :
- `/smart-whiteboard-input` : SmartWhiteboardInputScreen
- `/smart-whiteboard-editor` : SmartWhiteboardStoryboardEditorScreen
- `/smart-whiteboard-preview` : SmartWhiteboardPreviewScreen
- `/smart-whiteboard-projects` : SmartWhiteboardProjectsListScreen

**Navigation** :
- Bouton + → Modal → Smart Whiteboard → SmartWhiteboardInputScreen
- SmartWhiteboardInputScreen → Génération → SmartWhiteboardStoryboardEditorScreen
- SmartWhiteboardStoryboardEditorScreen → Sauvegarde → SmartWhiteboardPreviewScreen
- SmartWhiteboardPreviewScreen → Retour → SmartWhiteboardStoryboardEditorScreen

**Version** : 1.0

**Compatibilité** : Flutter 3.0+, Navigator 2.0+

**Références** :
- ADR-009 : Le projet Flutter officiel est exclusivement academia_app

---

## RÈGLE ABSOLUE

Aucun contrat documenté ne peut être modifié sans :

1. Mise à jour du registre (ACADEMIA_CONTRACT_REGISTRY.md)
2. Création d'un ADR si le changement est architectural
3. Mise à jour de la Truth Matrix si le niveau de validation évolue

---

## RÈGLE DE DÉMARRAGE

Avant toute modification d'une RPC, d'une Edge Function, d'un Provider Flutter, d'un Worker Kamatera ou d'une table Supabase, consulter obligatoirement le contrat correspondant dans ACADEMIA_CONTRACT_REGISTRY.md.

En cas d'absence d'un contrat, le créer avant toute modification.

---

## HISTORIQUE DES MODIFICATIONS

### 24 Juin 2026
- Création du registre des contrats techniques
- Enregistrement de 15 contrats initiaux (CONTRAT-001 à CONTRAT-015)
- CONTRAT-001 : Flutter → Edge Function
- CONTRAT-002 : Edge Function → OpenRouter
- CONTRAT-003 : OpenRouter → Validation
- CONTRAT-004 : Contrat Storyboard
- CONTRAT-005 : Storyboard → Renderer
- CONTRAT-006 : Renderer → Kamatera
- CONTRAT-007 : Kamatera → Storage
- CONTRAT-008 : Storage → Flutter
- CONTRAT-009 : RPC whiteboard_create_project
- CONTRAT-010 : RPC whiteboard_create_render_job
- CONTRAT-011 : RPC whiteboard_get_render_status
- CONTRAT-012 : Table whiteboard_projects
- CONTRAT-013 : Table whiteboard_renders
- CONTRAT-014 : Provider SmartWhiteboardProvider
- CONTRAT-015 : Navigation Flutter Smart Whiteboard
- Définition de la règle absolue
- Définition de la règle de démarrage

---

**Fin de ACADEMIA_CONTRACT_REGISTRY.md**
