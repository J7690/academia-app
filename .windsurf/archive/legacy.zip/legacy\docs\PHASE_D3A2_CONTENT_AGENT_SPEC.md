# PHASE D.3A.2 – CONTENT AGENT SPEC

**Date** : 23 Juin 2026  
**Phase** : D.3A.2 – IA Generation Architecture Refactor  
**Mode** : SPÉCIFICATION

---

## OBJECTIF

Spécifier le Smart Whiteboard Content Agent pour la génération de Storyboard JSON.

---

## DIRECTIVE

Le Content Agent est un agent spécialisé dissocié de Bobodo Assistant.

---

## PARTIE 1 – DÉFINITION

### 1.1 Nom

**Smart Whiteboard Content Agent**

### 1.2 Edge Function

**Nom** : `whiteboard-generate-storyboard`

**Chemin** : `supabase/functions/whiteboard-generate-storyboard/index.ts`

### 1.3 Responsabilités

- Génération Storyboard JSON valide
- Structuration pédagogique (scènes et blocs)
- Adaptation renderer/theme/narration
- Validation JSON stricte
- Gestion crédits Academia

---

## PARTIE 2 – INTERFACE

### 2.1 Entrée HTTP

**Méthode** : POST

**Headers** :
- `Authorization: Bearer <jwt>`
- `Content-Type: application/json`

**Body** :
```json
{
  "mode": "simple_subject|full_text|plan|existing_course",
  "subject": "string",
  "content": "string",
  "renderer": "scientific|notebook",
  "theme": "scientific|notebook",
  "narration_mode": "none|tts|user_recording"
}
```

### 2.2 Sortie HTTP

**Succès** (200) :
```json
{
  "success": true,
  "storyboard_json": {},
  "credits_used": 15,
  "model": "google/gemini-2.0-flash-001",
  "tokens_input": 500,
  "tokens_output": 2000
}
```

**Erreur crédits** (402) :
```json
{
  "error": "insufficient_credits",
  "balance": 5,
  "cost": 15,
  "message": "Crédits insuffisants. Il vous faut 15 crédits (solde: 5)."
}
```

**Erreur JSON** (500) :
```json
{
  "error": "invalid_json",
  "raw": "..."
}
```

**Erreur inconnue** (500) :
```json
{
  "error": "internal_error",
  "message": "..."
}
```

---

## PARTIE 3 – PROMPT SYSTÈME

### 3.1 Prompt Général

```
Tu es un expert en création de Storyboards pédagogiques pour le Smart Whiteboard Academia.

Ton rôle est de générer un Storyboard JSON valide qui sera utilisé pour créer une vidéo pédagogique.

RÈGLES STRICTES :
1. Le Storyboard doit être conforme au format JSON défini dans SMART_WHITEBOARD_DATA_CONTRACT.md
2. Structure le contenu en 5-10 scènes
3. Chaque scène contient 3-6 blocs
4. Utilise les types de blocs appropriés (title, paragraph, formula, definition, exercise, correction)
5. Adapte le contenu au renderer et au thème spécifiés
6. Le narration_mode est spécifié dans l'entrée

FORMAT JSON REQUIS :
{
  "version": "1.0",
  "created_at": "iso8601",
  "created_by": "uuid",
  "subject": "...",
  "renderer": "...",
  "theme": "...",
  "narration_mode": "...",
  "export_settings": {
    "resolution": "1080p",
    "fps": 30,
    "format": "mp4"
  },
  "scenes": [
    {
      "id": "uuid",
      "order": 0,
      "title": "...",
      "duration_ms": 5000,
      "transition": {},
      "blocks": [
        {
          "id": "uuid",
          "type": "title|paragraph|formula|definition|exercise|correction",
          "content": "...",
          "order": 0,
          "visible": true,
          "animation": {},
          "position": {},
          "style": {}
        }
      ]
    }
  ]
}

RÉPONSE :
Réponds UNIQUEMENT avec le JSON valide, sans markdown, sans commentaire.
```

### 3.2 Prompts Spécifiques par Mode

#### Mode A : Sujet Simple

```
Génère un Storyboard JSON valide pour le sujet : "{subject}"

Le sujet est simple. Structure le contenu de manière pédagogique :
- Introduction au sujet
- Définitions clés
- Exemples concrets
- Exercice d'application
- Correction

Utilise le renderer "{renderer}" et le thème "{theme}".
```

#### Mode B : Texte Complet

```
Génère un Storyboard JSON valide à partir du texte complet fourni.

SUJET : "{subject}"

TEXTE COMPLET :
"{content}"

Structure le contenu en scènes basées sur le texte :
- Résumé du texte
- Points clés
- Définitions importantes
- Exemples du texte
- Exercice basé sur le texte
- Correction

Utilise le renderer "{renderer}" et le thème "{theme}".
```

#### Mode C : Plan

```
Génère un Storyboard JSON valide à partir du plan structuré fourni.

SUJET : "{subject}"

PLAN :
"{content}"

Structure le contenu en scènes basées sur le plan (une scène par section) :
- Développe chaque section du plan en détail
- Ajoute des exemples pour chaque section
- Inclut un exercice d'application
- Fournis la correction

Utilise le renderer "{renderer}" et le thème "{theme}".
```

#### Mode D : Cours Existant

```
Génère un Storyboard JSON valide à partir du cours existant.

COURS ID : {content}
SUJET : "{subject}"

Structure le contenu en scènes basées sur le cours :
- Résumé du cours
- Points clés du cours
- Définitions importantes
- Exemples du cours
- Exercice basé sur le cours
- Correction

Utilise le renderer "{renderer}" et le thème "{theme}".
```

---

## PARTIE 4 – VALIDATION JSON

### 4.1 Fonction de Validation

```typescript
function validateStoryboard(json: unknown): { valid: boolean; error?: string } {
  // Vérifier type
  if (!json || typeof json !== 'object') {
    return { valid: false, error: 'Not an object' };
  }
  
  const sb = json as Record<string, unknown>;
  
  // Champs obligatoires
  const required = ['version', 'created_at', 'created_by', 'subject', 'renderer', 'theme', 'narration_mode', 'scenes'];
  for (const field of required) {
    if (!(field in sb)) {
      return { valid: false, error: `Missing field: ${field}` };
    }
  }
  
  // Version
  if (sb.version !== '1.0') {
    return { valid: false, error: 'Invalid version' };
  }
  
  // Scenes
  if (!Array.isArray(sb.scenes)) {
    return { valid: false, error: 'scenes is not an array' };
  }
  
  if (sb.scenes.length === 0) {
    return { valid: false, error: 'scenes is empty' };
  }
  
  if (sb.scenes.length > 20) {
    return { valid: false, error: 'scenes too many (max 20)' };
  }
  
  // Chaque scène
  for (const scene of sb.scenes) {
    if (!scene || typeof scene !== 'object') {
      return { valid: false, error: 'Invalid scene' };
    }
    
    const s = scene as Record<string, unknown>;
    
    // Champs scène obligatoires
    const sceneRequired = ['id', 'order', 'title', 'duration_ms', 'blocks'];
    for (const field of sceneRequired) {
      if (!(field in s)) {
        return { valid: false, error: `Scene missing field: ${field}` };
      }
    }
    
    // Blocks
    if (!Array.isArray(s.blocks)) {
      return { valid: false, error: 'Scene blocks is not an array' };
    }
    
    if (s.blocks.length === 0) {
      return { valid: false, error: 'Scene blocks is empty' };
    }
    
    if (s.blocks.length > 10) {
      return { valid: false, error: 'Scene blocks too many (max 10)' };
    }
    
    // Chaque bloc
    for (const block of s.blocks) {
      if (!block || typeof block !== 'object') {
        return { valid: false, error: 'Invalid block' };
      }
      
      const b = block as Record<string, unknown>;
      
      // Champs bloc obligatoires
      const blockRequired = ['id', 'type', 'content', 'order', 'visible', 'style'];
      for (const field of blockRequired) {
        if (!(field in b)) {
          return { valid: false, error: `Block missing field: ${field}` };
        }
      }
      
      // Type valide
      const validTypes = ['title', 'paragraph', 'formula', 'definition', 'exercise', 'correction'];
      if (!validTypes.includes(b.type as string)) {
        return { valid: false, error: `Invalid block type: ${b.type}` };
      }
    }
  }
  
  // Taille JSON
  const jsonStr = JSON.stringify(sb);
  if (jsonStr.length > 100000) {
    return { valid: false, error: 'Storyboard too large (max 100KB)' };
  }
  
  return { valid: true };
}
```

### 4.2 Gestion Erreurs

**JSON invalide** :
```typescript
const validation = validateStoryboard(parsed);
if (!validation.valid) {
  await supabase.rpc('app_student_refund_credits', { p_reservation_id: reservationId });
  return jsonResponse({ 
    error: 'invalid_json', 
    detail: validation.error,
    raw: rawResponse.slice(0, 500)
  }, 500);
}
```

---

## PARTIE 5 – CASCADE MULTI-MODÈLES

### 5.1 Configuration

```typescript
const TEXT_CASCADE = [
  { model: 'google/gemini-2.0-flash-001', tier: 'primary' },
  { model: 'google/gemini-2.0-flash-lite-001', tier: 'fallback' },
  { model: 'nvidia/nemotron-3-super-120b-a12b:free', tier: 'fallback' },
  { model: 'qwen/qwen3.6-plus:free', tier: 'fallback' },
].filter(m => m.model);
```

### 5.2 Implémentation

```typescript
interface CascadeResult {
  content: string;
  model: string;
  tier: string;
  usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
  costUsd: number;
}

async function callWithCascade(
  msgs: Array<{role: string; content: string}>,
  maxTok: number
): Promise<CascadeResult> {
  const errs: string[] = [];
  
  for (const { model, tier } of TEXT_CASCADE) {
    if (!model) continue;
    
    try {
      const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${OPENROUTER_API_KEY}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          model,
          messages: msgs,
          temperature: 0.2,
          max_tokens: maxTok,
        }),
      });
      
      if (!r.ok) {
        errs.push(`${model}(${r.status})`);
        continue;
      }
      
      const d = await r.json();
      const c = (d?.choices?.[0]?.message?.content ?? '').toString().trim();
      
      if (!c) {
        errs.push(`${model}:empty`);
        continue;
      }
      
      const u = d?.usage ?? { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 };
      const cost = tier === 'free' ? 0 : ((u.prompt_tokens || 0) * 0.0000001 + (u.completion_tokens || 0) * 0.0000004);
      
      console.log(`[cascade] OK: ${model} (${tier}) ${u.total_tokens}tok $${cost.toFixed(6)}`);
      
      return { content: c, model, tier, usage: u, costUsd: cost };
    } catch (e) {
      errs.push(`${model}:${(e as Error).message?.slice(0, 60)}`);
    }
  }
  
  throw new Error(`All models failed: ${errs.join(' | ')}`);
}
```

---

## PARTIE 6 – CRÉDITS

### 6.1 Action Code

**Action Code** : `generate_storyboard`

### 6.2 Prix

**Prix** : 15 crédits

**Raison** :
- Input : ~500 tokens
- Output : ~2000 tokens
- Coût USD : ~$0.0015
- Conversion : 15 crédits

### 6.3 Pattern Réserve→Confirme→Rembourse

```typescript
// Réserve
const { data: resData } = await supabase.rpc('app_student_reserve_credits', {
  p_action_code: 'generate_storyboard',
  p_edge_function: 'whiteboard-generate-storyboard',
  p_student_id: userId,
});
const res = resData as Record<string, unknown> | null;
if (!res?.success) {
  return jsonResponse({ 
    error: 'insufficient_credits', 
    balance: res?.balance ?? 0, 
    cost: res?.cost ?? 0,
    message: `Crédits insuffisants. Il vous faut ${res?.cost ?? 0} crédits (solde: ${res?.balance ?? 0}).` 
  }, 402);
}
const reservationId = (res.reservation_id as string) || '';

// Appel LLM
let cascadeResult: CascadeResult;
try {
  cascadeResult = await callWithCascade(messages, 4000);
} catch (e) {
  await supabase.rpc('app_student_refund_credits', { p_reservation_id: reservationId });
  return jsonResponse({ error: 'llm_error', detail: (e as Error).message?.slice(0, 300) }, 502);
}

// Confirme
await supabase.rpc('app_student_confirm_credits', {
  p_reservation_id: reservationId,
  p_openrouter_cost_usd: cascadeResult.costUsd,
  p_openrouter_model: cascadeResult.model,
  p_tokens_input: cascadeResult.usage.prompt_tokens || 0,
  p_tokens_output: cascadeResult.usage.completion_tokens || 0,
});
```

---

## PARTIE 7 – STOCKAGE SUPABASE

### 7.1 RPC Utilisée

**RPC** : `app_whiteboard_create_project`

**Signature** :
```sql
app_whiteboard_create_project(
  p_student_id UUID,
  p_subject TEXT,
  p_renderer_id TEXT,
  p_theme_id TEXT,
  p_narration_mode TEXT,
  p_storyboard_json JSONB
) RETURNS JSONB
```

### 7.2 Appel RPC

```typescript
const { data: projectData } = await supabase.rpc('app_whiteboard_create_project', {
  p_student_id: userId,
  p_subject: body.subject,
  p_renderer_id: body.renderer,
  p_theme_id: body.theme,
  p_narration_mode: body.narration_mode,
  p_storyboard_json: parsed,
});
```

---

## PARTIE 8 – LOGGING

### 8.1 Logging Génération

**Table** : `whiteboard_ai_generations`

**Insertion** :
```typescript
const logSql = `
  INSERT INTO app.whiteboard_ai_generations (
    created_by,
    generation_type,
    input_params,
    output_json,
    status,
    model_used,
    tokens_input,
    tokens_output,
    cost_usd
  ) VALUES (
    '${userId}',
    'storyboard',
    '${JSON.stringify(body).replace(/'/g, "''")}'::jsonb,
    '${JSON.stringify(parsed).replace(/'/g, "''")}'::jsonb,
    'validated',
    '${cascadeResult.model}',
    ${cascadeResult.usage.prompt_tokens || 0},
    ${cascadeResult.usage.completion_tokens || 0},
    ${cascadeResult.costUsd}
  )
`.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();

await supabase.rpc('admin_execute_sql', { p_sql: logSql });
```

---

## CONCLUSION

### Spécification Complète

Le Smart Whiteboard Content Agent est spécifié avec :
- ✅ Interface HTTP claire
- ✅ Prompts système par mode
- ✅ Validation JSON stricte
- ✅ Cascade multi-modèles
- ✅ Gestion crédits
- ✅ Stockage Supabase
- ✅ Logging complet

### Prochaine Étape

Créer le document PHASE_D3A2_IMPLEMENTATION_ROADMAP.md pour le plan d'implémentation.

---

**Fin de PHASE D.3A.2 – CONTENT AGENT SPEC**
