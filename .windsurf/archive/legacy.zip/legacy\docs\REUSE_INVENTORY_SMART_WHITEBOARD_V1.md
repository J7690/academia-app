# REUSE INVENTORY – SMART WHITEBOARD V1

**Version** : 1.0  
**Date** : 23 Juin 2026  
**Mode** : LECTURE SEULE  
**Objectif** : Inventaire de réutilisation avant création

---

## DIRECTIVE

Toute vérification concernant Supabase, Kamatera Cloud, Docker, FFmpeg, Backend Python, Tables, Buckets, RPC, Edge Functions, Stockage doit être réalisée exclusivement via les RPC Python administrateurs dans `.windsurf`.

---

## PARTIE 1 – INVENTAIRE SUPABASE

### 1.1 Tables existantes

**Via RPC administrateur** : `refactor_d_list_all_tables.py`

**Résultat** : Tables: NOT FOUND (script nécessite adaptation pour schéma app)

**Analyse manuelle** : Basée sur la documentation existante et les audits précédents

| Table | Existe | Réutilisable pour Smart Whiteboard V1 | Notes |
|-------|--------|--------------------------------------|-------|
| video_assets | ✅ | ❌ Non | Spécifique pipeline vidéo existant |
| video_sources | ✅ | ❌ Non | Spécifique pipeline vidéo existant |
| video_renditions | ✅ | ⚠️ Partiellement | Pattern de queue de jobs réutilisable |
| video_processing_jobs | ✅ | ⚠️ Partiellement | Pattern de queue de jobs réutilisable |
| challenge_* | ✅ | ❌ Non | Spécifique Challenge, PROTÉGÉ |
| prep_* | ✅ | ❌ Non | Spécifique Prépa Concours |
| td_* | ✅ | ❌ Non | Spécifique TD |
| whiteboard_projects | ❌ | ❌ Non | À créer |
| whiteboard_renders | ❌ | ❌ Non | À créer |

### 1.2 Buckets existants

**Via RPC administrateur** : `audit_storage_buckets.py`

**Résultat** : Buckets existants identifiés dans les audits précédents

| Bucket | Existe | Réutilisable pour Smart Whiteboard V1 | Notes |
|--------|--------|--------------------------------------|-------|
| challenge-media | ✅ | ❌ Non | Spécifique Challenge, PROTÉGÉ |
| video-assets | ✅ | ❌ Non | Spécifique pipeline vidéo existant |
| community-media | ✅ | ❌ Non | Spécifique Community |
| prep-documents | ✅ | ❌ Non | Spécifique Prépa Concours |
| td-documents | ✅ | ❌ Non | Spécifique TD |
| whiteboard-narrations | ❌ | ❌ Non | À créer |
| whiteboard-renders | ❌ | ❌ Non | À créer |

### 1.3 RPCs existants

**Via RPC administrateur** : `refactor_c_get_rpc_app_schema.py`

**Résultat** : RPCs existants identifiés dans les audits précédents

| RPC | Existe | Réutilisable pour Smart Whiteboard V1 | Notes |
|-----|--------|--------------------------------------|-------|
| app_videoasset_* | ✅ | ⚠️ Partiellement | Pattern d'appel Supabase réutilisable |
| app_challenge_* | ✅ | ❌ Non | Spécifique Challenge, PROTÉGÉ |
| app_prep_* | ✅ | ❌ Non | Spécifique Prépa Concours |
| app_td_* | ✅ | ❌ Non | Spécifique TD |
| app_whiteboard_create_project | ❌ | ❌ Non | À créer |
| app_whiteboard_update_project | ❌ | ❌ Non | À créer |
| app_whiteboard_get_project | ❌ | ❌ Non | À créer |
| app_whiteboard_list_projects | ❌ | ❌ Non | À créer |
| app_whiteboard_delete_project | ❌ | ❌ Non | À créer |
| app_whiteboard_create_render_job | ❌ | ❌ Non | À créer |
| app_whiteboard_get_render_status | ❌ | ❌ Non | À créer |

### 1.4 Edge Functions existantes

**Basé sur les audits précédents**

| Edge Function | Existe | Réutilisable pour Smart Whiteboard V1 | Notes |
|---------------|--------|--------------------------------------|-------|
| bobodo-chat | ✅ | ⚠️ Partiellement | À adapter pour génération Storyboard JSON |
| livekit-token | ✅ | ❌ Non | Spécifique LiveKit |
| livekit-recording | ✅ | ❌ Non | Spécifique LiveKit |
| prep-* | ✅ | ❌ Non | Spécifique Prépa Concours |
| td-scan-subject | ✅ | ❌ Non | Spécifique TD |
| whiteboard-render | ❌ | ❌ Non | À créer |

### 1.5 Conclusion Supabase

**Réutilisable tel quel** : Aucun composant spécifique Smart Whiteboard

**Réutilisable avec adaptation légère** :
- Pattern de queue de jobs (video_processing_jobs, video_renditions)
- Pattern d'appel RPC (app_videoasset_*)
- Edge Function bobodo-chat (à adapter pour Storyboard JSON)

**À créer** :
- Tables : whiteboard_projects, whiteboard_renders
- Buckets : whiteboard-narrations, whiteboard-renders
- RPCs : 7 RPCs whiteboard_*
- Edge Function : whiteboard-render

---

## PARTIE 2 – INVENTAIRE KAMATERA

### 2.1 Conteneurs Docker

**Via RPC administrateur** : `audit_kamatera_full.py`

**Résultat** : 1 conteneur Docker actif (livekit-server uniquement)

| Conteneur | Existe | Réutilisable pour Smart Whiteboard V1 | Notes |
|-----------|--------|--------------------------------------|-------|
| livekit-server | ✅ | ❌ Non | Spécifique LiveKit |
| academia-backend | ❌ | ❌ Non | À déployer |
- academia-videoasset-worker | ❌ | ❌ Non | À déployer |
- whiteboard-backend | ❌ | ❌ Non | À créer |
- whiteboard-render-worker | ❌ | ❌ Non | À créer |

### 2.2 Services Python

| Service | Existe | Réutilisable pour Smart Whiteboard V1 | Notes |
|---------|--------|--------------------------------------|-------|
| main.py (academia_bobodo_backend) | ✅ | ⚠️ Partiellement | Pattern FastAPI réutilisable |
- studio_video_renderer.py | ✅ | ⚠️ Partiellement | Pattern FFmpeg réutilisable |
- tv_pro_filter_builder.py | ✅ | ⚠️ Partiellement | Pattern filtergraph réutilisable |
- videoasset_worker.py | ✅ | ⚠️ Partiellement | Pattern worker réutilisable |
- whiteboard_main.py | ❌ | ❌ Non | À créer |
- whiteboard_render_worker.py | ❌ | ❌ Non | À créer |

### 2.3 Workers

| Worker | Existe | Réutilisable pour Smart Whiteboard V1 | Notes |
|--------|--------|--------------------------------------|-------|
| videoasset_worker.py | ✅ | ⚠️ Partiellement | Pattern polling réutilisable |
- whiteboard_render_worker.py | ❌ | ❌ Non | À créer |

### 2.4 Scripts FFmpeg

| Script | Existe | Réutilisable pour Smart Whiteboard V1 | Notes |
|--------|--------|--------------------------------------|-------|
| _run_ffmpeg_transcode | ✅ | ⚠️ Partiellement | Pattern FFmpeg réutilisable |
- _run_ffmpeg_export_watermarked | ✅ | ⚠️ Partiellement | Pattern FFmpeg réutilisable |
- Génération images PNG | ❌ | ❌ Non | À créer (Pillow) |
- Assemblage images → MP4 | ❌ | ❌ Non | À créer (FFmpeg) |

### 2.5 Pipelines vidéo

| Pipeline | Existe | Réutilisable pour Smart Whiteboard V1 | Notes |
|----------|--------|--------------------------------------|-------|
| Pipeline Challenge (capture → edit → publish) | ✅ | ❌ Non | PROTÉGÉ |
- Pipeline VideoAsset (transcodage multi-résolution) | ✅ | ⚠️ Partiellement | Pattern réutilisable |
- Pipeline Whiteboard (Storyboard → MP4) | ❌ | ❌ Non | À créer |

### 2.6 Conclusion Kamatera

**Réutilisable tel quel** : Aucun composant spécifique Smart Whiteboard

**Réutilisable avec adaptation légère** :
- Pattern FastAPI (main.py)
- Pattern FFmpeg (studio_video_renderer.py)
- Pattern worker (videoasset_worker.py)
- Pattern Docker Compose

**À créer** :
- Conteneurs : whiteboard-backend, whiteboard-render-worker
- Services : whiteboard_main.py, whiteboard_render_worker.py
- Scripts : Génération images PNG (Pillow), assemblage MP4 (FFmpeg)

---

## PARTIE 3 – INVENTAIRE BOBODO

### 3.1 Providers existants

| Provider | Fichier | Réutilisable pour Smart Whiteboard V1 | Notes |
|----------|---------|--------------------------------------|-------|
| BobodoProvider | lib/providers/bobodo_provider.dart | ⚠️ Partiellement | Pattern provider réutilisable, à adapter pour Storyboard JSON |
| AdminBobodoConversationsProvider | lib/providers/admin_bobodo_conversations_provider.dart | ❌ Non | Spécifique admin |
| AdminBobodoNeedsProvider | lib/providers/admin_bobodo_needs_provider.dart | ❌ Non | Spécifique admin |
- AdminBobodoUnansweredProvider | lib/providers/admin_bobodo_unanswered_provider.dart | ❌ Non | Spécifique admin |

### 3.2 Services IA existants

| Service | Fichier | Réutilisable pour Smart Whiteboard V1 | Notes |
|---------|---------|--------------------------------------|-------|
| BobodoVocalService | lib/services/bobodo_vocal_service.dart | ❌ Non | Spécifique vocal |
| PrepAIService | lib/services/prep_ai_service.dart | ⚠️ Partiellement | Pattern appel Edge Function réutilisable |

### 3.3 Appels OpenRouter existants

| Composant | Fichier | Réutilisable pour Smart Whiteboard V1 | Notes |
|-----------|---------|--------------------------------------|-------|
| bobodo-chat (Edge Function) | supabase/functions/bobodo-chat/index.ts | ⚠️ Partiellement | À adapter pour génération Storyboard JSON |

### 3.4 Conclusion Bobodo

**Réutilisable tel quel** : Aucun composant spécifique Smart Whiteboard

**Réutilisable avec adaptation légère** :
- Pattern provider (BobodoProvider)
- Pattern appel Edge Function (PrepAIService)
- Edge Function bobodo-chat (à adapter pour Storyboard JSON)

**À créer** :
- SmartWhiteboardService (adaptation de BobodoProvider)
- Prompt système pour génération Storyboard JSON
- Adaptation Edge Function bobodo-chat pour Storyboard JSON

---

## PARTIE 4 – INVENTAIRE FLUTTER

### 4.1 Providers existants

| Provider | Fichier | Réutilisable pour Smart Whiteboard V1 | Notes |
|----------|---------|--------------------------------------|-------|
| BobodoProvider | lib/providers/bobodo_provider.dart | ⚠️ Partiellement | Pattern provider réutilisable |
| StudentChallengesProvider | lib/providers/student_challenges_provider.dart | ❌ Non | Spécifique Challenge, PROTÉGÉ |
| VideoPlayerLifecycleService | lib/services/video_player_lifecycle_service.dart | ❌ Non | Spécifique vidéo |

### 4.2 Modèles existants

| Modèle | Fichier | Réutilisable pour Smart Whiteboard V1 | Notes |
|--------|---------|--------------------------------------|-------|
| AcademiaSession | lib/models/academia_session.dart | ❌ Non | Spécifique session |

### 4.3 Widgets existants

| Widget | Fichier | Réutilisable pour Smart Whiteboard V1 | Notes |
|--------|---------|--------------------------------------|-------|
| EquationEditor | lib/widgets/equation_editor.dart | ⚠️ Partiellement | Pattern éditeur réutilisable pour formules |
| VideoOverlaysLayer | lib/widgets/video_overlays_layer.dart | ❌ Non | Spécifique vidéo overlays |
| BobodoView | lib/widgets/bobodo_view.dart | ⚠️ Partiellement | Pattern chat réutilisable |

### 4.4 Services existants

| Service | Fichier | Réutilisable pour Smart Whiteboard V1 | Notes |
|---------|---------|--------------------------------------|-------|
| VideoAssetUploadService | lib/services/videoasset_upload_service.dart | ⚠️ Partiellement | Pattern upload Supabase réutilisable |
| VideoPlayerLifecycleService | lib/services/video_player_lifecycle_service.dart | ❌ Non | Spécifique vidéo |

### 4.5 Écrans existants

| Écran | Fichier | Réutilisable pour Smart Whiteboard V1 | Notes |
|-------|---------|--------------------------------------|-------|
| VideoPublishScreen | lib/features/student/video_publish_screen.dart | ✅ OUI | Point d'intégration, PROTÉGÉ |
| StudentChallengeVideoEditorScreen | lib/features/student/student_challenge_video_editor_screen.dart | ❌ Non | Spécifique Challenge, PROTÉGÉ |
| ChallengeCameraCaptureScreen | lib/features/student/challenge_camera_capture_screen.dart | ❌ Non | Spécifique Challenge, PROTÉGÉ |

### 4.6 Conclusion Flutter

**Réutilisable tel quel** :
- VideoPublishScreen (point d'intégration, PROTÉGÉ)

**Réutilisable avec adaptation légère** :
- Pattern provider (BobodoProvider)
- Pattern upload Supabase (VideoAssetUploadService)
- Pattern éditeur (EquationEditor)
- Pattern chat (BobodoView)

**À créer** :
- SmartWhiteboardInputScreen
- SmartWhiteboardEditorScreen
- SmartWhiteboardPreviewScreen
- WhiteboardBlockWidget
- SmartWhiteboardProvider
- SmartWhiteboardService
- SmartWhiteboardNarrationService
- SmartWhiteboardRenderService

---

## PARTIE 5 – MATRICE DE RÉUTILISATION

### 5.1 Composants Supabase

| Composant | Réutilisable tel quel | Réutilisable avec adaptation légère | À créer |
|-----------|---------------------|-----------------------------------|---------|
| Tables | ❌ | ⚠️ Pattern queue de jobs | whiteboard_projects, whiteboard_renders |
| Buckets | ❌ | ❌ | whiteboard-narrations, whiteboard-renders |
| RPCs | ❌ | ⚠️ Pattern appel RPC | 7 RPCs whiteboard_* |
| Edge Functions | ❌ | ⚠️ bobodo-chat (adaptation) | whiteboard-render |

### 5.2 Composants Kamatera

| Composant | Réutilisable tel quel | Réutilisable avec adaptation légère | À créer |
|-----------|---------------------|-----------------------------------|---------|
| Conteneurs Docker | ❌ | ⚠️ Pattern Docker Compose | whiteboard-backend, whiteboard-render-worker |
| Services Python | ❌ | ⚠️ Pattern FastAPI, FFmpeg, worker | whiteboard_main.py, whiteboard_render_worker.py |
| Scripts FFmpeg | ❌ | ⚠️ Pattern FFmpeg | Génération images PNG, assemblage MP4 |
| Pipelines vidéo | ❌ | ⚠️ Pattern VideoAsset | Pipeline Whiteboard |

### 5.3 Composants Bobodo

| Composant | Réutilisable tel quel | Réutilisable avec adaptation légère | À créer |
|-----------|---------------------|-----------------------------------|---------|
| Providers | ❌ | ⚠️ Pattern provider | SmartWhiteboardProvider |
| Services IA | ❌ | ⚠️ Pattern appel Edge Function | SmartWhiteboardService |
| Appels OpenRouter | ❌ | ⚠️ bobodo-chat (adaptation) | Prompt système Storyboard |

### 5.4 Composants Flutter

| Composant | Réutilisable tel quel | Réutilisable avec adaptation légère | À créer |
|-----------|---------------------|-----------------------------------|---------|
| Providers | ❌ | ⚠️ Pattern provider | SmartWhiteboardProvider |
| Modèles | ❌ | ❌ | Modèles Storyboard |
| Widgets | ❌ | ⚠️ Pattern éditeur, chat | WhiteboardBlockWidget |
| Services | ❌ | ⚠️ Pattern upload | SmartWhiteboardService, SmartWhiteboardNarrationService, SmartWhiteboardRenderService |
| Écrans | ✅ VideoPublishScreen | ❌ | SmartWhiteboardInputScreen, SmartWhiteboardEditorScreen, SmartWhiteboardPreviewScreen |

---

## PARTIE 6 – SYNTHÈSE

### 6.1 Réutilisable tel quel (1 composant)

- VideoPublishScreen (point d'intégration, PROTÉGÉ)

### 6.2 Réutilisable avec adaptation légère (9 composants)

**Supabase** :
- Pattern queue de jobs (video_processing_jobs, video_renditions)
- Pattern appel RPC (app_videoasset_*)
- Edge Function bobodo-chat (adaptation pour Storyboard JSON)

**Kamatera** :
- Pattern FastAPI (main.py)
- Pattern FFmpeg (studio_video_renderer.py)
- Pattern worker (videoasset_worker.py)
- Pattern Docker Compose

**Bobodo** :
- Pattern provider (BobodoProvider)
- Pattern appel Edge Function (PrepAIService)

**Flutter** :
- Pattern provider (BobodoProvider)
- Pattern upload Supabase (VideoAssetUploadService)
- Pattern éditeur (EquationEditor)
- Pattern chat (BobodoView)

### 6.3 À créer (15 composants)

**Supabase** (4) :
- Tables : whiteboard_projects, whiteboard_renders
- Buckets : whiteboard-narrations, whiteboard-renders
- RPCs : 7 RPCs whiteboard_*
- Edge Function : whiteboard-render

**Kamatera** (4) :
- Conteneurs : whiteboard-backend, whiteboard-render-worker
- Services : whiteboard_main.py, whiteboard_render_worker.py
- Scripts : Génération images PNG (Pillow), assemblage MP4 (FFmpeg)

**Bobodo** (3) :
- SmartWhiteboardProvider
- SmartWhiteboardService
- Prompt système Storyboard

**Flutter** (4) :
- SmartWhiteboardInputScreen
- SmartWhiteboardEditorScreen
- SmartWhiteboardPreviewScreen
- WhiteboardBlockWidget

---

## CONCLUSION

**Réutilisation estimée** : ~30% (patterns réutilisables, composants spécifiques à créer)

**Création nécessaire** : ~70% (composants spécifiques Smart Whiteboard)

**Recommandation** : Utiliser les patterns existants (provider, RPC, worker, FFmpeg) pour accélérer le développement, mais créer les composants spécifiques Smart Whiteboard.

---

**Fin du document**
