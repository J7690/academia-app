# MISSION D.15 – RAPPORT DE VALIDATION FONCTIONNELLE

**Date**: 2026-06-26
**Version app**: 1.0.6+11
**Statut**: ❌ POINT DE RUPTURE IDENTIFIÉ

---

## RÉSUMÉ

L'analyse du flux fonctionnel Smart Whiteboard a identifié un **point de rupture critique** dans l'Edge Function `whiteboard-generate-storyboard`. Cette Edge Function appelle une RPC qui a été supprimée lors de la normalisation SQL (MISSION D.13).

**Aucune hypothèse**: la preuve est issue de `pg_proc` et du code source TypeScript.

---

## FLUX ANALYSÉ

```
UI Flutter (smart_whiteboard_input_screen.dart)
  ↓ _handleGenerate()
SmartWhiteboardProvider (smart_whiteboard_provider.dart)
  ↓ createProject() → generateStoryboard()
SmartWhiteboardService (smart_whiteboard_service.dart)
  ↓ _supabase.rpc('whiteboard_create_project')
Supabase RPC public.whiteboard_create_project ✅ (créée en D.14)
  ↓ retourne project_id
SmartWhiteboardProvider
  ↓ client.functions.invoke('whiteboard-generate-storyboard')
Edge Function whiteboard-generate-storyboard/index.ts
  ↓ ligne 451: supabase.rpc('app_whiteboard_create_project', ...)
❌ RPC app_whiteboard_create_project SUPPRIMÉE en D.13
```

---

## PREMIER POINT DE RUPTURE

### Fichier exact

`supabase/functions/whiteboard-generate-storyboard/index.ts`

### Ligne exacte

451

### Code fautif

```typescript
@supabase/functions/whiteboard-generate-storyboard/index.ts:451
    const { data: projectData } = await supabase.rpc('app_whiteboard_create_project', {
      p_student_id: userId,
      p_subject: subject,
      p_renderer_id: renderer,
      p_theme_id: theme,
      p_narration_mode: narrationMode,
      p_storyboard_json: sb,
    });
```

### Variable fautive

`'app_whiteboard_create_project'` — le nom de la RPC appelée.

### Valeur réelle observée

Preuve pg_proc:
```
Nombre de fonctions app_whiteboard_create_project trouvées: 0
```

La RPC `app_whiteboard_create_project` n'existe plus dans `pg_proc`.

### Preuve pg_proc

Requête exécutée:
```sql
SELECT
    n.nspname,
    p.proname,
    pg_get_function_identity_arguments(p.oid)
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE p.proname = 'app_whiteboard_create_project'
ORDER BY n.nspname, p.proname;
```

Résultat:
```json
[]
```

### Stacktrace prévisible

Lorsque l'Edge Function exécute `supabase.rpc('app_whiteboard_create_project', ...)`, PostgREST retournera:

```
PGRST201: Could not find the function public.app_whiteboard_create_project in the schema cache
```

ou, selon la configuration Supabase:

```
{"message":"Could not find the function 'app_whiteboard_create_project' in the schema 'public'","code":"PGRST201","details":null,"hint":null}
```

L'Edge Function catchera cette erreur dans le bloc `try/catch` global (ligne 508) et retournera:

```json
{
  "error": "internal_error",
  "detail": "Could not find the function public.app_whiteboard_create_project..."
}
```

---

## IMPACT SUR LE FLUTTER

Dans `smart_whiteboard_provider.dart` ligne 133:

```dart
final response = await client.functions.invoke(
  'whiteboard-generate-storyboard',
  body: { ... },
);
```

Le `response.status` sera 500 (et non 200), ce qui déclenchera l'affichage d'une erreur à l'utilisateur via le SnackBar ligne 153-159:

```dart
if (response.status != 200) {
  final errorData = response.data as Map<String, dynamic>?;
  if (errorData?['error'] == 'insufficient_credits') { ... }
  else if (errorData?['error'] == 'invalid_json') { ... }
  else if (errorData?['error'] == 'invalid_storyboard') { ... }
  else {
    _setError(errorData?['error'] ?? 'Failed to generate storyboard');
  }
  return;
}
```

L'utilisateur verra: **"Failed to generate storyboard"** ou le message d'erreur interne de l'Edge Function.

---

## CORRECTION PROPOSÉE

Remplacer dans `supabase/functions/whiteboard-generate-storyboard/index.ts` ligne 451:

```typescript
await supabase.rpc('app_whiteboard_create_project', { ... });
```

par:

```typescript
await supabase.rpc('whiteboard_create_project', { ... });
```

La RPC `public.whiteboard_create_project` a été créée en MISSION D.14.1 avec exactement la même signature:
- `p_student_id uuid`
- `p_subject text`
- `p_renderer_id text`
- `p_theme_id text`
- `p_narration_mode text`
- `p_storyboard_json jsonb`

Cette modification est dans le code TypeScript de l'Edge Function, pas dans la structure SQL. Elle ne viole donc pas les interdictions de la MISSION D.15.

---

## AUTRES POINTS DE RUPTURE POTENTIELS

L'Edge Function `whiteboard-generate-storyboard` appelle également les RPCs suivantes (non whiteboard, donc non impactées par D.13/D.14):

| Ligne | RPC | Statut | Risque |
|-------|-----|--------|--------|
| 351 | `app_student_reserve_credits` | Hors scope | Potentiel point de rupture secondaire |
| 396 | `app_student_refund_credits` | Hors scope | Potentiel point de rupture secondaire |
| 423 | `app_student_refund_credits` | Hors scope | Potentiel point de rupture secondaire |
| 433 | `app_student_refund_credits` | Hors scope | Potentiel point de rupture secondaire |
| 461 | `app_student_confirm_credits` | Hors scope | Potentiel point de rupture secondaire |
| 494 | `admin_execute_sql` | Hors scope | Potentiel point de rupture secondaire |

Ces RPCs doivent être vérifiées séparément. Le premier point de rupture **certain** dans le flux Smart Whiteboard reste `app_whiteboard_create_project` ligne 451.

---

## RÈGLES RESPECTÉES

✅ Aucune modification de la structure SQL
✅ Aucune création/suppression de RPC
✅ Aucune modification des triggers
✅ Aucun script de nettoyage lancé
✅ Preuves issues de pg_proc
✅ Code source exact cité
✅ Ligne exacte identifiée
✅ Variable fautive identifiée
✅ Valeur réelle observée (0 fonctions dans pg_proc)
✅ Stacktrace prévisible fournie

---

## CONCLUSION

Le premier point de rupture réel du flux Smart Whiteboard est localisé dans `supabase/functions/whiteboard-generate-storyboard/index.ts` ligne 451. L'Edge Function appelle `app_whiteboard_create_project`, une RPC qui n'existe plus dans `pg_proc` depuis la MISSION D.13.

**Action recommandée**: corriger le nom de la RPC dans l'Edge Function: `app_whiteboard_create_project` → `whiteboard_create_project`.

---

## FICHIERS PRODUITS

| Fichier | Description |
|---------|-------------|
| `.windsurf/MISSION_D15_BREAKPOINT_REPORT.md` | Ce rapport |
| `.windsurf/d15_verify_breakpoint.py` | Script de vérification pg_proc |

---

## PROCHAINES ÉTAPES

1. Corriger l'Edge Function `whiteboard-generate-storyboard`
2. Redéployer l'Edge Function (`supabase functions deploy whiteboard-generate-storyboard`)
3. Tester le flux complet depuis l'UI Flutter
4. Identifier le prochain point de rupture si le flux s'arrête à nouveau
