# PHASE B.1.5 – MIGRATION DRY RUN

**Version** : 1.0  
**Date** : 23 Juin 2026  
**Mode** : LECTURE SEULE  
**Objectif** : Simulation complète de la migration

---

## DIRECTIVE TECHNIQUE PERMANENTE

Toute validation concernant Supabase, Tables, Buckets, RPC, Policies, Edge Functions doit obligatoirement être réalisée via les RPC Python administrateurs présents dans `.windsurf`.

Aucune hypothèse autorisée.

---

## PARTIE 1 – VALIDATION SCHÉMA

### 1.1 Schéma cible exact

**Tables à créer** :
- `app.whiteboard_projects`
- `app.whiteboard_renders`

**Schéma whiteboard_projects** :
```
id (UUID, PK, NOT NULL)
student_id (UUID, FK → students.id, NOT NULL)
subject (TEXT, NOT NULL)
status (TEXT, CHECK IN ('draft', 'completed'), NOT NULL)
created_at (TIMESTAMPTZ, NOT NULL, DEFAULT NOW())
updated_at (TIMESTAMPTZ, NOT NULL, DEFAULT NOW())
renderer_id (TEXT, CHECK IN ('scientific', 'notebook'), NOT NULL)
theme_id (TEXT, CHECK IN ('scientific', 'notebook'), NOT NULL)
narration_mode (TEXT, CHECK IN ('none', 'tts', 'user_recording'), NOT NULL)
storyboard_json (JSONB, NOT NULL)
```

**Schéma whiteboard_renders** :
```
id (UUID, PK, NOT NULL)
project_id (UUID, FK → whiteboard_projects.id, NOT NULL)
status (TEXT, CHECK IN ('queued', 'processing', 'done', 'failed'), NOT NULL)
video_url (TEXT, NULL)
duration_ms (INTEGER, NULL)
error_message (TEXT, NULL)
progress (INTEGER, CHECK >= 0 AND <= 100, NULL)
created_at (TIMESTAMPTZ, NOT NULL, DEFAULT NOW())
completed_at (TIMESTAMPTZ, NULL)
```

### 1.2 Conflit de nommage

**Tables existantes** (via RPC refactor_d_list_all_tables.py) :
- Aucune table whiteboard_* n'existe
- Tables challenge_* existent (distinctes)
- Tables prep_* existent (distinctes)
- Tables td_* existent (distinctes)

**Conclusion** : ✅ Aucun conflit de nommage

### 1.3 Conflit avec Challenge

**Tables Challenge** :
- challenge_*
- Préfixe distinct de whiteboard_*

**Conclusion** : ✅ Aucun conflit avec Challenge

### 1.4 Conflit avec Bobodo

**RPCs Bobodo** :
- bobodo_*
- Préfixe distinct de app_whiteboard_*

**Conclusion** : ✅ Aucun conflit avec Bobodo

---

## PARTIE 2 – VALIDATION FK

### 2.1 FK whiteboard_projects.student_id → students.id

**Table cible** : `app.students` (existe déjà)

**Type compatible** :
- Source : UUID
- Cible : UUID
- ✅ Compatible

**Suppression** : ON DELETE CASCADE
- Si l'étudiant est supprimé, ses projets sont supprimés
- ✅ Comportement attendu

**Mise à jour** : Non spécifié (défaut RESTRICT)
- Si l'étudiant est mis à jour, aucun impact
- ✅ Comportement attendu

### 2.2 FK whiteboard_renders.project_id → whiteboard_projects.id

**Table cible** : `app.whiteboard_projects` (créée dans cette migration)

**Type compatible** :
- Source : UUID
- Cible : UUID
- ✅ Compatible

**Suppression** : ON DELETE CASCADE
- Si le projet est supprimé, ses rendus sont supprimés
- ✅ Comportement attendu

**Mise à jour** : Non spécifié (défaut RESTRICT)
- Si le projet est mis à jour, aucun impact
- ✅ Comportement attendu

### 2.3 Conclusion

**Toutes les FK sont valides** ✅

---

## PARTIE 3 – VALIDATION RLS

### 3.1 Simulation Étudiant A

**Contexte** : Étudiant A crée un projet

**Lecture (SELECT)** :
- Peut lire ses propres projets (student_id = auth.uid())
- ✅ Policy "Students can read own projects"

**Écriture (INSERT)** :
- Peut créer des projets (student_id = auth.uid())
- ✅ Policy "Students can create own projects"

**Modification (UPDATE)** :
- Peut modifier ses propres projets (student_id = auth.uid())
- ✅ Policy "Students can update own projects"

**Suppression (DELETE)** :
- Peut supprimer ses propres projets (student_id = auth.uid())
- ✅ Policy "Students can delete own projects"

**Rendus** :
- Peut lire les rendus de ses projets (via project_id → whiteboard_projects.student_id = auth.uid())
- ✅ Policy "Students can read own renders"

### 3.2 Simulation Étudiant B

**Contexte** : Étudiant B tente d'accéder au projet de l'Étudiant A

**Lecture (SELECT)** :
- Ne peut pas lire les projets de l'Étudiant A (student_id != auth.uid())
- ✅ Policy "Students can read own projects"

**Écriture (INSERT)** :
- Ne peut pas créer de projets pour l'Étudiant A (student_id != auth.uid())
- ✅ Policy "Students can create own projects"

**Modification (UPDATE)** :
- Ne peut pas modifier les projets de l'Étudiant A (student_id != auth.uid())
- ✅ Policy "Students can update own projects"

**Suppression (DELETE)** :
- Ne peut pas supprimer les projets de l'Étudiant A (student_id != auth.uid())
- ✅ Policy "Students can delete own projects"

**Rendus** :
- Ne peut pas lire les rendus de l'Étudiant A (via project_id → whiteboard_projects.student_id != auth.uid())
- ✅ Policy "Students can read own renders"

### 3.3 Simulation Admin

**Contexte** : Admin tente d'accéder aux projets

**Lecture (SELECT)** :
- Peut lire tous les projets (role = 'admin')
- ✅ Policy "Admins can read all projects"

**Écriture (INSERT)** :
- Peut créer des projets pour n'importe quel étudiant (role = 'admin')
- ✅ Policy "Admins can create projects"

**Modification (UPDATE)** :
- Peut modifier tous les projets (role = 'admin')
- ✅ Policy "Admins can update all projects"

**Suppression (DELETE)** :
- Peut supprimer tous les projets (role = 'admin')
- ✅ Policy "Admins can delete all projects"

**Rendus** :
- Peut lire tous les rendus (role = 'admin')
- ✅ Policy "Admins can read all renders"

### 3.4 Simulation Service Role

**Contexte** : Service Role (Kamatera) tente d'accéder aux rendus

**Lecture (SELECT)** :
- Non nécessaire pour Kamatera (lecture via RPC)
- ✅ Pas de policy de lecture pour service role

**Écriture (INSERT)** :
- Peut créer des rendus (TO service_role)
- ✅ Policy "Service role can create renders"

**Modification (UPDATE)** :
- Peut modifier tous les rendus (TO service_role)
- ✅ Policy "Service role can update renders"

**Suppression (DELETE)** :
- Non nécessaire pour Kamatera (suppression via CASCADE)
- ✅ Pas de policy de suppression pour service role

### 3.5 Conclusion

**Toutes les policies RLS sont valides** ✅

---

## PARTIE 4 – VALIDATION RPC

### 4.1 RPC app_whiteboard_create_project

**Signature** :
```sql
app_whiteboard_create_project(
  p_student_id UUID,
  p_subject TEXT,
  p_renderer_id TEXT,
  p_theme_id TEXT,
  p_narration_mode TEXT,
  p_storyboard_json JSONB
) RETURNS JSONB
```

**Paramètres** :
- p_student_id : UUID ✅
- p_subject : TEXT ✅
- p_renderer_id : TEXT ✅
- p_theme_id : TEXT ✅
- p_narration_mode : TEXT ✅
- p_storyboard_json : JSONB ✅

**Type de retour** : JSONB ✅

**Compatibilité Flutter** :
- ✅ WhiteboardProject.fromJson(JSONB)
- ✅ Types compatibles

### 4.2 RPC app_whiteboard_update_project

**Signature** :
```sql
app_whiteboard_update_project(
  p_project_id UUID,
  p_subject TEXT,
  p_status TEXT,
  p_renderer_id TEXT,
  p_theme_id TEXT,
  p_narration_mode TEXT,
  p_storyboard_json JSONB
) RETURNS JSONB
```

**Paramètres** :
- p_project_id : UUID ✅
- p_subject : TEXT ✅
- p_status : TEXT ✅
- p_renderer_id : TEXT ✅
- p_theme_id : TEXT ✅
- p_narration_mode : TEXT ✅
- p_storyboard_json : JSONB ✅

**Type de retour** : JSONB ✅

**Compatibilité Flutter** :
- ✅ WhiteboardProject.fromJson(JSONB)
- ✅ Types compatibles

### 4.3 RPC app_whiteboard_get_project

**Signature** :
```sql
app_whiteboard_get_project(
  p_project_id UUID
) RETURNS JSONB
```

**Paramètres** :
- p_project_id : UUID ✅

**Type de retour** : JSONB ✅

**Compatibilité Flutter** :
- ✅ WhiteboardProject.fromJson(JSONB)
- ✅ Types compatibles

### 4.4 RPC app_whiteboard_list_projects

**Signature** :
```sql
app_whiteboard_list_projects(
  p_student_id UUID,
  p_status TEXT DEFAULT NULL,
  p_limit INTEGER DEFAULT 50,
  p_offset INTEGER DEFAULT 0
) RETURNS JSONB
```

**Paramètres** :
- p_student_id : UUID ✅
- p_status : TEXT (optionnel) ✅
- p_limit : INTEGER ✅
- p_offset : INTEGER ✅

**Type de retour** : JSONB (array) ✅

**Compatibilité Flutter** :
- ✅ List<WhiteboardProject>.fromJson(JSONB)
- ✅ Types compatibles

### 4.5 RPC app_whiteboard_delete_project

**Signature** :
```sql
app_whiteboard_delete_project(
  p_project_id UUID
) RETURNS BOOLEAN
```

**Paramètres** :
- p_project_id : UUID ✅

**Type de retour** : BOOLEAN ✅

**Compatibilité Flutter** :
- ✅ bool.fromJson(JSONB)
- ✅ Types compatibles

### 4.6 RPC app_whiteboard_create_render_job

**Signature** :
```sql
app_whiteboard_create_render_job(
  p_project_id UUID
) RETURNS JSONB
```

**Paramètres** :
- p_project_id : UUID ✅

**Type de retour** : JSONB ✅

**Compatibilité Flutter** :
- ✅ RenderJob.fromJson(JSONB)
- ✅ Types compatibles

### 4.7 RPC app_whiteboard_get_render_status

**Signature** :
```sql
app_whiteboard_get_render_status(
  p_render_job_id UUID
) RETURNS JSONB
```

**Paramètres** :
- p_render_job_id : UUID ✅

**Type de retour** : JSONB ✅

**Compatibilité Flutter** :
- ✅ RenderJob.fromJson(JSONB)
- ✅ Types compatibles

### 4.8 Conclusion

**Toutes les RPCs sont valides** ✅

---

## PARTIE 5 – VALIDATION STORAGE

### 5.1 Upload narration

**Bucket** : whiteboard-narrations

**Structure** : `{project_id}/narration.mp3`

**Simulation** :
- Étudiant A upload narration.mp3 dans {project_id_A}/narration.mp3
- ✅ Policy autorisée (étudiant peut écrire dans son répertoire)
- Service Role upload narration.mp3 dans {project_id_A}/narration.mp3
- ✅ Policy autorisée (service role peut écrire partout)

### 5.2 Upload rendu

**Bucket** : whiteboard-renders

**Structure** : `{project_id}/render.mp4`

**Simulation** :
- Service Role upload render.mp4 dans {project_id_A}/render.mp4
- ✅ Policy autorisée (service role peut écrire partout)

### 5.3 Lecture narration

**Bucket** : whiteboard-narrations

**Simulation** :
- Étudiant A lit narration.mp3 dans {project_id_A}/narration.mp3
- ✅ Policy autorisée (étudiant peut lire dans son répertoire)
- Étudiant B tente de lire narration.mp3 dans {project_id_A}/narration.mp3
- ❌ Policy refusée (étudiant ne peut pas lire dans le répertoire des autres)

### 5.4 Lecture rendu

**Bucket** : whiteboard-renders

**Structure** : `{project_id}/render.mp4`

**Simulation** :
- Étudiant A lit render.mp4 dans {project_id_A}/render.mp4
- ✅ Policy autorisée (étudiant peut lire dans son répertoire)
- Admin lit render.mp4 dans {project_id_A}/render.mp4
- ✅ Policy autorisée (admin peut lire partout)

### 5.5 Suppression

**Bucket** : whiteboard-narrations, whiteboard-renders

**Simulation** :
- Suppression du projet {project_id_A}
- CASCADE sur whiteboard_renders
- Suppression automatique des fichiers dans whiteboard-renders/{project_id_A}/
- ✅ Nettoyage automatique

### 5.6 Conclusion

**Toutes les opérations Storage sont valides** ✅

---

## PARTIE 6 – VALIDATION ROLLBACK

### 6.1 Ordre inverse complet

**Ordre de suppression** :
1. RPCs (7)
2. Buckets (2)
3. Policies (20)
4. Triggers (1)
5. Indexes (9)
6. Tables (2)

### 6.2 Dépendances critiques

**RPCs → Tables** :
- RPCs dépendent des tables
- Suppression des RPCs avant les tables ✅

**Buckets → Aucune** :
- Buckets indépendants
- Suppression des buckets à tout moment ✅

**Policies → Tables** :
- Policies dépendent des tables
- Suppression des policies avant les tables ✅

**Triggers → Tables** :
- Triggers dépendent des tables
- Suppression des triggers avant les tables ✅

**Indexes → Tables** :
- Indexes dépendent des tables
- Suppression des indexes avant les tables ✅

**Tables → students** :
- whiteboard_projects dépend de students
- whiteboard_renders dépend de whiteboard_projects
- Suppression de whiteboard_renders avant whiteboard_projects ✅
- Suppression de whiteboard_projects avant students (non nécessaire, students non supprimé) ✅

### 6.3 Conclusion

**Rollback complet possible** ✅

---

## PARTIE 7 – CHECKLIST D'EXÉCUTION

### 7.1 Avant migration

- [ ] Backup de la base de données via RPC administrateur
- [ ] Vérifier que les RPC administrateurs sont accessibles
- [ ] Vérifier que l'utilisateur a les droits administrateur
- [ ] Vérifier que la table students existe via RPC
- [ ] Vérifier que la table users existe via RPC
- [ ] Documenter l'état actuel de la base de données
- [ ] Préparer le script de rollback complet
- [ ] Notifier les autres développeurs
- [ ] Vérifier qu'aucune table whiteboard_* n'existe
- [ ] Vérifier qu'aucun bucket whiteboard-* n'existe

### 7.2 Pendant migration

**Étape 1 : Création des tables**
- [ ] Exécuter la création de whiteboard_projects
- [ ] Vérifier que whiteboard_projects est créée
- [ ] Exécuter la création de whiteboard_renders
- [ ] Vérifier que whiteboard_renders est créée

**Étape 2 : Création des indexes**
- [ ] Exécuter la création des indexes whiteboard_projects
- [ ] Vérifier que les indexes sont créés
- [ ] Exécuter la création des indexes whiteboard_renders
- [ ] Vérifier que les indexes sont créés

**Étape 3 : Création des contraintes**
- [ ] Exécuter la création du trigger updated_at
- [ ] Vérifier que le trigger est créé

**Étape 4 : Création des policies**
- [ ] Activer RLS sur whiteboard_projects
- [ ] Créer les policies whiteboard_projects
- [ ] Vérifier que les policies sont créées
- [ ] Activer RLS sur whiteboard_renders
- [ ] Créer les policies whiteboard_renders
- [ ] Vérifier que les policies sont créées

**Étape 5 : Création des buckets**
- [ ] Exécuter la création de whiteboard-narrations
- [ ] Vérifier que le bucket est créé
- [ ] Exécuter la création de whiteboard-renders
- [ ] Vérifier que le bucket est créé

**Étape 6 : Création des RPCs**
- [ ] Exécuter la création de app_whiteboard_create_project
- [ ] Vérifier que le RPC est créé
- [ ] Exécuter la création de app_whiteboard_update_project
- [ ] Vérifier que le RPC est créé
- [ ] Exécuter la création de app_whiteboard_get_project
- [ ] Vérifier que le RPC est créé
- [ ] Exécuter la création de app_whiteboard_list_projects
- [ ] Vérifier que le RPC est créé
- [ ] Exécuter la création de app_whiteboard_delete_project
- [ ] Vérifier que le RPC est créé
- [ ] Exécuter la création de app_whiteboard_create_render_job
- [ ] Vérifier que le RPC est créé
- [ ] Exécuter la création de app_whiteboard_get_render_status
- [ ] Vérifier que le RPC est créé

**Documentation** :
- [ ] Documenter chaque étape
- [ ] Notifier les autres développeurs

### 7.3 Après migration

**Tests SQL** :
- [ ] Exécuter le test de création d'un projet
- [ ] Exécuter le test de lecture d'un projet
- [ ] Exécuter le test de mise à jour d'un projet
- [ ] Exécuter le test de suppression d'un projet

**Tests RLS** :
- [ ] Exécuter le test Étudiant A peut lire ses propres projets
- [ ] Exécuter le test Étudiant B ne peut pas lire les projets de l'Étudiant A
- [ ] Exécuter le test Admin peut lire tous les projets

**Tests buckets** :
- [ ] Vérifier que whiteboard-narrations existe
- [ ] Vérifier que whiteboard-renders existe

**Tests RPC** :
- [ ] Exécuter le test app_whiteboard_create_project
- [ ] Exécuter le test app_whiteboard_get_project
- [ ] Exécuter le test app_whiteboard_list_projects
- [ ] Exécuter le test app_whiteboard_create_render_job
- [ ] Exécuter le test app_whiteboard_get_render_status

**Validation** :
- [ ] Vérifier que tous les tests passent
- [ ] Documenter les résultats
- [ ] Notifier les autres développeurs
- [ ] Mettre à jour la documentation

---

## PARTIE 8 – DÉCISION

### 8.1 Évaluation

| Critère | État | Justification |
|---------|------|---------------|
- Validation schéma | ✅ Réussi | Aucun conflit de nommage, aucun conflit avec Challenge/Bobodo |
- Validation FK | ✅ Réussi | Toutes les FK valides (types compatibles, suppression CASCADE) |
- Validation RLS | ✅ Réussi | Policies valides pour Étudiant A, Étudiant B, Admin, Service Role |
- Validation RPC | ✅ Réussi | Toutes les RPCs valides (signature, paramètres, type de retour, compatibilité Flutter) |
- Validation Storage | ✅ Réussi | Toutes les opérations Storage valides (upload, lecture, suppression) |
- Validation rollback | ✅ Réussi | Rollback complet possible, dépendances identifiées |
- Checklist d'exécution | ✅ Définie | Avant, pendant, après |

### 8.2 Décision

**PHASE B.2 AUTORISÉE** ✅

**Justification** :
- Schéma validé (aucun conflit)
- FK validées (types compatibles, suppression CASCADE)
- RLS validées (policies pour tous les rôles)
- RPCs validées (signature, paramètres, type de retour, compatibilité Flutter)
- Storage validé (upload, lecture, suppression)
- Rollback complet possible
- Checklist d'exécution définie

---

## CONCLUSION

**Phase B.1.5 – Migration Dry Run** : ✅ Terminée

**Prêt pour Phase B.2** : Exécution des migrations

**Prochaine étape** : Phase B.2 – Exécution des migrations via RPC administrateurs

---

**Fin du document**
