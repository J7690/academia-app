# SMART WHITEBOARD RENDERER V1 – FEASIBILITY

**Version** : 1.0  
**Date** : 23 Juin 2026  
**Mode** : LECTURE SEULE  
**Objectif** : Valider le renderer V1 minimal

---

## SCÉNARIO ÉTUDIÉ

**Sujet** : Photosynthèse

**Storyboard** :
- Titre
- Définition
- Exemple
- Résumé

**Animation** :
- Fade In
- Apparition progressive
- Transition simple

**Narration** :
- TTS ou audio utilisateur

**Sortie** :
- MP4

---

## QUESTION PRINCIPALE

Quel est le plus petit renderer cloud réalisable rapidement avec Flutter + Supabase + Kamatera + FFmpeg déjà disponibles ?

---

## RÉPONSE

**Renderer V1 minimal** : FFmpeg Direct avec Pillow

**Architecture** :
```
Storyboard JSON
  ↓
Python (Pillow) → Génère images PNG
  ↓
FFmpeg → Assemble images + audio → MP4
  ↓
Pipeline Challenge existant
```

---

## DÉTAIL DES OPTIONS

### Option 1 : FFmpeg Direct avec Pillow ✅ RECOMMANDÉ

**Description** :
- Python (Pillow) génère des images PNG depuis le Storyboard JSON
- FFmpeg assemble les images + audio en MP4

**Avantages** :
- ✅ FFmpeg déjà installé sur Kamatera
- ✅ Pillow est une bibliothèque Python légère
- ✅ Pas besoin de headless browser
- ✅ Pas besoin de complexité Canvas
- ✅ Peut être déployé sur Kamatera

**Inconvénients** :
- ⚠️ Besoin de générer des images depuis texte (mais Pillow le fait nativement)
- ⚠️ Formules LaTeX nécessitent matplotlib (mais c'est standard)

**Complexité** : Faible

**Temps de développement** : 1-2 semaines

---

### Option 2 : HTML → Capture → MP4

**Description** :
- Générer du HTML depuis le Storyboard JSON
- Headless browser (Puppeteer/Playwright) capture des screenshots
- FFmpeg assemble les screenshots en MP4

**Avantages** :
- ✅ HTML est facile à générer
- ✅ CSS permet un styling puissant

**Inconvénients** :
- ❌ Besoin d'un headless browser sur Kamatera (non installé)
- ❌ Puppeteer/Playwright nécessite Node.js (non installé)
- ❌ Complexité de déploiement élevée

**Complexité** : Élevée

**Temps de développement** : 3-4 semaines

---

### Option 3 : Canvas → MP4

**Description** :
- Flutter génère des Canvas depuis le Storyboard JSON
- Flutter capture les Canvas en images
- FFmpeg assemble les images en MP4

**Avantages** :
- ✅ Canvas est natif dans Flutter

**Inconvénients** :
- ❌ Rendu sur Flutter (pas sur Kamatera)
- ❌ Utilise screen recording Flutter (refusé par l'utilisateur)
- ❌ Charge sur le téléphone (pas sur le cloud)

**Complexité** : Moyenne

**Temps de développement** : 2-3 semaines

---

### Option 4 : Flutter Screen Recording

**Description** :
- Flutter fait le rendu en temps réel
- flutter_screen_recording capture l'écran

**Avantages** :
- ✅ Pas besoin de backend

**Inconvénients** :
- ❌ Utilise screen recording Flutter (refusé par l'utilisateur)
- ❌ Charge sur le téléphone
- ❌ Pas de rendu cloud

**Complexité** : Faible

**Temps de développement** : 1 semaine

**Statut** : ❌ REFUSÉ par l'utilisateur

---

## RÉPONSES AUX 5 QUESTIONS

### Question 1

Avec FFmpeg déjà installé, peut-on générer écran 1, 2, 3, 4 puis assembler le tout en vidéo ?

**Réponse** : ✅ OUI

**Justification** :
- FFmpeg supporte la concaténation d'images via le filtre `concat`
- FFmpeg supporte l'assemblage d'images en vidéo via le filtre `fps`
- FFmpeg supporte le mixage audio via le filtre `amix`

**Commande FFmpeg** :
```bash
ffmpeg -framerate 30 -i frame_%d.png -i audio.mp3 -c:v libx264 -c:a aac -shortest output.mp4
```

---

### Question 2

Peut-on générer les scènes sous forme PNG, SVG, Canvas, HTML ou autre ?

**Réponse** : ✅ OUI (PNG recommandé)

**Justification** :
- Pillow (Python) peut générer des images PNG depuis texte
- Pillow est léger et standard
- PNG est supporté nativement par FFmpeg
- PNG offre une bonne qualité pour le texte

**Alternatives** :
- SVG : Possible mais nécessite une conversion intermédiaire
- Canvas : Possible mais nécessite Flutter (refusé)
- HTML : Possible mais nécessite headless browser (complexe)

**Recommandation** : PNG

---

### Question 3

Quel est le renderer V1 le plus simple à construire ?

**Réponse** : FFmpeg Direct avec Pillow

**Justification** :
- FFmpeg déjà installé sur Kamatera
- Pillow est une bibliothèque Python légère
- Pas besoin de headless browser
- Pas besoin de complexité Canvas
- Peut être déployé sur Kamatera en 1-2 semaines

**Architecture** :
```
Storyboard JSON
  ↓
Python (Pillow) → Génère images PNG
  ↓
FFmpeg → Assemble images + audio → MP4
  ↓
Pipeline Challenge existant
```

---

### Question 4

Quel est le temps estimé pour ce Renderer V1 uniquement ?

**Réponse** : 1-2 semaines

**Détail** :
- Configuration backend sur Kamatera : 2-3 jours
- Implémentation génération images (Pillow) : 3-4 jours
- Implémentation assemblage FFmpeg : 2-3 jours
- Tests et optimisation : 2-3 jours

**Total** : 1-2 semaines

---

### Question 5

Quelle est la charge Kamatera estimée ?

**Réponse** : Faible

**Détail** :

| Ressource | Estimation | Justification |
|-----------|------------|---------------|
| **CPU** | 10-20% par rendu | Génération images légère, FFmpeg optimisé |
| **RAM** | 1-2 Go par rendu | Pillow + FFmpeg sont légers |
| **Stockage** | 50-100 Mo temporaire | Images PNG + audio + MP4 final |
| **Temps de rendu** | 10-30 secondes | 4 scènes simples, 30 fps, 5 secondes par scène |

**Capacité** :
- Avec 4 vCPU : ~2-4 rendus simultanés
- Avec 9.7 Go RAM : ~4-8 rendus simultanés
- Avec 12 Go disque disponible : ~100-200 rendus avant nettoyage

---

## ARCHITECTURE DÉTAILLÉE DU RENDERER V1

### 1. Flux de rendu

```
1. Flutter → RPC app_whiteboard_create_render_job
   ↓
2. Supabase → whiteboard_renders (status=queued)
   ↓
3. Worker Kamatera (poll whiteboard_renders)
   ↓
4. Worker télécharge Storyboard JSON depuis Supabase
   ↓
5. Worker télécharge narration audio depuis Supabase Storage
   ↓
6. Python (Pillow) génère images PNG depuis chaque bloc
   ↓
7. Python (Pillow) applique animations (fade_in)
   ↓
8. FFmpeg assemble images + audio → MP4
   ↓
9. Worker upload MP4 vers Supabase Storage
   ↓
10. Worker met à jour whiteboard_renders (status=done, video_url)
   ↓
11. Flutter récupère video_url via RPC app_whiteboard_get_render_status
```

### 2. Génération d'images avec Pillow

**Exemple de code Python** :
```python
from PIL import Image, ImageDraw, ImageFont

def generate_text_image(text, font_size=24, width=1080, height=1920):
    image = Image.new('RGB', (width, height), color='white')
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype('Roboto.ttf', font_size)
    
    # Calculer la position centrée
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    x = (width - text_width) / 2
    y = (height - text_height) / 2
    
    draw.text((x, y), text, font=font, fill='black')
    return image
```

### 3. Assemblage FFmpeg

**Commande FFmpeg** :
```bash
ffmpeg -framerate 30 -i frame_%d.png -i audio.mp3 -c:v libx264 -c:a aac -shortest output.mp4
```

**Explication** :
- `-framerate 30` : 30 images par seconde
- `-i frame_%d.png` : Images numérotées (frame_0.png, frame_1.png, ...)
- `-i audio.mp3` : Fichier audio
- `-c:v libx264` : Codec vidéo H.264
- `-c:a aac` : Codec audio AAC
- `-shortest` : Durée = la plus courte entre vidéo et audio

### 4. Animation Fade In

**Approche simple** :
- Générer 2 versions de chaque image : transparente et opaque
- Utiliser FFmpeg pour faire le fondu entre les deux

**Commande FFmpeg** :
```bash
ffmpeg -i frame_0.png -i frame_1.png -filter_complex "fade=in:0:30" output.png
```

---

## EXEMPLE COMPLET

### Storyboard JSON

```json
{
  "version": "1.0",
  "subject": "Photosynthèse",
  "scenes": [
    {
      "id": "scene_001",
      "order": 0,
      "title": "Titre",
      "duration_ms": 5000,
      "blocks": [
        {
          "type": "title",
          "content": "Photosynthèse",
          "style": {
            "font_size": 48,
            "color": "#000000"
          }
        }
      ]
    },
    {
      "id": "scene_002",
      "order": 1,
      "title": "Définition",
      "duration_ms": 5000,
      "blocks": [
        {
          "type": "paragraph",
          "content": "Processus par lequel les plantes convertissent la lumière en énergie chimique.",
          "style": {
            "font_size": 24,
            "color": "#000000"
          }
        }
      ]
    }
  ],
  "narration": {
    "mode": "tts",
    "audio_url": "https://supabase.storage/whiteboard-narrations/audio.mp3"
  }
}
```

### Rendu Python

```python
import json
from PIL import Image, ImageDraw, ImageFont
import subprocess

def render_storyboard(storyboard_json, output_mp4):
    storyboard = json.loads(storyboard_json)
    
    # Générer les images pour chaque scène
    for scene in storyboard['scenes']:
        for block in scene['blocks']:
            image = generate_text_image(
                block['content'],
                font_size=block['style']['font_size']
            )
            image.save(f"frame_{scene['order']}.png")
    
    # Assembler avec FFmpeg
    cmd = [
        "ffmpeg",
        "-framerate", "30",
        "-i", "frame_%d.png",
        "-i", storyboard['narration']['audio_url'],
        "-c:v", "libx264",
        "-c:a", "aac",
        "-shortest",
        output_mp4
    ]
    subprocess.run(cmd)
```

---

## CONCLUSION

### Renderer V1 minimal recommandé

**Architecture** : FFmpeg Direct avec Pillow

**Temps de développement** : 1-2 semaines

**Charge Kamatera** : Faible (10-20% CPU, 1-2 Go RAM)

**Faisabilité** : ✅ OUI

### Avantages

- ✅ Utilise FFmpeg déjà installé
- ✅ Utilise Pillow (bibliothèque Python légère)
- ✅ Pas besoin de headless browser
- ✅ Pas besoin de complexité Canvas
- ✅ Peut être déployé sur Kamatera
- ✅ Respecte la contrainte cloud (pas de screen recording Flutter)

### Limites

- ⚠️ Animations simples uniquement (fade_in)
- ⚠️ Pas d'écriture manuscrite
- ⚠️ Pas de synchronisation mot par mot
- ⚠️ Pas de zoom intelligent

### Évolution future

**V2** : Ajouter des animations plus complexes (slide_up, typewriter)

**V3** : Ajouter l'écriture manuscrite (polices manuscrites)

**V4** : Ajouter le zoom intelligent

**V5** : Ajouter la synchronisation mot par mot

---

**Fin du document**
