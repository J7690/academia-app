# PHASE D.6E – REAL PERFORMANCE AUDIT

**Date** : 24 Juin 2026  
**Phase** : D.6E – Product Integration and Real User Validation  
**Composant** : Smart Whiteboard Real Performance Audit

---

## OBJECTIF

Auditer la performance réelle du Smart Whiteboard en mesurant les percentiles P50, P90 et P95 pour :
- Le temps de génération du storyboard
- Le temps de rendu vidéo
- Le temps de réponse de l'interface Flutter
- La consommation de crédits
- Le taux d'erreur

---

## 1. MÉTHODOLOGIE D'AUDIT

### 1.1 Échantillon de test

Générer 100 projets Smart Whiteboard avec des paramètres variés :
- 25 projets Mode A (Sujet simple)
- 25 projets Mode B (Texte complet)
- 25 projets Mode C (Plan)
- 25 projets Mode D (Cours existant)

### 1.2 Métriques mesurées

Pour chaque projet, mesurer :

#### 1.2.1 Temps de génération du storyboard
- Début : Appel RPC `whiteboard_generate_storyboard`
- Fin : Réponse de l'Edge Function
- Métrique : `generation_time_ms`

#### 1.2.2 Temps de rendu vidéo
- Début : Appel RPC `whiteboard_create_render_job`
- Fin : Statut "done" dans `app.whiteboard_renders`
- Métrique : `render_time_ms`

#### 1.2.3 Temps de réponse Flutter
- Début : Clic sur "Générer le Storyboard"
- Fin : Affichage de l'écran d'édition
- Métrique : `flutter_response_time_ms`

#### 1.2.4 Consommation de crédits
- Crédits déduits pour la génération
- Crédits déduits pour le rendu
- Métrique : `credits_consumed`

#### 1.2.5 Taux d'erreur
- Erreurs de génération
- Erreurs de rendu
- Métrique : `error_rate` (nombre d'erreurs / nombre total)

### 1.3 Percentiles

Calculer les percentiles pour chaque métrique :
- **P50** : Médiane (50% des valeurs sont en dessous)
- **P90** : 90% des valeurs sont en dessous
- **P95** : 95% des valeurs sont en dessous

---

## 2. PROCÉDURE D'AUDIT

### 2.1 Génération des 100 projets

Utiliser le script Python `.windsurf/test_whiteboard_modes.py` modifié pour générer 100 projets avec des paramètres variés :

```python
subjects = [
    ("Dérivée d'une fonction", "simple", "scientific", "scientific", "none"),
    ("Théorème de Pythagore", "full_text", "notebook", "notebook", "tts"),
    ("Les équations différentielles", "plan", "scientific", "scientific", "recording"),
    ("La photosynthèse", "existing_course", "notebook", "notebook", "none"),
    # ... ajouter 96 autres sujets variés
]
```

### 2.2 Mesure des temps

Pour chaque projet :
1. Enregistrer l'heure de début de génération
2. Appeler l'Edge Function
3. Enregistrer l'heure de fin de génération
4. Calculer `generation_time_ms`
5. Enregistrer l'heure de début de rendu
6. Créer le job de rendu
7. Poller le statut jusqu'à "done" ou "failed"
8. Enregistrer l'heure de fin de rendu
9. Calculer `render_time_ms`

### 2.3 Collecte des données

Stocker les résultats dans un fichier JSON :

```json
{
  "results": [
    {
      "project_id": "uuid",
      "mode": "simple",
      "subject": "Dérivée d'une fonction",
      "generation_time_ms": 3500,
      "render_time_ms": 120000,
      "flutter_response_time_ms": 4200,
      "credits_consumed": 15,
      "error": null
    },
    // ... 99 autres résultats
  ]
}
```

### 2.4 Calcul des percentiles

Utiliser Python pour calculer les percentiles :

```python
import numpy as np

generation_times = [r["generation_time_ms"] for r in results]
render_times = [r["render_time_ms"] for r in results]

p50_generation = np.percentile(generation_times, 50)
p90_generation = np.percentile(generation_times, 90)
p95_generation = np.percentile(generation_times, 95)

p50_render = np.percentile(render_times, 50)
p90_render = np.percentile(render_times, 90)
p95_render = np.percentile(render_times, 95)
```

---

## 3. RÉSULTATS ATTENDUS

### 3.1 Tableau de synthèse

| Métrique | P50 | P90 | P95 | Cible P50 | Cible P90 | Cible P95 |
|----------|-----|-----|-----|-----------|-----------|-----------|
| Temps de génération (ms) | ? | ? | ? | < 5000 | < 10000 | < 15000 |
| Temps de rendu (ms) | ? | ? | ? | < 120000 | < 180000 | < 240000 |
| Temps de réponse Flutter (ms) | ? | ? | ? | < 3000 | < 5000 | < 7000 |
| Crédits consommés | ? | ? | ? | = 15 | = 15 | = 15 |
| Taux d'erreur (%) | ? | ? | ? | < 5% | < 10% | < 15% |

### 3.2 Analyse par mode

| Mode | P50 Génération | P90 Génération | P95 Génération | P50 Rendu | P90 Rendu | P95 Rendu |
|------|----------------|----------------|----------------|-----------|-----------|-----------|
| A | ? | ? | ? | ? | ? | ? |
| B | ? | ? | ? | ? | ? | ? |
| C | ? | ? | ? | ? | ? | ? |
| D | ? | ? | ? | ? | ? | ? |

### 3.3 Distribution des temps

Générer des histogrammes pour visualiser la distribution :
- Histogramme des temps de génération
- Histogramme des temps de rendu
- Histogramme des temps de réponse Flutter

---

## 4. CRITÈRES DE VALIDATION

### 4.1 Seuils de performance

#### Temps de génération
- **P50 < 5 secondes** : Bon
- **P90 < 10 secondes** : Acceptable
- **P95 < 15 secondes** : Maximum acceptable

#### Temps de rendu
- **P50 < 2 minutes** : Bon
- **P90 < 3 minutes** : Acceptable
- **P95 < 4 minutes** : Maximum acceptable

#### Temps de réponse Flutter
- **P50 < 3 secondes** : Bon
- **P90 < 5 secondes** : Acceptable
- **P95 < 7 secondes** : Maximum acceptable

#### Taux d'erreur
- **P50 < 5%** : Bon
- **P90 < 10%** : Acceptable
- **P95 < 15%** : Maximum acceptable

### 4.2 Décision GO/NO-GO

- **GO** : Si tous les seuils P90 sont satisfaits
- **NO-GO** : Si un ou plusieurs seuils P90 ne sont pas satisfaits

---

## 5. ACTIONS CORRECTIVES

### 5.1 Si P50 génération > 5 secondes

- Optimiser l'Edge Function whiteboard-generate-storyboard
- Réduire la taille du prompt
- Utiliser un modèle plus rapide
- Mettre en cache les réponses courantes

### 5.2 Si P90 génération > 10 secondes

- Identifier les cas lents (taille de contenu, complexité)
- Implémenter un timeout et une retry strategy
- Ajouter une file d'attente pour les requêtes
- Surveiller la charge de l'Edge Function

### 5.3 Si P50 rendu > 2 minutes

- Optimiser le worker Kamatera (CPU/GPU)
- Paralléliser les tâches de rendu
- Réduire la complexité des animations
- Utiliser un renderer plus performant

### 5.4 Si P90 rendu > 3 minutes

- Identifier les rendus lents (durée vidéo, complexité)
- Implémenter une priorité de rendu
- Ajouter des workers supplémentaires
- Optimiser le pipeline de rendu

### 5.5 Si P50 Flutter > 3 secondes

- Optimiser le code Flutter
- Réduire les calculs sur le thread principal
- Implémenter le chargement différé
- Optimiser la navigation

### 5.6 Si taux d'erreur > 10%

- Identifier les erreurs fréquentes
- Implémenter une meilleure gestion d'erreur
- Ajouter des logs détaillés
- Améliorer la résilience du système

---

## 6. SCRIPT D'AUDIT AUTOMATISÉ

### 6.1 Script Python

Créer un script Python pour automatiser l'audit de performance :

```python
#!/usr/bin/env python3
"""
Script d'audit de performance pour Smart Whiteboard
"""

import asyncio
import json
import time
import numpy as np
import httpx
from typing import Dict, Any, List
from datetime import datetime

class PerformanceAuditor:
    def __init__(self):
        self.client = httpx.Client(
            base_url="https://thevdfcwlcqzdoybfvgs.supabase.co",
            headers={
                "apikey": "YOUR_SERVICE_ROLE_KEY",
                "Authorization": "Bearer YOUR_SERVICE_ROLE_KEY",
                "Content-Type": "application/json",
            }
        )
        self.results = []

    def call_rpc(self, rpc_name: str, params: Dict[str, Any]) -> Optional[Dict]:
        """Appelle une RPC Supabase et mesure le temps"""
        start = time.time()
        try:
            response = self.client.post(
                f"/rest/v1/rpc/{rpc_name}",
                json=params
            )
            response.raise_for_status()
            elapsed = (time.time() - start) * 1000  # ms
            return {"data": response.json(), "time_ms": elapsed}
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return {"error": str(e), "time_ms": elapsed}

    def generate_project(self, subject: str, mode: str, theme: str, renderer: str, narration: str) -> Dict[str, Any]:
        """Génère un projet et mesure les temps"""
        result = {
            "subject": subject,
            "mode": mode,
            "timestamp": datetime.now().isoformat(),
        }

        # Créer le projet
        create_params = {
            "p_user_id": "test_user",
            "p_subject": subject,
            "p_content": None if mode == "simple" else "Contenu de test...",
            "p_mode": mode,
            "p_theme_id": theme,
            "p_renderer_id": renderer,
            "p_narration_mode": narration,
        }

        create_result = self.call_rpc("app_whiteboard_create_project", create_params)
        if "error" in create_result:
            result["error"] = create_result["error"]
            return result

        project_id = create_result["data"].get("id")
        result["project_id"] = project_id

        # Générer le storyboard
        gen_params = {"p_project_id": project_id}
        gen_result = self.call_rpc("whiteboard_generate_storyboard", gen_params)
        if "error" in gen_result:
            result["error"] = gen_result["error"]
            return result

        result["generation_time_ms"] = gen_result["time_ms"]

        # Créer le job de rendu
        render_params = {"p_project_id": project_id}
        render_result = self.call_rpc("whiteboard_create_render_job", render_params)
        if "error" in render_result:
            result["error"] = render_result["error"]
            return result

        render_id = render_result["data"].get("id")
        result["render_id"] = render_id

        # Attendre le rendu
        render_start = time.time()
        for i in range(300):  # 5 minutes max
            time.sleep(1)
            status = self.call_rpc("whiteboard_get_render_status", {"p_render_id": render_id})
            if status and "data" in status:
                status_value = status["data"].get("status")
                if status_value == "done":
                    result["render_time_ms"] = (time.time() - render_start) * 1000
                    break
                elif status_value == "failed":
                    result["error"] = status["data"].get("error_message")
                    break
        else:
            result["error"] = "Timeout"

        return result

    def run_audit(self, n_projects: int = 100):
        """Exécute l'audit sur n projets"""
        subjects = [
            ("Dérivée d'une fonction", "simple", "scientific", "scientific", "none"),
            ("Théorème de Pythagore", "full_text", "notebook", "notebook", "tts"),
            ("Les équations différentielles", "plan", "scientific", "scientific", "recording"),
            ("La photosynthèse", "existing_course", "notebook", "notebook", "none"),
            # ... ajouter d'autres sujets
        ]

        for i in range(n_projects):
            subject, mode, theme, renderer, narration = subjects[i % len(subjects)]
            result = self.generate_project(subject, mode, theme, renderer, narration)
            self.results.append(result)
            print(f"Progress: {i+1}/{n_projects}")

    def calculate_percentiles(self):
        """Calcule les percentiles pour chaque métrique"""
        generation_times = [r.get("generation_time_ms") for r in self.results if r.get("generation_time_ms")]
        render_times = [r.get("render_time_ms") for r in self.results if r.get("render_time_ms")]

        return {
            "generation": {
                "p50": np.percentile(generation_times, 50) if generation_times else None,
                "p90": np.percentile(generation_times, 90) if generation_times else None,
                "p95": np.percentile(generation_times, 95) if generation_times else None,
            },
            "render": {
                "p50": np.percentile(render_times, 50) if render_times else None,
                "p90": np.percentile(render_times, 90) if render_times else None,
                "p95": np.percentile(render_times, 95) if render_times else None,
            },
        }

    def save_results(self, filename: str):
        """Sauvegarde les résultats dans un fichier JSON"""
        with open(filename, "w") as f:
            json.dump({
                "results": self.results,
                "percentiles": self.calculate_percentiles(),
            }, f, indent=2)

if __name__ == "__main__":
    auditor = PerformanceAuditor()
    auditor.run_audit(n_projects=100)
    auditor.save_results(".windsurf/performance_audit_results.json")
```

---

## 7. RAPPORT D'AUDIT

### 7.1 Structure du rapport

1. **Résumé exécutif**
   - Objectif de l'audit
   - Méthodologie
   - Résultats clés (P50, P90, P95)
   - Recommandations

2. **Détail des métriques**
   - Tableau des percentiles
   - Comparaison avec les cibles
   - Analyse par mode

3. **Distribution des temps**
   - Histogrammes
   - Analyse des outliers
   - Identification des goulots d'étranglement

4. **Taux d'erreur**
   - Types d'erreurs
   - Fréquence d'apparition
   - Analyse des causes

5. **Analyse par mode**
   - Performance de chaque mode
   - Modes les plus performants
   - Modes à améliorer

6. **Recommandations**
   - Actions prioritaires
   - Actions secondaires
   - Améliorations futures

7. **Conclusion**
   - Décision GO/NO-GO
   - Conditions de validation
   - Prochaines étapes

### 7.2 Livrables

- `docs/PHASE_D6E_PERFORMANCE_AUDIT_REPORT.md` : Rapport complet
- `.windsurf/performance_audit_results.json` : Résultats bruts
- `.windsurf/performance_histograms/` : Histogrammes visuels

---

## 8. INSTRUCTIONS D'EXÉCUTION

### 8.1 Prérequis

- Accès à Supabase (clé service_role)
- Worker Kamatera actif
- Python 3 installé
- Script d'audit de performance disponible
- Au moins 1500 crédits (100 tests × 15 crédits)

### 8.2 Exécution

1. Configurer le script avec la clé service_role
2. Exécuter le script pour générer 100 projets
3. Attendre la fin de tous les rendus
4. Analyser les résultats
5. Calculer les percentiles
6. Rédiger le rapport d'audit

### 8.3 Durée estimée

- Génération des 100 projets : 30-60 minutes
- Rendu des 100 vidéos : 3-5 heures
- Analyse des résultats : 1-2 heures
- Compilation et rapport : 1-2 heures
- **Total** : 5.5-9.5 heures

---

## 9. CONCLUSION

L'audit de performance permettra de mesurer la performance réelle du Smart Whiteboard en conditions d'utilisation. Les résultats seront utilisés pour :

- Valider les temps de réponse
- Identifier les goulots d'étranglement
- Optimiser le pipeline de génération et de rendu
- Mesurer la fiabilité du système
- Décider du GO/NO-GO pour la bêta utilisateurs

---

**Fin de PHASE_D6E_PERFORMANCE_AUDIT.md**
