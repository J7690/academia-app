# PHASE D.3A.2 – IMPLEMENTATION ROADMAP

**Date** : 23 Juin 2026  
**Phase** : D.3A.2 – IA Generation Architecture Refactor  
**Mode** : ROADMAP

---

## OBJECTIF

Produire la séquence d'implémentation pour le Smart Whiteboard Content Agent.

---

## DIRECTIVE

Le plan d'implémentation suit la séquence : D.3A.3 → D.3A.4 → D.3A.5 → D.3B → D.4 → D.5 → D.6

---

## PARTIE 1 – SÉQUENCE D'IMPLÉMENTATION

### D.3A.3 – Création du Content Generation Agent

**Objectif** : Créer l'Edge Function `whiteboard-generate-storyboard`

**Tâches** :
1. Créer `supabase/functions/whiteboard-generate-storyboard/index.ts`
2. Implémenter cascade multi-modèles (réutilisé depuis prep-generate-questions)
3. Implémenter prompts système par mode (A, B, C, D)
4. Implémenter validation JSON stricte
5. Implémenter gestion crédits (réserve→confirme→rembourse)
6. Implémenter stockage Supabase via RPC `app_whiteboard_create_project`
7. Implémenter logging dans `whiteboard_ai_generations`

**Livrables** :
- Edge Function `whiteboard-generate-storyboard`
- Tests unitaires Edge Function
- Documentation déployement

**Validation** :
- Déploiement Supabase CLI
- Test HTTP 200 avec Storyboard JSON valide
- Test HTTP 402 avec crédits insuffisants
- Test HTTP 500 avec JSON invalide

**Durée estimée** : 2-3 jours

---

### D.3A.4 – Connexion OpenRouter

**Objectif** : Connecter Flutter à l'Edge Function

**Tâches** :
1. Créer `SmartWhiteboardContentService` dans Flutter
2. Implémenter méthode `generateStoryboard()`
3. Gérer HTTP 402 (crédits insuffisants)
4. Gérer HTTP 500 (erreur génération)
5. Gérer timeout (7 secondes max)
6. Afficher loading pendant génération
7. Afficher erreur avec remboursement automatique

**Livrables** :
- `SmartWhiteboardContentService`
- Intégration dans `SmartWhiteboardProvider`
- Tests unitaires service

**Validation** :
- Test génération Storyboard valide
- Test erreur crédits insuffisants
- Test erreur génération
- Test timeout

**Durée estimée** : 1-2 jours

---

### D.3A.5 – Validation sur 20 Storyboards Réels

**Objectif** : Valider la génération sur 20 Storyboards réels

**Tâches** :
1. Générer 20 Storyboards (8 matières)
   - Mathématiques : 3
   - Physique : 3
   - Chimie : 2
   - Biologie : 2
   - Histoire : 3
   - Géographie : 2
   - Langues : 2
   - Informatique : 3
2. Mesurer chaque Storyboard :
   - Nombre de scènes
   - Nombre de blocs
   - Types de blocs
   - Longueur moyenne des contenus
   - Présence des métadonnées
3. Vérifier conformité :
   - storyboard_models.dart
   - SMART_WHITEBOARD_DATA_CONTRACT.md
4. Identifier anomalies :
   - Blocs vides
   - Champs absents
   - Types inconnus
   - Structures invalides
5. Construire matrice :
   - Type de bloc / Fréquence / Compatibilité éditeur
6. Déterminer opérations éditeur :
   - Modifier texte
   - Supprimer bloc
   - Déplacer bloc
   - Ajouter bloc
   - Changer ordre
7. Identifier limites de Bobodo :
   - Stabilité génération
   - Qualité pédagogique
   - Structuration scènes
8. Produire liste fonctionnalités éditeur V1 :
   - OBLIGATOIRE
   - OPTIONNEL
   - REPORTÉ V2

**Livrables** :
- Document `PHASE_D3A1_STORYBOARD_QUALITY_AUDIT.md`
- Matrice compatibilité
- Liste fonctionnalités éditeur V1

**Validation** :
- 20 Storyboards générés avec succès
- 100% conformité storyboard_models.dart
- 100% conformité Data Contract
- Aucun bloc vide
- Aucun champ absent

**Durée estimée** : 2-3 jours

---

### D.3B – Storyboard Editor

**Objectif** : Créer `SmartWhiteboardStoryboardEditorScreen`

**Tâches** :
1. Créer `SmartWhiteboardStoryboardEditorScreen`
2. Afficher Storyboard JSON en UI
3. Implémenter édition scènes :
   - Modifier titre
   - Modifier durée
   - Réordonner scènes
   - Supprimer scène
   - Ajouter scène
4. Implémenter édition blocs :
   - Modifier contenu
   - Modifier type
   - Réordonner blocs
   - Supprimer bloc
   - Ajouter bloc
5. Implémenter preview render :
   - Preview scène par scène
   - Preview bloc par bloc
6. Connecter `SmartWhiteboardProvider` :
   - `updateStoryboard()`
   - `addScene()`
   - `deleteScene()`
   - `addBlock()`
   - `deleteBlock()`
7. Implémenter sauvegarde automatique
8. Implémenter navigation vers render

**Livrables** :
- `SmartWhiteboardStoryboardEditorScreen`
- Tests Widget éditeur
- Documentation éditeur

**Validation** :
- Test édition scènes
- Test édition blocs
- Test sauvegarde automatique
- Test navigation render
- Non-régression (aucun composant Challenge modifié)

**Durée estimée** : 4-5 jours

---

### D.4 – Narration

**Objectif** : Implémenter la narration audio

**Tâches** :
1. Créer `SmartWhiteboardNarrationService`
2. Implémenter TTS (Text-to-Speech) :
   - Utiliser Edge Function TTS existante ou créer nouvelle
   - Générer audio depuis texte blocs
   - Stocker audio dans Supabase Storage
3. Implémenter enregistrement utilisateur :
   - Enregistrement micro
   - Upload audio
   - Stockage audio
4. Implémenter sélection narration mode :
   - none (pas de narration)
   - tts (synthèse vocale)
   - user_recording (enregistrement utilisateur)
5. Connecter `SmartWhiteboardProvider` :
   - `generateNarration()`
   - `uploadNarration()`
   - `deleteNarration()`
6. Intégrer narration dans Storyboard JSON
7. Implémenter UI sélection narration

**Livrables** :
- `SmartWhiteboardNarrationService`
- Edge Function TTS (si nécessaire)
- Intégration narration dans éditeur
- Tests narration

**Validation** :
- Test TTS génération
- Test enregistrement utilisateur
- Test sélection narration mode
- Test intégration Storyboard

**Durée estimée** : 3-4 jours

---

### D.5 – Render Monitor

**Objectif** : Implémenter le monitoring du rendu vidéo

**Tâches** :
1. Créer `SmartWhiteboardRenderService`
2. Implémenter création render job :
   - Appel Kamatera Renderer
   - Stockage render job dans Supabase
3. Implémenter polling status :
   - Polling Kamatera API
   - Mise à jour status Supabase
   - Gestion timeout
4. Implémenter récupération vidéo :
   - Téléchargement MP4 depuis Kamatera
   - Upload Supabase Storage
   - Mise à jour URL vidéo
5. Implémenter UI monitoring :
   - Affichage progress bar
   - Affichage status
   - Affichage erreur
6. Connecter `SmartWhiteboardProvider` :
   - `createRenderJob()`
   - `pollRenderJob()`
   - `getRenderVideoUrl()`
7. Implémenter navigation vers preview vidéo

**Livrables** :
- `SmartWhiteboardRenderService`
- Intégration Kamatera Renderer
- UI monitoring render
- Tests render

**Validation** :
- Test création render job
- Test polling status
- Test récupération vidéo
- Test UI monitoring

**Durée estimée** : 3-4 jours

---

### D.6 – Intégration Flutter Finale

**Objectif** : Intégrer tous les composants dans l'app Flutter

**Tâches** :
1. Intégrer navigation complète :
   - Input Screen → Editor → Render Monitor → Preview
2. Intégrer onglet Challenge :
   - Bouton "Smart Whiteboard" dans `student_challenges_tab.dart`
   - Navigation vers `SmartWhiteboardInputScreen`
3. Implémenter permissions :
   - Permission micro (narration)
   - Permission stockage (téléchargement vidéo)
4. Implémenter paywall :
   - Vérifier crédits avant génération
   - Dialogue achat crédits
5. Implémenter gestion erreurs :
   - Snackbar erreurs
   - Dialogue confirmation
6. Implémenter analytics :
   - Tracking génération Storyboard
   - Tracking render
   - Tracking erreurs
7. Tests E2E :
   - Flux complet génération → édition → render → preview
   - Test avec crédits insuffisants
   - Test avec erreur render

**Livrables** :
- Intégration navigation complète
- Intégration onglet Challenge
- Tests E2E
- Documentation utilisateur

**Validation** :
- Test flux complet
- Test navigation
- Test permissions
- Test paywall
- Test analytics
- Non-régression (aucun composant Challenge modifié)

**Durée estimée** : 3-4 jours

---

## PARTIE 2 – DURÉE TOTALE

### Estimation

| Phase | Durée |
|-------|-------|
| D.3A.3 – Content Generation Agent | 2-3 jours |
| D.3A.4 – Connexion OpenRouter | 1-2 jours |
| D.3A.5 – Validation 20 Storyboards | 2-3 jours |
| D.3B – Storyboard Editor | 4-5 jours |
| D.4 – Narration | 3-4 jours |
| D.5 – Render Monitor | 3-4 jours |
| D.6 – Intégration Flutter Finale | 3-4 jours |
| **Total** | **18-25 jours** |

### Risques

| Risque | Impact | Mitigation |
|-------|--------|------------|
| OpenRouter instable | Élevé | Cascade multi-modèles |
| Kamatera Renderer non prêt | Élevé | Renderer fallback local |
| Validation Storyboard échoue | Moyen | Itération prompts |
| Crédits insuffisants | Faible | Dialogue achat crédits |

---

## PARTIE 3 – CRITÈRE DE RÉUSSITE

### D.3A.3

- ✅ Edge Function déployée
- ✅ Génération Storyboard valide
- ✅ Gestion crédits fonctionnelle
- ✅ Validation JSON stricte

### D.3A.4

- ✅ Flutter connecté à Edge Function
- ✅ Gestion erreurs complète
- ✅ Loading UI fonctionnelle

### D.3A.5

- ✅ 20 Storyboards générés
- ✅ 100% conformité Data Contract
- ✅ Matrice compatibilité produite
- ✅ Liste fonctionnalités éditeur V1 définie

### D.3B

- ✅ Éditeur Storyboard fonctionnel
- ✅ Édition scènes/blocs
- ✅ Sauvegarde automatique
- ✅ Non-régression

### D.4

- ✅ Narration TTS fonctionnelle
- ✅ Enregistrement utilisateur fonctionnel
- ✅ Intégration Storyboard

### D.5

- ✅ Render monitoring fonctionnel
- ✅ Polling status
- ✅ Récupération vidéo

### D.6

- ✅ Intégration Flutter complète
- ✅ Navigation complète
- ✅ Tests E2E
- ✅ Non-régression

---

## CONCLUSION

### Roadmap Complète

Le plan d'implémentation est défini pour :
- ✅ D.3A.3 – Content Generation Agent
- ✅ D.3A.4 – Connexion OpenRouter
- ✅ D.3A.5 – Validation 20 Storyboards
- ✅ D.3B – Storyboard Editor
- ✅ D.4 – Narration
- ✅ D.5 – Render Monitor
- ✅ D.6 – Intégration Flutter Finale

### Durée Totale

**18-25 jours** pour l'implémentation complète du Smart Whiteboard.

### Prochaine Étape

Commencer D.3A.3 – Création du Content Generation Agent.

---

**Fin de PHASE D.3A.2 – IMPLEMENTATION ROADMAP**
