# OFFICIAL RPC REGISTRY - WHITEBOARD

**Date**: 2026-06-26
**Version app**: 1.0.6+11
**Méthode**: Registre officiel des RPCs et objets whiteboard autorisés

---

## SOURCE OFFICIELLE

Les fichiers SQL officiels sont dans `.windsurf/sql/` et `.windsurf/sql_changes/`.

### Fichiers SQL officiels

| Fichier | Rôle | Statut |
|---------|------|--------|
| `.windsurf/sql/05_create_rpcs_worker.sql` | RPCs worker public | OFFICIEL |
| `.windsurf/sql/06_create_rpcs_editor.sql` | RPCs editor app | OFFICIEL (mais app non accessible) |
| `.windsurf/sql/07_create_public_wrapper_rpc.sql` | Wrappers public | OFFICIEL |
| `.windsurf/sql/04_create_triggers.sql` | Triggers updated_at | OFFICIEL |
| `.windsurf/sql_changes/change_20260623_whiteboard_worker_rpcs.sql` | RPCs worker public | OFFICIEL |
| `.windsurf/sql_changes/change_20260624_whiteboard_editor_rpcs.sql` | RPCs editor app | OFFICIEL (mais app non accessible) |
| `.windsurf/sql_changes/change_20260624_whiteboard_tables_buckets.sql` | Tables + RLS + trigger | OFFICIEL |

### Fichiers de contrat officiels

| Fichier | Rôle |
|---------|------|
| `.windsurf/whiteboard_rpc_contract.md` | Contrat officiel des signatures |
| `.windsurf/whiteboard_rpc_wiring.md` | Cartographie Flutter ↔ Supabase |
| `.windsurf/flutter_rpc_contracts.md` | Appels Flutter réels (MISSION D.12) |

---

## REGISTRE OFFICIEL DES RPCs

### RPCs FLUTTER (schéma public obligatoire)

Ces RPCs sont appelées par Flutter via PostgREST. Elles doivent exister dans le schéma `public` avec les signatures exactes ci-dessous.

| # | RPC | Schéma | Signature | Source officielle | Statut |
|---|-----|--------|-----------|-------------------|--------|
| 1 | whiteboard_create_project | public | `(p_student_id uuid, p_subject text, p_renderer_id text, p_theme_id text, p_narration_mode text, p_storyboard_json jsonb) RETURNS jsonb` | Contrat Flutter | À CRÉER |
| 2 | whiteboard_get_project | public | `(p_project_id uuid) RETURNS jsonb` | Contrat Flutter | À CRÉER |
| 3 | whiteboard_update_project | public | `(p_project_id uuid, p_subject text DEFAULT NULL, p_status text DEFAULT NULL, p_renderer_id text DEFAULT NULL, p_theme_id text DEFAULT NULL, p_narration_mode text DEFAULT NULL, p_storyboard_json jsonb DEFAULT NULL) RETURNS jsonb` | Contrat Flutter | À CRÉER |
| 4 | whiteboard_list_projects | public | `(p_status text DEFAULT NULL) RETURNS jsonb` | Contrat Flutter | À CRÉER |
| 5 | whiteboard_delete_project | public | `(p_project_id uuid) RETURNS jsonb` | Contrat Flutter | À CRÉER |
| 6 | whiteboard_create_render_job | public | `(p_project_id uuid) RETURNS jsonb` | Contrat Flutter | À CRÉER |
| 7 | whiteboard_get_render_status | public | `(p_render_id uuid) RETURNS jsonb` | Contrat Flutter | À CRÉER |

### RPCs WORKER (schéma public)

Ces RPCs sont utilisées par le worker Python. Elles doivent rester dans le schéma `public`.

| # | RPC | Schéma | Signature | Source officielle | Statut |
|---|-----|--------|-----------|-------------------|--------|
| 8 | whiteboard_fetch_queued_jobs | public | `(p_limit integer DEFAULT 5) RETURNS TABLE(id uuid, storyboard jsonb, created_at timestamptz)` | `sql/05_create_rpcs_worker.sql` | KEEP |
| 9 | whiteboard_mark_processing | public | `(p_job_id uuid) RETURNS void` | `sql/05_create_rpcs_worker.sql` | KEEP |
| 10 | whiteboard_mark_done | public | `(p_job_id uuid, p_video_url text, p_duration_ms integer) RETURNS void` | `sql/05_create_rpcs_worker.sql` | KEEP |
| 11 | whiteboard_mark_failed | public | `(p_job_id uuid, p_error_message text) RETURNS void` | `sql/05_create_rpcs_worker.sql` | KEEP |
| 12 | whiteboard_get_any_student_id | public | `() RETURNS uuid` | `sql/05_create_rpcs_worker.sql` | KEEP |

### RPCs INTERNES (schéma app)

Ces RPCs sont dans le schéma `app` et ne sont PAS accessibles directement via PostgREST. Elles ne doivent PAS être appelées par Flutter. Elles peuvent servir de wrappers internes si nécessaire, mais dans notre cas elles sont des doublons.

| # | RPC | Schéma | Signature | Source officielle | Statut |
|---|-----|--------|-----------|-------------------|--------|
| 13 | app_whiteboard_create_project | app | `(p_student_id uuid, p_subject varchar, ...) RETURNS jsonb` | `sql/06_create_rpcs_editor.sql` | DELETE |
| 14 | whiteboard_create_project | app | `(p_subject text, p_renderer_id text, ...) RETURNS jsonb` | `sql/06_create_rpcs_editor.sql` | DELETE |
| 15 | whiteboard_get_project | app | `(p_project_id uuid) RETURNS jsonb` | `sql/06_create_rpcs_editor.sql` | DELETE |
| 16 | whiteboard_update_project | app | `(p_project_id uuid, ...) RETURNS jsonb` | `sql/06_create_rpcs_editor.sql` | DELETE |
| 17 | whiteboard_list_projects | app | `(p_status text) RETURNS jsonb` | `sql/06_create_rpcs_editor.sql` | DELETE |
| 18 | whiteboard_delete_project | app | `(p_project_id uuid) RETURNS jsonb` | `sql/06_create_rpcs_editor.sql` | DELETE |
| 19 | whiteboard_create_render_job | app | `(p_project_id uuid) RETURNS jsonb` | Historique | DELETE |
| 20 | whiteboard_get_render_status | app | `(p_render_id uuid) RETURNS jsonb` | Historique | DELETE |

### FONCTIONS TRIGGER (schéma app)

| # | Fonction | Schéma | Signature | Source officielle | Statut |
|---|----------|--------|-----------|-------------------|--------|
| 21 | whiteboard_projects_updated_at | app | `() RETURNS trigger` | `sql/04_create_triggers.sql` | KEEP |
| 22 | whiteboard_ai_generations_updated_at | app | `() RETURNS trigger` | `sql/04_create_triggers.sql` | KEEP |
| 23 | update_whiteboard_projects_updated_at | app | `() RETURNS trigger` | Historique | DELETE (doublon) |

---

## TABLES OFFICIELLES

| # | Table | Schéma | Source officielle | Statut |
|---|-------|--------|-------------------|--------|
| 1 | whiteboard_projects | app | `sql/02_create_whiteboard_tables.sql` | KEEP |
| 2 | whiteboard_renders | app | `sql/02_create_whiteboard_tables.sql` | KEEP |
| 3 | whiteboard_ai_generations | app | `sql/02_create_whiteboard_tables.sql` | KEEP (obsolète) |

---

## SYNTHÈSE KEEP / DELETE

### KEEP (8 objets)

| Type | Nom | Schéma |
|------|-----|--------|
| RPC worker | whiteboard_fetch_queued_jobs | public |
| RPC worker | whiteboard_mark_processing | public |
| RPC worker | whiteboard_mark_done | public |
| RPC worker | whiteboard_mark_failed | public |
| RPC worker | whiteboard_get_any_student_id | public |
| Trigger | whiteboard_projects_updated_at | app |
| Trigger | whiteboard_ai_generations_updated_at | app |
| Table | whiteboard_projects | app |
| Table | whiteboard_renders | app |
| Table | whiteboard_ai_generations | app |

### DELETE (toutes les versions non conformes)

Toutes les versions non conformes des 7 RPCs Flutter dans `app` et `public` doivent être supprimées.

### CREATE (7 RPCs)

Les 7 RPCs Flutter doivent être créées dans `public` avec les signatures exactes du contrat.

---

## RÈGLE ABSOLUE

Aucune création ou suppression sans:
1. Lecture de `.windsurf`
2. Comparaison avec Flutter
3. Validation via `pg_proc`

Ce registre est la source de vérité officielle pour le nettoyage D.13.
