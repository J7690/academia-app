# PHASE C.3C – REMEDIATION PLAN

**Date** : 23 Juin 2026  
**Phase** : C.3C – Remediation Plan  
**Mode** : PRÉPARATION SEULEMENT  
**Objectif** : Préparer la remise en conformité complète du Smart Whiteboard

---

## DIRECTIVE

**AUCUNE MODIFICATION**  
**AUCUNE MIGRATION**  
**AUCUNE CORRECTION**

---

## PARTIE 1 – LISTE DES CORRECTIONS

### Correction C1 : Corriger CHECK status

**Problème** : La contrainte `whiteboard_renders_status_check` n'autorise que `('processing', 'failed')` au lieu de `('queued', 'processing', 'done', 'failed')`

**Impact** :
- Worker ne peut pas créer de jobs avec `status='queued'`
- Worker ne peut pas marquer les jobs comme `done`
- Flux complet Storyboard → MP4 impossible

**Dépendances** :
- Aucune (correction isolée)

**Risque** : **FAIBLE**
- Modification d'une contrainte CHECK
- Aucun impact sur les données existantes
- Aucun impact sur les autres tables

---

### Correction C2 : Ajouter colonne export_settings

**Problème** : La colonne `export_settings` est absente de `whiteboard_renders` mais spécifiée dans le Data Contract

**Impact** :
- ExportSettings non stocké dans la base
- Paramètres d'export vidéo perdus

**Dépendances** :
- Aucune (ajout de colonne)

**Risque** : **FAIBLE**
- Ajout de colonne NULLABLE
- Aucun impact sur les données existantes
- Aucun impact sur les requêtes existantes

---

### Correction C3 : Ajouter colonne started_at

**Problème** : La colonne `started_at` est absente de `whiteboard_renders` mais utilisée par les RPCs C.3B.1

**Impact** :
- RPC `whiteboard_mark_processing` échouera
- Worker ne peut pas marquer les jobs comme processing

**Dépendances** :
- Correction C4 (création RPCs V1) peut rendre cette correction inutile

**Risque** : **FAIBLE**
- Ajout de colonne NULLABLE
- Aucun impact sur les données existantes

---

### Correction C4 : Créer 7 RPCs V1

**Problème** : Les 7 RPCs spécifiées dans V1 Final Spec n'ont pas été créées

**Impact** :
- Flux Flutter impossible
- Écrans Smart Whiteboard non fonctionnels

**Dépendances** :
- Aucune (création de RPCs)

**Risque** : **FAIBLE**
- Création de nouvelles RPCs
- Aucun impact sur les RPCs existantes

---

### Correction C5 : Supprimer/renommer RPCs C.3B.1

**Problème** : Les 5 RPCs créées en C.3B.1 ne sont pas conformes à la spécification V1

**Impact** :
- Confusion entre RPCs V1 et RPCs C.3B.1
- Worker dépend de RPCs non conformes

**Dépendances** :
- Correction C4 (si les RPCs V1 remplacent les RPCs C.3B.1)

**Risque** : **MOYEN**
- Suppression de RPCs utilisées par le worker
- Nécessite modification du worker

---

### Correction C6 : Harmoniser narration_mode

**Problème** : La contrainte utilise `'user_recording'` mais la spécification V1 utilise `'user'`

**Impact** :
- Écart entre spécification et implémentation
- Confusion potentielle pour les développeurs

**Dépendances** :
- Aucune (modification de contrainte)

**Risque** : **MOYEN**
- Modification de contrainte CHECK
- Impact sur les données existantes si elles contiennent `'user_recording'`

---

### Correction C7 : Décider de progress

**Problème** : La colonne `progress` est présente mais non spécifiée dans V1

**Impact** :
- Écart entre spécification et implémentation

**Dépendances** :
- Aucune (décision de conserver ou supprimer)

**Risque** : **FAIBLE**
- Si conservé : ajouter à la spécification
- Si supprimé : suppression de colonne

---

### Correction C8 : Supprimer whiteboard_get_any_student_id

**Problème** : RPC de test non supprimée

**Impact** :
- Nettoyage des RPCs de test

**Dépendances** :
- Aucune (suppression de RPC)

**Risque** : **FAIBLE**
- Suppression de RPC non utilisée

---

## PARTIE 2 – ORDRE D'EXÉCUTION

### Ordre recommandé

```
C1 : Corriger CHECK status
  ↓
C2 : Ajouter colonne export_settings
  ↓
C3 : Ajouter colonne started_at
  ↓
C4 : Créer 7 RPCs V1
  ↓
C5 : Supprimer/renommer RPCs C.3B.1
  ↓
C6 : Harmoniser narration_mode
  ↓
C7 : Décider de progress
  ↓
C8 : Supprimer whiteboard_get_any_student_id
```

### Justification de l'ordre

1. **C1 en premier** : La contrainte CHECK est le blocage critique. Sans cette correction, aucune autre correction n'est utile car le worker ne peut pas fonctionner.

2. **C2 et C3 ensuite** : Ajouts de colonnes nécessaires pour le fonctionnement complet. Ces corrections sont indépendantes et peuvent être faites en parallèle.

3. **C4 ensuite** : Création des RPCs V1. Ces RPCs sont nécessaires pour le flux Flutter. Elles doivent être créées avant de supprimer les RPCs C.3B.1.

4. **C5 ensuite** : Suppression des RPCs C.3B.1. Cette correction dépend de C4 car les RPCs V1 doivent remplacer les RPCs C.3B.1.

5. **C6 ensuite** : Harmonisation de narration_mode. Cette correction est indépendante et peut être faite à tout moment, mais elle est faite après les corrections critiques.

6. **C7 ensuite** : Décision sur progress. Cette correction est indépendante et peut être faite à tout moment.

7. **C8 en dernier** : Nettoyage final. Cette correction est la moins prioritaire et peut être faite à tout moment.

---

## PARTIE 3 – SIMULATION D'IMPACT

### Correction C1 : Corriger CHECK status

**Tables touchées** :
- `app.whiteboard_renders` (contrainte modifiée)

**RPCs touchées** :
- Aucune (contrainte modifiée directement)

**Worker touché** :
- ✅ OUI (peut maintenant créer des jobs avec `status='queued'`)

**Storage touché** :
- ❌ Non

**Kamatera touché** :
- ❌ Non

---

### Correction C2 : Ajouter colonne export_settings

**Tables touchées** :
- `app.whiteboard_renders` (colonne ajoutée)

**RPCs touchées** :
- Aucune (colonne ajoutée directement)

**Worker touché** :
- ❌ Non (colonne non utilisée par le worker actuel)

**Storage touché** :
- ❌ Non

**Kamatera touché** :
- ❌ Non

---

### Correction C3 : Ajouter colonne started_at

**Tables touchées** :
- `app.whiteboard_renders` (colonne ajoutée)

**RPCs touchées** :
- `public.whiteboard_mark_processing` (utilise `started_at`)

**Worker touché** :
- ✅ OUI (peut maintenant marquer les jobs comme processing)

**Storage touché** :
- ❌ Non

**Kamatera touché** :
- ❌ Non

---

### Correction C4 : Créer 7 RPCs V1

**Tables touchées** :
- Aucune (création de RPCs)

**RPCs touchées** :
- 7 nouvelles RPCs créées dans le schema `app`

**Worker touché** :
- ❌ Non (worker utilise les RPCs C.3B.1)

**Storage touché** :
- ❌ Non

**Kamatera touché** :
- ❌ Non

---

### Correction C5 : Supprimer/renommer RPCs C.3B.1

**Tables touchées** :
- Aucune (suppression de RPCs)

**RPCs touchées** :
- 5 RPCs supprimées ou renommées

**Worker touché** :
- ✅ OUI (doit être modifié pour utiliser les RPCs V1)

**Storage touché** :
- ❌ Non

**Kamatera touché** :
- ❌ Non

---

### Correction C6 : Harmoniser narration_mode

**Tables touchées** :
- `app.whiteboard_projects` (contrainte modifiée)

**RPCs touchées** :
- Aucune (contrainte modifiée directement)

**Worker touché** :
- ❌ Non

**Storage touché** :
- ❌ Non

**Kamatera touché** :
- ❌ Non

---

### Correction C7 : Décider de progress

**Tables touchées** :
- `app.whiteboard_renders` (colonne supprimée ou conservée)

**RPCs touchées** :
- Aucune

**Worker touché** :
- ❌ Non

**Storage touché** :
- ❌ Non

**Kamatera touché** :
- ❌ Non

---

### Correction C8 : Supprimer whiteboard_get_any_student_id

**Tables touchées** :
- Aucune (suppression de RPC)

**RPCs touchées** :
- 1 RPC supprimée

**Worker touché** :
- ❌ Non

**Storage touché** :
- ❌ Non

**Kamatera touché** :
- ❌ Non

---

## PARTIE 4 – CORRECTIONS SANS INTERRUPTION

### Corrections applicables sans interruption

| Correction | Sans interruption | Justification |
|-------------|-------------------|----------------|
| C1 : Corriger CHECK status | ✅ OUI | Modification de contrainte, aucune donnée modifiée |
| C2 : Ajouter export_settings | ✅ OUI | Ajout de colonne NULLABLE, aucune donnée modifiée |
| C3 : Ajouter started_at | ✅ OUI | Ajout de colonne NULLABLE, aucune donnée modifiée |
| C4 : Créer 7 RPCs V1 | ✅ OUI | Création de nouvelles RPCs, aucune RPC existante modifiée |
| C6 : Harmoniser narration_mode | ⚠️ Conditionnel | Si aucune donnée contient `'user_recording'` |
| C7 : Décider de progress | ✅ OUI | Ajout à la spécification (pas de modification DB) |
| C8 : Supprimer whiteboard_get_any_student_id | ✅ OUI | Suppression de RPC non utilisée |

### Corrections nécessitant une interruption

| Correction | Nécessite interruption | Justification |
|-------------|------------------------|----------------|
| C5 : Supprimer/renommer RPCs C.3B.1 | ✅ OUI | Worker utilise ces RPCs, doit être arrêté et modifié |

---

## PARTIE 5 – CORRECTIONS NÉCESSITANT ARRÊT/REDÉPLOIEMENT/MIGRATION

### Corrections nécessitant un arrêt du worker

| Correction | Arrêt worker | Justification |
|-------------|--------------|----------------|
| C5 : Supprimer/renommer RPCs C.3B.1 | ✅ OUI | Worker utilise ces RPCs |

### Corrections nécessitant un redéploiement

| Correction | Redéploiement | Justification |
|-------------|---------------|----------------|
| C5 : Supprimer/renommer RPCs C.3B.1 | ✅ OUI | Worker doit être modifié pour utiliser les RPCs V1 |

### Corrections nécessitant une migration

| Correction | Migration | Justification |
|-------------|-----------|----------------|
| Aucune | ❌ Non | Toutes les corrections sont des modifications directes |

---

## PARTIE 6 – ROLLBACK COMPLET

### Rollback C1 : Corriger CHECK status

**Rollback** :
```sql
ALTER TABLE app.whiteboard_renders DROP CONSTRAINT whiteboard_renders_status_check;

ALTER TABLE app.whiteboard_renders 
ADD CONSTRAINT whiteboard_renders_status_check 
CHECK (status IN ('processing', 'failed'));
```

**Vérification** :
```sql
-- Tester l'insertion avec status='queued' (doit échouer)
INSERT INTO app.whiteboard_renders (id, project_id, status)
VALUES ('test-id', 'test-project-id', 'queued');
-- Doit retourner : violates check constraint "whiteboard_renders_status_check"
```

**Critères d'annulation** :
- Si le worker ne peut plus créer de jobs avec `status='queued'`
- Si les tests d'insertion échouent

---

### Rollback C2 : Ajouter colonne export_settings

**Rollback** :
```sql
ALTER TABLE app.whiteboard_renders DROP COLUMN IF EXISTS export_settings;
```

**Vérification** :
```sql
-- Vérifier que la colonne n'existe plus
SELECT column_name FROM information_schema.columns 
WHERE table_schema = 'app' AND table_name = 'whiteboard_renders' AND column_name = 'export_settings';
-- Doit retourner : 0 rows
```

**Critères d'annulation** :
- Si la colonne ne peut pas être supprimée (données présentes)
- Si les requêtes existantes échouent

---

### Rollback C3 : Ajouter colonne started_at

**Rollback** :
```sql
ALTER TABLE app.whiteboard_renders DROP COLUMN IF EXISTS started_at;
```

**Vérification** :
```sql
-- Vérifier que la colonne n'existe plus
SELECT column_name FROM information_schema.columns 
WHERE table_schema = 'app' AND table_name = 'whiteboard_renders' AND column_name = 'started_at';
-- Doit retourner : 0 rows
```

**Critères d'annulation** :
- Si la colonne ne peut pas être supprimée (données présentes)
- Si les RPCs C.3B.1 échouent

---

### Rollback C4 : Créer 7 RPCs V1

**Rollback** :
```sql
DROP FUNCTION IF EXISTS app.app_whiteboard_create_project;
DROP FUNCTION IF EXISTS app.app_whiteboard_update_project;
DROP FUNCTION IF EXISTS app.app_whiteboard_get_project;
DROP FUNCTION IF EXISTS app.app_whiteboard_list_projects;
DROP FUNCTION IF EXISTS app.app_whiteboard_delete_project;
DROP FUNCTION IF EXISTS app.app_whiteboard_create_render_job;
DROP FUNCTION IF EXISTS app.app_whiteboard_get_render_status;
```

**Vérification** :
```sql
-- Vérifier que les RPCs n'existent plus
SELECT routine_name FROM information_schema.routines 
WHERE routine_schema = 'app' AND routine_name LIKE 'app_whiteboard_%';
-- Doit retourner : 0 rows
```

**Critères d'annulation** :
- Si les RPCs ne peuvent pas être supprimées
- Si les écrans Flutter échouent

---

### Rollback C5 : Supprimer/renommer RPCs C.3B.1

**Rollback** :
```sql
-- Si supprimées : Recréer les RPCs C.3B.1
CREATE OR REPLACE FUNCTION public.whiteboard_fetch_queued_jobs(p_limit integer DEFAULT 5)
RETURNS TABLE (id uuid, storyboard jsonb, created_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT wr.id, wp.storyboard_json as storyboard, wr.created_at
    FROM app.whiteboard_renders wr
    JOIN app.whiteboard_projects wp ON wr.project_id = wp.id
    WHERE wr.status = 'queued'
    ORDER BY wr.created_at ASC
    LIMIT p_limit;
END;
$$;

-- Recréer les autres RPCs C.3B.1...
```

**Vérification** :
```sql
-- Vérifier que les RPCs existent
SELECT routine_name FROM information_schema.routines 
WHERE routine_schema = 'public' AND routine_name LIKE 'whiteboard_%';
-- Doit retourner : 5 rows
```

**Critères d'annulation** :
- Si le worker ne peut pas utiliser les RPCs V1
- Si les tests d'intégration échouent

---

### Rollback C6 : Harmoniser narration_mode

**Rollback** :
```sql
ALTER TABLE app.whiteboard_projects DROP CONSTRAINT whiteboard_projects_narration_mode_check;

ALTER TABLE app.whiteboard_projects 
ADD CONSTRAINT whiteboard_projects_narration_mode_check 
CHECK (narration_mode IN ('none', 'tts', 'user_recording'));
```

**Vérification** :
```sql
-- Tester l'insertion avec narration_mode='user' (doit échouer)
INSERT INTO app.whiteboard_projects (id, student_id, subject, status, renderer_id, theme_id, narration_mode, storyboard_json)
VALUES ('test-id', 'test-student-id', 'Test', 'draft', 'scientific', 'scientific', 'user', '{}');
-- Doit retourner : violates check constraint "whiteboard_projects_narration_mode_check"
```

**Critères d'annulation** :
- Si les données existantes contiennent `'user'`
- Si les écrans Flutter échouent

---

### Rollback C7 : Décider de progress

**Rollback** (si supprimée) :
```sql
ALTER TABLE app.whiteboard_renders ADD COLUMN progress INTEGER CHECK (progress >= 0 AND progress <= 100);
```

**Vérification** :
```sql
-- Vérifier que la colonne existe
SELECT column_name FROM information_schema.columns 
WHERE table_schema = 'app' AND table_name = 'whiteboard_renders' AND column_name = 'progress';
-- Doit retourner : 1 row
```

**Critères d'annulation** :
- Si la colonne ne peut pas être ajoutée
- Si les requêtes existantes échouent

---

### Rollback C8 : Supprimer whiteboard_get_any_student_id

**Rollback** :
```sql
CREATE OR REPLACE FUNCTION public.whiteboard_get_any_student_id()
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_student_id uuid;
BEGIN
    SELECT id INTO v_student_id FROM app.students LIMIT 1;
    RETURN v_student_id;
END;
$$;
```

**Vérification** :
```sql
-- Vérifier que la RPC existe
SELECT routine_name FROM information_schema.routines 
WHERE routine_schema = 'public' AND routine_name = 'whiteboard_get_any_student_id';
-- Doit retourner : 1 row
```

**Critères d'annulation** :
- Si la RPC ne peut pas être recréée
- Si les scripts de test échouent

---

## PARTIE 7 – VALIDATIONS POST-CORRECTION

### Validation V1 : CHECK status

```sql
-- Test 1 : INSERT avec status='queued' (doit réussir)
INSERT INTO app.whiteboard_renders (id, project_id, status)
VALUES ('test-queued', 'test-project-id', 'queued');
-- Attendu : Succès

-- Test 2 : INSERT avec status='processing' (doit réussir)
INSERT INTO app.whiteboard_renders (id, project_id, status)
VALUES ('test-processing', 'test-project-id', 'processing');
-- Attendu : Succès

-- Test 3 : INSERT avec status='done' (doit réussir)
INSERT INTO app.whiteboard_renders (id, project_id, status)
VALUES ('test-done', 'test-project-id', 'done');
-- Attendu : Succès

-- Test 4 : INSERT avec status='failed' (doit réussir)
INSERT INTO app.whiteboard_renders (id, project_id, status)
VALUES ('test-failed', 'test-project-id', 'failed');
-- Attendu : Succès

-- Test 5 : INSERT avec status='invalid' (doit échouer)
INSERT INTO app.whiteboard_renders (id, project_id, status)
VALUES ('test-invalid', 'test-project-id', 'invalid');
-- Attendu : violates check constraint "whiteboard_renders_status_check"

-- Nettoyage
DELETE FROM app.whiteboard_renders WHERE id LIKE 'test-%';
```

---

### Validation V2 : export_settings

```sql
-- Test 1 : INSERT avec export_settings (doit réussir)
INSERT INTO app.whiteboard_renders (id, project_id, status, export_settings)
VALUES ('test-export', 'test-project-id', 'queued', '{"format": "mp4", "resolution": {"width": 1080, "height": 1920}}');
-- Attendu : Succès

-- Test 2 : SELECT export_settings (doit retourner les données)
SELECT export_settings FROM app.whiteboard_renders WHERE id = 'test-export';
-- Attendu : {"format": "mp4", "resolution": {"width": 1080, "height": 1920}}

-- Nettoyage
DELETE FROM app.whiteboard_renders WHERE id = 'test-export';
```

---

### Validation V3 : started_at

```sql
-- Test 1 : INSERT avec started_at (doit réussir)
INSERT INTO app.whiteboard_renders (id, project_id, status, started_at)
VALUES ('test-started', 'test-project-id', 'processing', NOW());
-- Attendu : Succès

-- Test 2 : UPDATE started_at via RPC (doit réussir)
CALL public.whiteboard_mark_processing('test-started');
-- Attendu : Succès

-- Test 3 : SELECT started_at (doit retourner les données)
SELECT started_at FROM app.whiteboard_renders WHERE id = 'test-started';
-- Attendu : Timestamp valide

-- Nettoyage
DELETE FROM app.whiteboard_renders WHERE id = 'test-started';
```

---

### Validation V4 : RPCs V1

```sql
-- Test 1 : app_whiteboard_create_project (doit réussir)
SELECT app_whiteboard_create_project(
    'test-student-id',
    'Test Project',
    '{"version": "1.0", "scenes": []}'::jsonb
);
-- Attendu : {"success": true, "project_id": "uuid"}

-- Test 2 : app_whiteboard_get_project (doit réussir)
SELECT app_whiteboard_get_project('project-id-from-test-1');
-- Attendu : JSON du projet

-- Test 3 : app_whiteboard_list_projects (doit réussir)
SELECT app_whiteboard_list_projects('test-student-id');
-- Attendu : Array de projets

-- Test 4 : app_whiteboard_create_render_job (doit réussir)
SELECT app_whiteboard_create_render_job('project-id-from-test-1');
-- Attendu : {"success": true, "render_id": "uuid"}

-- Test 5 : app_whiteboard_get_render_status (doit réussir)
SELECT app_whiteboard_get_render_status('render-id-from-test-4');
-- Attendu : JSON du rendu

-- Nettoyage
CALL app_whiteboard_delete_project('project-id-from-test-1');
```

---

### Validation V5 : narration_mode

```sql
-- Test 1 : INSERT avec narration_mode='user' (doit réussir)
INSERT INTO app.whiteboard_projects (id, student_id, subject, status, renderer_id, theme_id, narration_mode, storyboard_json)
VALUES ('test-user', 'test-student-id', 'Test', 'draft', 'scientific', 'scientific', 'user', '{}');
-- Attendu : Succès

-- Test 2 : INSERT avec narration_mode='user_recording' (doit échouer si harmonisé)
INSERT INTO app.whiteboard_projects (id, student_id, subject, status, renderer_id, theme_id, narration_mode, storyboard_json)
VALUES ('test-user-recording', 'test-student-id', 'Test', 'draft', 'scientific', 'scientific', 'user_recording', '{}');
-- Attendu : violates check constraint "whiteboard_projects_narration_mode_check"

-- Nettoyage
DELETE FROM app.whiteboard_projects WHERE id LIKE 'test-%';
```

---

### Validation V6 : Flux complet

```sql
-- Étape 1 : Créer un project
SELECT app_whiteboard_create_project(
    'test-student-id',
    'Test Flux Complet',
    '{"version": "1.0", "scenes": [{"id": "scene-1", "order": 0, "title": "Test", "duration_ms": 5000, "blocks": []}]}'::jsonb
) INTO v_project_id;

-- Étape 2 : Créer un render job avec status='queued'
SELECT app_whiteboard_create_render_job(v_project_id) INTO v_render_id;

-- Étape 3 : Vérifier que le job est enqueued
SELECT status FROM app.whiteboard_renders WHERE id = v_render_id;
-- Attendu : 'queued'

-- Étape 4 : Marquer comme processing
CALL public.whiteboard_mark_processing(v_render_id);

-- Étape 5 : Vérifier que le job est processing
SELECT status FROM app.whiteboard_renders WHERE id = v_render_id;
-- Attendu : 'processing'

-- Étape 6 : Marquer comme done
CALL public.whiteboard_mark_done(v_render_id, 'https://example.com/video.mp4', 5000);

-- Étape 7 : Vérifier que le job est done
SELECT status, video_url, duration_ms FROM app.whiteboard_renders WHERE id = v_render_id;
-- Attendu : 'done', 'https://example.com/video.mp4', 5000

-- Nettoyage
CALL app_whiteboard_delete_project(v_project_id);
```

---

## PARTIE 8 – JALON FINAL

### Définition du jalon

Le système est considéré conforme uniquement lorsque le flux complet fonctionne :

```
Storyboard (Flutter)
  ↓
Bobodo (Edge Function)
  ↓
RenderJob queued (Supabase)
  ↓
Worker (Kamatera)
  ↓
PNG (Renderer)
  ↓
FFmpeg (Kamatera)
  ↓
MP4 (Storage)
  ↓
done (Supabase)
  ↓
Flutter (display)
```

### Critères de succès

1. **Storyboard créé** : ✅ L'utilisateur peut créer un Storyboard via Flutter
2. **RenderJob créé** : ✅ L'utilisateur peut créer un RenderJob avec `status='queued'`
3. **Worker détecte** : ✅ Le worker détecte le job enqueued
4. **Worker traite** : ✅ Le worker marque le job comme `processing`
5. **PNG générés** : ✅ Le worker génère les images PNG depuis le Storyboard
6. **FFmpeg encode** : ✅ Le worker encode les PNG en MP4 via FFmpeg
7. **MP4 uploadé** : ✅ Le worker upload le MP4 vers Supabase Storage
8. **Job marqué done** : ✅ Le worker marque le job comme `done`
9. **Flutter display** : ✅ L'utilisateur peut afficher le MP4 dans Flutter

### Test de validation

```python
# Script de test du flux complet
# À exécuter après toutes les corrections

# 1. Créer un Storyboard via Flutter
storyboard = {
    "version": "1.0",
    "scenes": [
        {
            "id": "scene-1",
            "order": 0,
            "title": "Test",
            "duration_ms": 5000,
            "blocks": [
                {
                    "id": "block-1",
                    "type": "title",
                    "content": "Test Title",
                    "order": 0,
                    "visible": True,
                    "style": {
                        "font_size": 48,
                        "font_weight": "bold",
                        "color": "#000000"
                    }
                }
            ]
        }
    ]
}

# 2. Créer un project via RPC
project_id = create_project(student_id, "Test", storyboard)

# 3. Créer un render job via RPC
render_id = create_render_job(project_id)

# 4. Attendre que le worker traite le job
time.sleep(30)

# 5. Vérifier le statut du job
render_status = get_render_status(render_id)

# 6. Si done, récupérer l'URL du MP4
if render_status["status"] == "done":
    video_url = render_status["video_url"]
    # 7. Afficher le MP4 dans Flutter
    display_video(video_url)
else:
    # Échec
    print(f"Job failed: {render_status['error_message']}")
```

### Critères d'échec

- Si le worker ne détecte pas le job enqueued
- Si le worker ne peut pas marquer le job comme processing
- Si le worker ne peut pas générer les PNG
- Si le worker ne peut pas encoder le MP4
- Si le worker ne peut pas uploader le MP4
- Si le worker ne peut pas marquer le job comme done
- Si Flutter ne peut pas afficher le MP4

---

## CONCLUSION

### Résumé du plan

**Corrections totales** : 8 (5 critiques, 2 majeures, 1 mineure)

**Ordre d'exécution** : C1 → C2 → C3 → C4 → C5 → C6 → C7 → C8

**Corrections sans interruption** : 7 (C1, C2, C3, C4, C6, C7, C8)

**Corrections avec interruption** : 1 (C5)

**Rollback complet** : Disponible pour chaque correction

**Validations post-correction** : 6 validations complètes

**Jalon final** : Flux complet Storyboard → MP4 fonctionnel

### Recommandation

**Exécuter les corrections dans l'ordre recommandé, avec validation après chaque correction.**

**En cas d'échec, utiliser le rollback correspondant avant de continuer.**

**Le jalon final est atteint uniquement lorsque le flux complet fonctionne réellement.**

---

**Fin du Remediation Plan**
