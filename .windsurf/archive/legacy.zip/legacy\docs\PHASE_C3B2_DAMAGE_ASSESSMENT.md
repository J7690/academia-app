# PHASE C.3B.2 – DAMAGE ASSESSMENT

**Date** : 23 Juin 2026  
**Phase** : C.3B.2 – Damage Assessment  
**Mode** : AUDIT SEULEMENT  
**Objectif** : Déterminer exactement ce qui a été modifié durant PHASE C.3B.1

---

## DIRECTIVE

**AUCUN DÉVELOPPEMENT**  
**AUCUNE NOUVELLE RPC**  
**AUCUNE MODIFICATION**  
**AUCUN DÉPLOIEMENT**

---

## PARTIE 1 – MODIFICATIONS EFFECTUÉES

### 1.1 Fichier : `academia_bobodo_backend/whiteboard_render_worker.py`

**Date** : 23 Juin 2026  
**Raison** : Remplacer l'API REST par des RPCs spécifiques pour contourner les erreurs 404 sur les tables du schema `app`

**Modifications** :

#### Avant (Lignes 65-82)
```python
async def _fetch_queued_jobs(limit: int = 5) -> List[Dict[str, Any]]:
    """Récupère les jobs en attente (status=queued)"""
    url = f"{_rest_base()}/app.{WHITEBOARD_TABLE}"
    params = {
        "status": "eq.queued",
        "order": "created_at.asc",
        "limit": str(limit),
    }
    async with httpx.AsyncClient(timeout=SUPABASE_HTTP_TIMEOUT) as client:
        resp = await client.get(url, headers=_supabase_headers(), params=params)
    resp.raise_for_status()
    return resp.json()

async def _update_job(job_id: str, updates: Dict[str, Any]) -> None:
    """Met à jour un job"""
    url = f"{_rest_base()}/app.{WHITEBOARD_TABLE}/{job_id}"
    async with httpx.AsyncClient(timeout=SUPABASE_HTTP_TIMEOUT) as client:
        resp = await client.patch(url, headers=_supabase_headers(), json=updates)
    resp.raise_for_status()
```

#### Après (Lignes 65-102)
```python
async def _fetch_queued_jobs(limit: int = 5) -> List[Dict[str, Any]]:
    """Récupère les jobs en attente (status=queued) via RPC spécifique"""
    rpc_url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/rpc/whiteboard_fetch_queued_jobs"
    async with httpx.AsyncClient(timeout=SUPABASE_HTTP_TIMEOUT) as client:
        resp = await client.post(rpc_url, headers=_supabase_headers(), json={"p_limit": limit})
    resp.raise_for_status()
    return resp.json()

async def _mark_job_processing(job_id: str) -> None:
    """Marque un job comme processing via RPC spécifique"""
    rpc_url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/rpc/whiteboard_mark_processing"
    async with httpx.AsyncClient(timeout=SUPABASE_HTTP_TIMEOUT) as client:
        resp = await client.post(rpc_url, headers=_supabase_headers(), json={"p_job_id": job_id})
    resp.raise_for_status()

async def _mark_job_done(job_id: str, video_url: str, duration_ms: int) -> None:
    """Marque un job comme done via RPC spécifique"""
    rpc_url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/rpc/whiteboard_mark_done"
    async with httpx.AsyncClient(timeout=SUPABASE_HTTP_TIMEOUT) as client:
        resp = await client.post(rpc_url, headers=_supabase_headers(), json={
            "p_job_id": job_id,
            "p_video_url": video_url,
            "p_duration_ms": duration_ms
        })
    resp.raise_for_status()

async def _mark_job_failed(job_id: str, error_message: str) -> None:
    """Marque un job comme failed via RPC spécifique"""
    rpc_url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/rpc/whiteboard_mark_failed"
    async with httpx.AsyncClient(timeout=SUPABASE_HTTP_TIMEOUT) as client:
        resp = await client.post(rpc_url, headers=_supabase_headers(), json={
            "p_job_id": job_id,
            "p_error_message": error_message
        })
    resp.raise_for_status()
```

**Impact** :
- Le worker ne dépend plus de l'API REST pour accéder aux tables du schema `app`
- Le worker utilise des RPCs spécifiques dans le schema `public`
- Les appels HTTP sont passés de GET/PATCH à POST (standard pour les RPCs)
- La logique de mise à jour a été divisée en 3 fonctions spécifiques (processing, done, failed)

---

### 1.2 Fichier : `.windsurf/sql_changes/change_20260623_whiteboard_worker_rpcs.sql`

**Date** : 23 Juin 2026  
**Raison** : Créer des RPCs spécifiques pour le worker whiteboard dans le schema `public` (accessible via l'API REST)

**Contenu** :

```sql
-- RPC pour récupérer les jobs en attente
CREATE OR REPLACE FUNCTION public.whiteboard_fetch_queued_jobs(p_limit integer DEFAULT 5)
RETURNS TABLE (
    id uuid,
    storyboard jsonb,
    created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT wr.id, wp.storyboard_json as storyboard, wr.created_at
    FROM app.whiteboard_renders wr
    JOIN app.whiteboard_projects wp ON wr.project_id = wp.id
    WHERE wr.status = 'queued'
    ORDER BY wr.created_at ASC
    LIMIT p_limit;
END;
$$;

-- RPC pour marquer un job comme processing
CREATE OR REPLACE FUNCTION public.whiteboard_mark_processing(p_job_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE app.whiteboard_renders
    SET status = 'processing',
        started_at = now()
    WHERE id = p_job_id;
END;
$$;

-- RPC pour marquer un job comme done avec succès
CREATE OR REPLACE FUNCTION public.whiteboard_mark_done(p_job_id uuid, p_video_url text, p_duration_ms integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE app.whiteboard_renders
    SET status = 'done',
        video_url = p_video_url,
        duration_ms = p_duration_ms,
        completed_at = now()
    WHERE id = p_job_id;
END;
$$;

-- RPC pour marquer un job comme failed
CREATE OR REPLACE FUNCTION public.whiteboard_mark_failed(p_job_id uuid, p_error_message text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE app.whiteboard_renders
    SET status = 'failed',
        error_message = p_error_message,
        completed_at = now()
    WHERE id = p_job_id;
END;
$$;

-- RPC pour récupérer un student_id existant
CREATE OR REPLACE FUNCTION public.whiteboard_get_any_student_id()
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_student_id uuid;
BEGIN
    SELECT id INTO v_student_id FROM app.students LIMIT 1;
    RETURN v_student_id;
END;
$$;
```

**Impact** :
- 5 RPCs créées dans le schema `public`
- Ces RPCs sont accessibles via l'API REST Supabase
- La RPC `whiteboard_fetch_queued_jobs` fait un JOIN entre `whiteboard_renders` et `whiteboard_projects` pour récupérer le storyboard
- Les RPCs de mise à jour utilisent des colonnes (`started_at`, `completed_at`) qui n'existent pas dans la spécification V1

---

### 1.3 Fichier : `docs/KAMATERA_ADMIN_PATH_DISCOVERY.md`

**Date** : 23 Juin 2026  
**Raison** : Documenter l'audit du chemin d'administration Kamatera

**Impact** : Documentation uniquement, aucun impact technique

---

### 1.4 Fichier : `docs/PHASE_C3B1_RAPPORT_SESSION.md`

**Date** : 23 Juin 2026  
**Raison** : Documenter le rapport de session PHASE C.3B.1

**Impact** : Documentation uniquement, aucun impact technique

---

## PARTIE 2 – RPCS CRÉÉES

### 2.1 RPC : `public.whiteboard_fetch_queued_jobs`

**Nom** : `whiteboard_fetch_queued_jobs`  
**Schéma** : `public`  
**SQL complet** :

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_fetch_queued_jobs(p_limit integer DEFAULT 5)
RETURNS TABLE (
    id uuid,
    storyboard jsonb,
    created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT wr.id, wp.storyboard_json as storyboard, wr.created_at
    FROM app.whiteboard_renders wr
    JOIN app.whiteboard_projects wp ON wr.project_id = wp.id
    WHERE wr.status = 'queued'
    ORDER BY wr.created_at ASC
    LIMIT p_limit;
END;
$$;
```

**Permissions** : `SECURITY DEFINER` (exécute avec les droits du propriétaire de la fonction)  
**Dépendances** :
- Table `app.whiteboard_renders`
- Table `app.whiteboard_projects`
- Colonne `app.whiteboard_projects.storyboard_json`

---

### 2.2 RPC : `public.whiteboard_mark_processing`

**Nom** : `whiteboard_mark_processing`  
**Schéma** : `public`  
**SQL complet** :

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_mark_processing(p_job_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE app.whiteboard_renders
    SET status = 'processing',
        started_at = now()
    WHERE id = p_job_id;
END;
$$;
```

**Permissions** : `SECURITY DEFINER`  
**Dépendances** :
- Table `app.whiteboard_renders`
- Colonne `app.whiteboard_renders.status`
- Colonne `app.whiteboard_renders.started_at` (**ÉCART** : cette colonne n'existe pas dans la spécification V1)

---

### 2.3 RPC : `public.whiteboard_mark_done`

**Nom** : `whiteboard_mark_done`  
**Schéma** : `public`  
**SQL complet** :

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_mark_done(p_job_id uuid, p_video_url text, p_duration_ms integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE app.whiteboard_renders
    SET status = 'done',
        video_url = p_video_url,
        duration_ms = p_duration_ms,
        completed_at = now()
    WHERE id = p_job_id;
END;
$$;
```

**Permissions** : `SECURITY DEFINER`  
**Dépendances** :
- Table `app.whiteboard_renders`
- Colonne `app.whiteboard_renders.status`
- Colonne `app.whiteboard_renders.video_url`
- Colonne `app.whiteboard_renders.duration_ms`
- Colonne `app.whiteboard_renders.completed_at` (**ÉCART** : cette colonne n'existe pas dans la spécification V1)

---

### 2.4 RPC : `public.whiteboard_mark_failed`

**Nom** : `whiteboard_mark_failed`  
**Schéma** : `public`  
**SQL complet** :

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_mark_failed(p_job_id uuid, p_error_message text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE app.whiteboard_renders
    SET status = 'failed',
        error_message = p_error_message,
        completed_at = now()
    WHERE id = p_job_id;
END;
$$;
```

**Permissions** : `SECURITY DEFINER`  
**Dépendances** :
- Table `app.whiteboard_renders`
- Colonne `app.whiteboard_renders.status`
- Colonne `app.whiteboard_renders.error_message`
- Colonne `app.whiteboard_renders.completed_at` (**ÉCART** : cette colonne n'existe pas dans la spécification V1)

---

### 2.5 RPC : `public.whiteboard_get_any_student_id`

**Nom** : `whiteboard_get_any_student_id`  
**Schéma** : `public`  
**SQL complet** :

```sql
CREATE OR REPLACE FUNCTION public.whiteboard_get_any_student_id()
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_student_id uuid;
BEGIN
    SELECT id INTO v_student_id FROM app.students LIMIT 1;
    RETURN v_student_id;
END;
$$;
```

**Permissions** : `SECURITY DEFINER`  
**Dépendances** :
- Table `app.students`

**Note** : Cette RPC a été créée pour faciliter la création de jobs de test, mais n'est pas utilisée par le worker.

---

## PARTIE 3 – AUDIT TABLES

### 3.1 Table : `app.whiteboard_projects`

**Source de vérité** : `supabase/migrations/20260623000001_create_whiteboard_tables.sql`

#### Colonnes réelles (selon migration)

```sql
CREATE TABLE app.whiteboard_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES app.students(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('draft', 'completed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  renderer_id TEXT NOT NULL CHECK (renderer_id IN ('scientific', 'notebook')),
  theme_id TEXT NOT NULL CHECK (theme_id IN ('scientific', 'notebook')),
  narration_mode TEXT NOT NULL CHECK (narration_mode IN ('none', 'tts', 'user_recording')),
  storyboard_json JSONB NOT NULL
);
```

**Colonnes** :
1. `id` (UUID, PK, DEFAULT gen_random_uuid())
2. `student_id` (UUID, NOT NULL, FK → app.students)
3. `subject` (TEXT, NOT NULL)
4. `status` (TEXT, NOT NULL, CHECK IN ('draft', 'completed'))
5. `created_at` (TIMESTAMPTZ, NOT NULL, DEFAULT NOW())
6. `updated_at` (TIMESTAMPTZ, NOT NULL, DEFAULT NOW())
7. `renderer_id` (TEXT, NOT NULL, CHECK IN ('scientific', 'notebook'))
8. `theme_id` (TEXT, NOT NULL, CHECK IN ('scientific', 'notebook'))
9. `narration_mode` (TEXT, NOT NULL, CHECK IN ('none', 'tts', 'user_recording'))
10. `storyboard_json` (JSONB, NOT NULL)

#### Contraintes réelles (selon migration)

1. **PK** : `whiteboard_projects_pkey` sur `id`
2. **FK** : `whiteboard_projects_student_id_fkey` → `app.students(id)` ON DELETE CASCADE
3. **CHECK** : `whiteboard_projects_status_check` : `status IN ('draft', 'completed')`
4. **CHECK** : `whiteboard_projects_renderer_id_check` : `renderer_id IN ('scientific', 'notebook')`
5. **CHECK** : `whiteboard_projects_theme_id_check` : `theme_id IN ('scientific', 'notebook')`
6. **CHECK** : `whiteboard_projects_narration_mode_check` : `narration_mode IN ('none', 'tts', 'user_recording')`

#### Indexes réels (selon migration)

1. `idx_whiteboard_projects_id` sur `id`
2. `idx_whiteboard_projects_student_id` sur `student_id`
3. `idx_whiteboard_projects_status` sur `status`
4. `idx_whiteboard_projects_created_at` sur `created_at`
5. `idx_whiteboard_projects_storyboard_json` (GIN) sur `storyboard_json`

#### Triggers réels (selon migration)

1. `trigger_update_whiteboard_projects_updated_at` : `BEFORE UPDATE` → exécute `app.update_whiteboard_projects_updated_at()`

---

### 3.2 Table : `app.whiteboard_renders`

**Source de vérité** : `supabase/migrations/20260623000001_create_whiteboard_tables.sql`

#### Colonnes réelles (selon migration)

```sql
CREATE TABLE app.whiteboard_renders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES app.whiteboard_projects(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('queued', 'processing', 'done', 'failed')),
  video_url TEXT,
  duration_ms INTEGER,
  error_message TEXT,
  progress INTEGER CHECK (progress >= 0 AND progress <= 100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);
```

**Colonnes** :
1. `id` (UUID, PK, DEFAULT gen_random_uuid())
2. `project_id` (UUID, NOT NULL, FK → app.whiteboard_projects)
3. `status` (TEXT, NOT NULL, CHECK IN ('queued', 'processing', 'done', 'failed'))
4. `video_url` (TEXT, NULLABLE)
5. `duration_ms` (INTEGER, NULLABLE)
6. `error_message` (TEXT, NULLABLE)
7. `progress` (INTEGER, NULLABLE, CHECK >= 0 AND <= 100)
8. `created_at` (TIMESTAMPTZ, NOT NULL, DEFAULT NOW())
9. `completed_at` (TIMESTAMPTZ, NULLABLE)

#### Contraintes réelles (selon migration)

1. **PK** : `whiteboard_renders_pkey` sur `id`
2. **FK** : `whiteboard_renders_project_id_fkey` → `app.whiteboard_projects(id)` ON DELETE CASCADE
3. **CHECK** : `whiteboard_renders_status_check` : `status IN ('queued', 'processing', 'done', 'failed')`
4. **CHECK** : `whiteboard_renders_progress_check` : `progress >= 0 AND progress <= 100`

#### Indexes réels (selon migration)

1. `idx_whiteboard_renders_id` sur `id`
2. `idx_whiteboard_renders_project_id` sur `project_id`
3. `idx_whiteboard_renders_status` sur `status`
4. `idx_whiteboard_renders_created_at` sur `created_at`

#### Triggers réels (selon migration)

Aucun trigger défini dans la migration.

---

## PARTIE 4 – POURQUOI `status='queued'` EST REFUSÉ

### 4.1 Définition exacte du CHECK

**Contrainte** : `whiteboard_renders_status_check`  
**Définition** (selon migration) :

```sql
CHECK (status IN ('queued', 'processing', 'done', 'failed'))
```

### 4.2 Requête SQL utilisée

```sql
INSERT INTO app.whiteboard_renders (id, project_id, status, progress, created_at)
VALUES ('{render_id}', '{project_id}', 'queued', 0, NOW());
```

### 4.3 Message d'erreur complet

```
new row for relation "whiteboard_renders" violates check constraint "whiteboard_renders_status_check"
SQLSTATE: 23514
```

### 4.4 Analyse

**Paradoxe** : La contrainte de check autorise explicitement `'queued'`, mais l'insertion est refusée.

**Hypothèses possibles** :

1. **La contrainte n'est pas celle définie dans la migration** : La contrainte réelle dans la base de données pourrait être différente de celle définie dans la migration.

2. **La colonne `status` a une définition différente** : La colonne pourrait avoir un type ou une contrainte différente dans la base réelle.

3. **Problème de casse** : La contrainte pourrait être sensible à la casse (bien que PostgreSQL soit généralement insensible à la casse pour les chaînes).

4. **Problème de validation avant le CHECK** : Il pourrait y avoir une autre contrainte ou trigger qui valide la valeur avant le CHECK.

5. **Problème de FK** : Le `project_id` pourrait ne pas exister dans `whiteboard_projects`, ce qui déclencherait une erreur FK avant le CHECK.

**Note** : La RPC `admin_execute_sql` ne retourne pas les données des SELECT, ce qui empêche de vérifier la définition exacte de la contrainte dans la base réelle.

---

## PARTIE 5 – CAHIER DES CHARGES VS BASE RÉELLE

### 5.1 Table `app.whiteboard_projects`

| Aspect | Cahier des charges (V1 Spec) | Base réelle (Migration) | Écart |
|--------|-----------------------------|-------------------------|-------|
| Colonnes | 10 colonnes | 10 colonnes | ✅ Aucun |
| `status` CHECK | `IN ('draft', 'completed')` | `IN ('draft', 'completed')` | ✅ Aucun |
| `renderer_id` CHECK | `IN ('scientific', 'notebook')` | `IN ('scientific', 'notebook')` | ✅ Aucun |
| `theme_id` CHECK | `IN ('scientific', 'notebook')` | `IN ('scientific', 'notebook')` | ✅ Aucun |
| `narration_mode` CHECK | `IN ('none', 'tts', 'user')` | `IN ('none', 'tts', 'user_recording')` | ⚠️ **ÉCART** |
| `storyboard_json` | JSONB NOT NULL | JSONB NOT NULL | ✅ Aucun |

**Écart identifié** :
- `narration_mode` : Spécification V1 utilise `'user'`, migration utilise `'user_recording'`

---

### 5.2 Table `app.whiteboard_renders`

| Aspect | Cahier des charges (V1 Spec) | Base réelle (Migration) | Écart |
|--------|-----------------------------|-------------------------|-------|
| Colonnes | 8 colonnes | 9 colonnes | ⚠️ **ÉCART** |
| `status` CHECK | `IN ('queued', 'processing', 'done', 'failed')` | `IN ('queued', 'processing', 'done', 'failed')` | ✅ Aucun |
| `progress` | Non spécifié | INTEGER CHECK >= 0 AND <= 100 | ⚠️ **ÉCART** |
| `started_at` | Non spécifié | Non présent | ⚠️ **ÉCART** |
| `completed_at` | Spécifié | Spécifié | ✅ Aucun |
| `export_settings` | Spécifié (JSONB) | Non présent | ⚠️ **ÉCART** |

**Écarts identifiés** :
1. **Colonne `progress`** : Présente dans la migration mais non spécifiée dans V1
2. **Colonne `started_at`** : Absente de la migration mais utilisée par les RPCs créées en C.3B.1
3. **Colonne `export_settings`** : Spécifiée dans V1 mais absente de la migration

---

### 5.3 RPCs Spécifiées vs RPCs Créées

| RPC | Spécifiée V1 | Créée C.3B.1 | Écart |
|-----|--------------|--------------|-------|
| `app_whiteboard_create_project` | ✅ | ❌ | ⚠️ **ÉCART** |
| `app_whiteboard_update_project` | ✅ | ❌ | ⚠️ **ÉCART** |
| `app_whiteboard_get_project` | ✅ | ❌ | ⚠️ **ÉCART** |
| `app_whiteboard_list_projects` | ✅ | ❌ | ⚠️ **ÉCART** |
| `app_whiteboard_delete_project` | ✅ | ❌ | ⚠️ **ÉCART** |
| `app_whiteboard_create_render_job` | ✅ | ❌ | ⚠️ **ÉCART** |
| `app_whiteboard_get_render_status` | ✅ | ❌ | ⚠️ **ÉCART** |
| `public.whiteboard_fetch_queued_jobs` | ❌ | ✅ | ⚠️ **ÉCART** |
| `public.whiteboard_mark_processing` | ❌ | ✅ | ⚠️ **ÉCART** |
| `public.whiteboard_mark_done` | ❌ | ✅ | ⚠️ **ÉCART** |
| `public.whiteboard_mark_failed` | ❌ | ✅ | ⚠️ **ÉCART** |
| `public.whiteboard_get_any_student_id` | ❌ | ✅ | ⚠️ **ÉCART** |

**Écarts identifiés** :
- Les RPCs spécifiées dans V1 sont dans le schema `app` avec préfixe `app_`
- Les RPCs créées en C.3B.1 sont dans le schema `public` sans préfixe
- Les RPCs créées en C.3B.1 sont spécifiques au worker, pas conformes à la spécification V1

---

## PARTIE 6 – COMPATIBILITÉ WORKER MODIFIÉ

### 6.1 Data Contract

**Storyboard Contract (V1 Spec)** :
- Structure : `{"version": "1.0", "scenes": [...], ...}`
- Blocs autorisés : title, paragraph, formula, definition, exercise, correction
- Métadonnées : narration_mode, renderer, theme, export_settings

**Worker modifié** :
- Récupère le storyboard via `wp.storyboard_json as storyboard`
- Utilise `job.get("storyboard")` pour accéder au storyboard
- Utilise `storyboard.get("scenes", [])` pour calculer la durée

**Compatibilité** : ✅ **COMPATIBLE**
- Le worker accède correctement au storyboard via le JOIN
- La structure du storyboard est préservée

---

### 6.2 Storyboard Contract

**Worker modifié** :
- Ligne 108 : `storyboard_json = job.get("storyboard")`
- Ligne 137-139 : `storyboard = storyboard_json if isinstance(storyboard_json, dict) else {}; scenes = storyboard.get("scenes", [])`

**Compatibilité** : ✅ **COMPATIBLE**
- Le worker gère correctement la structure du storyboard
- Le worker utilise la clé `scenes` comme spécifié

---

### 6.3 RPC Whiteboard Existantes

**RPCs spécifiées V1** (non créées) :
- `app_whiteboard_create_project`
- `app_whiteboard_update_project`
- `app_whiteboard_get_project`
- `app_whiteboard_list_projects`
- `app_whiteboard_delete_project`
- `app_whiteboard_create_render_job`
- `app_whiteboard_get_render_status`

**RPCs créées C.3B.1** (non spécifiées) :
- `public.whiteboard_fetch_queued_jobs`
- `public.whiteboard_mark_processing`
- `public.whiteboard_mark_done`
- `public.whiteboard_mark_failed`
- `public.whiteboard_get_any_student_id`

**Compatibilité** : ❌ **INCOMPATIBLE**
- Les RPCs créées ne sont pas conformes à la spécification V1
- Les RPCs créées utilisent le schema `public` au lieu de `app`
- Les RPCs créées n'ont pas le préfixe `app_`
- Les RPCs spécifiées V1 n'ont pas été créées

---

### 6.4 Colonnes Utilisées par le Worker

**Colonnes utilisées dans les RPCs créées** :
- `app.whiteboard_renders.id`
- `app.whiteboard_renders.status`
- `app.whiteboard_renders.started_at` (**ÉCART** : colonne absente de la migration)
- `app.whiteboard_renders.video_url`
- `app.whiteboard_renders.duration_ms`
- `app.whiteboard_renders.error_message`
- `app.whiteboard_renders.completed_at`
- `app.whiteboard_projects.id`
- `app.whiteboard_projects.storyboard_json`

**Compatibilité** : ❌ **INCOMPATIBLE**
- Le worker utilise `started_at` qui n'existe pas dans la migration
- Cela provoquera une erreur lors de l'exécution de `whiteboard_mark_processing`

---

## CONCLUSION

### 6.1 Modifications effectuées

1. **Worker modifié** : Remplacement de l'API REST par des RPCs spécifiques
2. **5 RPCs créées** : Dans le schema `public`, non conformes à la spécification V1
3. **Documentation créée** : 2 documents d'audit

### 6.2 Écarts avec l'architecture validée

**Écarts majeurs** :
1. **Schema des RPCs** : `public` au lieu de `app`
2. **Préfixe des RPCs** : Sans préfixe au lieu de `app_`
3. **RPCs spécifiées non créées** : 7 RPCs V1 non créées
4. **RPCs créées non spécifiées** : 5 RPCs worker non spécifiées
5. **Colonne `started_at`** : Utilisée par le worker mais absente de la migration
6. **Colonne `export_settings`** : Spécifiée V1 mais absente de la migration
7. **Colonne `progress`** : Présente dans la migration mais non spécifiée V1
8. **`narration_mode` CHECK** : `'user'` vs `'user_recording'`

### 6.3 Impact

**Immédiat** :
- Le worker ne peut pas être testé (problème de contrainte de check)
- Le worker échouera lors de l'exécution de `whiteboard_mark_processing` (colonne `started_at` absente)

**Futur** :
- Les RPCs créées ne sont pas conformes à la spécification V1
- Les RPCs spécifiées V1 doivent être créées pour le flux Flutter
- Les écarts de colonnes doivent être résolus

### 6.4 Recommandations

1. **Corriger la contrainte de check** : Investiguer pourquoi `status='queued'` est refusé
2. **Ajouter la colonne `started_at`** : Dans `app.whiteboard_renders`
3. **Créer les RPCs V1** : Dans le schema `app` avec préfixe `app_`
4. **Supprimer ou renommer les RPCs worker** : Pour éviter la confusion
5. **Harmoniser `narration_mode`** : Utiliser `'user_recording'` partout
6. **Décider de `progress`** : Ajouter à la spécification V1 ou supprimer de la migration
7. **Décider de `export_settings`** : Ajouter à la migration ou supprimer de la spécification V1

---

**Fin du Damage Assessment**
