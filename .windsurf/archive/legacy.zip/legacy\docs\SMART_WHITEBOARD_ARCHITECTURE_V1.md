# SMART WHITEBOARD IA – ARCHITECTURE V1

**Version** : 1.0  
**Date** : 23 Juin 2026  
**Mode** : LECTURE SEULE  
**Objectif** : Architecture finale avant développement

---

## RAPPEL DE LA CONTRAINTE PRINCIPALE

Le Smart Whiteboard IA est un AJOUT.

Il ne remplace rien.

Il ne modifie rien.

Il ne refond rien.

**Parcours PROTÉGÉS** :

### Parcours 1
Filmer → Edition → Description → Compression Kamatera → Publication

### Parcours 2
Importer une vidéo → Edition → Description → Compression Kamatera → Publication

Aucune modification n'est autorisée sur ces parcours.

---

## PHASE 1 – VALIDATION KAMATERA

### 1.1 Infrastructure réelle (vérifiée via SSH)

| Paramètre | Valeur |
|-----------|--------|
| **IP** | 185.167.97.144 |
| **OS** | Ubuntu 24.04.4 LTS |
| **RAM totale** | 9.7 Go |
| **RAM disponible** | 8.2 Go |
| **CPU** | 4 coeurs |
| **Disque disponible** | 12 Go |
| **FFmpeg** | 6.1.1-3ubuntu5 (installé) |
| **Docker** | 29.5.3 (installé) |
| **Conteneurs Docker** | 1 (livekit-server uniquement) |

### 1.2 Services actifs sur Kamatera

| Service | Port | Rôle | Statut |
|---------|------|------|--------|
| LiveKit Server | 7880 | Streaming temps réel | ✅ Actif |
| Redis | 6379 | Cache LiveKit | ✅ Actif |
| Nginx | 80 | Reverse proxy | ✅ Actif |

### 1.3 Observation critique

**Kamatera = LiveKit uniquement**

- Seul 1 conteneur Docker tourne : livekit-server
- FFmpeg est installé mais NON utilisé pour l'encodage vidéo
- Aucun service de transcodage vidéo n'est actif
- Pas de backend Python déployé
- Pas de worker vidéo déployé

### 1.4 Réponse à la question : Le serveur actuel peut-il héberger le Renderer V1 ?

**Réponse** : ❌ NON dans l'état actuel

**Justification** :
- FFmpeg est installé mais aucun service ne l'utilise
- Pas de backend Python déployé sur Kamatera
- Pas de worker vidéo déployé sur Kamatera
- L'architecture de traitement vidéo est locale (Docker) ou Railway (indisponible)

### 1.5 Peut-il produire un MP4 à partir d'un Storyboard JSON ?

**Réponse** : ❌ NON dans l'état actuel

**Justification** :
- Aucun service de rendu vidéo n'est actif
- Aucun composant capable d'interpréter un Storyboard JSON
- Aucun composant capable de générer une vidéo ex nihilo

### 1.6 Quels composants manquent ?

| Composant | Nécessité | Statut |
|-----------|-----------|--------|
| Backend Python avec endpoint Storyboard → MP4 | Critique | ❌ Manquant |
| Worker de rendu vidéo | Critique | ❌ Manquant |
- Docker Compose déployé sur Kamatera | Critique | ❌ Manquant |
- Système de queue de jobs | Critique | ❌ Manquant |
- Moteur de rendu Storyboard | Critique | ❌ Manquant |

### 1.7 Conclusion Phase 1

**Kamatera peut héberger le Renderer V1** : ❌ NON (développement requis)

**Déploiement nécessaire** :
- Déployer le backend Python sur Kamatera
- Déployer le worker de rendu vidéo sur Kamatera
- Configurer Docker Compose sur Kamatera
- Implémenter le moteur de rendu Storyboard

**Estimation** : 2-3 semaines de déploiement et configuration

---

## PHASE 2 – VALIDATION SUPABASE

### 2.1 Tables existantes (schéma app)

| Table | Rôle | Utilité Smart Whiteboard |
|-------|------|--------------------------|
| video_assets | Métadonnées vidéos | ✅ Réutilisable |
| video_sources | Sources vidéos | ✅ Réutilisable |
| video_renditions | Renditions multi-résolution | ✅ Réutilisable |
| video_processing_jobs | Queue de jobs vidéo | ✅ Réutilisable |
| participations | Participations challenges | ⚠️ À adapter |
| challenge_game_live_sessions | Sessions LiveKit | ❌ Non utilisé |

### 2.2 Structure de stockage proposée

#### 2.2.1 Tables nouvelles (schéma app)

| Table | Rôle | Colonnes clés |
|-------|------|--------------|
| whiteboard_projects | Projets Smart Whiteboard | id, student_id, subject, storyboard_json, theme_id, status, created_at |
| whiteboard_scenes | Scènes d'un projet | id, project_id, order, title, blocks_json, animation_config |
| whiteboard_narrations | Narrations audio | id, project_id, mode, tts_config, user_recording_url, sync_config |
| whiteboard_renders | Rendus générés | id, project_id, status, video_url, duration_ms, created_at |

#### 2.2.2 Buckets Storage

| Bucket | Rôle | Contenu |
|--------|------|---------|
| whiteboard-projects | Stockage projets | Storyboards JSON, métadonnées |
| whiteboard-narrations | Stockage narrations | Fichiers audio TTS/enregistrements |
| whiteboard-renders | Stockage rendus | MP4 générés, thumbnails |

### 2.3 RPCs nécessaires

| RPC | Rôle | Paramètres |
|-----|------|------------|
| app_whiteboard_create_project | Créer un projet | student_id, subject, storyboard_json |
| app_whiteboard_update_project | Mettre à jour un projet | project_id, storyboard_json |
| app_whiteboard_get_project | Récupérer un projet | project_id |
| app_whiteboard_list_projects | Lister les projets d'un étudiant | student_id |
| app_whiteboard_delete_project | Supprimer un projet | project_id |
| app_whiteboard_create_render_job | Créer un job de rendu | project_id, export_config |
| app_whiteboard_get_render_status | Récupérer le statut d'un rendu | render_id |

### 2.4 Edge Functions nécessaires

| Edge Function | Rôle | Déclenchement |
|---------------|------|---------------|
| whiteboard-render | Rendu Storyboard → MP4 | RPC whiteboard_create_render_job |
| whiteboard-narration-tts | Génération TTS | RPC whiteboard_create_project |
| whiteboard-webhook | Webhook de notification | Fin de rendu |

### 2.5 Conclusion Phase 2

**Supabase peut stocker les Storyboards** : ✅ OUI (nouvelles tables requises)

**Supabase peut stocker les Narrations** : ✅ OUI (nouvelles tables + bucket requis)

**Supabase peut stocker les Projets Whiteboard** : ✅ OUI (nouvelles tables requises)

**Supabase peut stocker les Rendus générés** : ✅ OUI (nouvelles tables + bucket requis)

**Estimation** : 1 semaine de création tables + RPCs + Edge Functions

---

## PHASE 3 – ARCHITECTURE STORYBOARD FINALE

### 3.1 Structure hiérarchique

```
Storyboard
  ↓
Scenes
  ↓
Blocks
```

### 3.2 Structure JSON finale

```json
{
  "version": "1.0",
  "created_at": "2026-06-23T14:00:00Z",
  "created_by": "user_id",
  "subject": "Sujet de la feuille pédagogique",
  "theme": "notebook",
  "layout": {
    "orientation": "portrait",
    "aspect_ratio": "9:16",
    "padding": 20
  },
  "scenes": [
    {
      "id": "scene_001",
      "order": 0,
      "title": "Introduction",
      "duration_ms": 5000,
      "blocks": []
    }
  ],
  "audio": {},
  "narration": {},
  "export": {}
}
```

### 3.3 Structure Scene

```json
{
  "id": "scene_uuid",
  "order": 0,
  "title": "Titre de la scène",
  "duration_ms": 5000,
  "transition": {
    "type": "fade|slide|zoom",
    "duration_ms": 500
  },
  "blocks": [
    {
      "id": "block_uuid",
      "type": "title|paragraph|formula|...",
      "content": "Contenu du bloc",
      "order": 0,
      "visible": true,
      "animation": {},
      "position": {},
      "style": {}
    }
  ]
}
```

### 3.4 Types de blocs supportés (V1)

| Type | Description | V1 |
|------|-------------|----|
| title | Titre principal | ✅ |
| subtitle | Sous-titre | ✅ |
| paragraph | Paragraphe de texte | ✅ |
| bullet_list | Liste à puces | ✅ |
| numbered_list | Liste numérotée | ✅ |
| formula | Formule mathématique (LaTeX) | ✅ |
| image | Image | ✅ |
| quote | Citation | ✅ |
| divider | Séparateur | ✅ |

### 3.5 Propriétés communes des blocs

```json
{
  "id": "block_uuid",
  "type": "title|paragraph|...",
  "content": "Contenu du bloc",
  "order": 0,
  "visible": true,
  "animation": {
    "type": "fade_in|slide_up|typewriter",
    "duration_ms": 500,
    "delay_ms": 0,
    "easing": "ease_in_out"
  },
  "position": {
    "x": 0.5,
    "y": 0.1,
    "width": 0.9,
    "height": 0.1
  },
  "style": {
    "font_family": "Roboto",
    "font_size": 24,
    "font_weight": "bold",
    "color": "#000000",
    "background_color": "#FFFFFF",
    "padding": 10
  }
}
```

### 3.6 Conclusion Phase 3

**Structure Storyboard définie** : ✅ OUI

**Hiérarchie Scenes → Blocks** : ✅ OUI

**Types de blocs V1** : ✅ 9 types définis

**Estimation** : 0 semaine (schéma déjà défini dans SMART_WHITEBOARD_STORYBOARD_SCHEMA.md)

---

## PHASE 4 – COMPOSANTS PÉDAGOGIQUES ACADEMIA

### 4.1 Blocs spécialisés Academia

| Type | Description | Structure JSON |
|------|-------------|----------------|
| definition | Définition d'un concept | term, definition, example |
| theorem | Théorème mathématique | statement, proof, reference |
| exercise | Exercice | question, hint, solution |
| correction | Correction d'exercice | exercise_id, steps, explanation |
| quiz | Questionnaire | questions, options, correct_answers |
| important_note | Note importante | content, icon, priority |
| warning | Avertissement | content, severity, action |

### 4.2 Structure JSON détaillée

#### 4.2.1 Definition

```json
{
  "type": "definition",
  "term": "Photosynthèse",
  "definition": "Processus par lequel les plantes convertissent la lumière en énergie chimique.",
  "example": "Les feuilles absorbent la lumière solaire pour produire du glucose.",
  "style": {
    "term_color": "#0000FF",
    "definition_color": "#000000",
    "example_color": "#666666"
  }
}
```

#### 4.2.2 Theorem

```json
{
  "type": "theorem",
  "statement": "Théorème de Pythagore",
  "proof": "a² + b² = c²",
  "reference": "Euclide, Éléments, Livre I",
  "style": {
    "statement_font_weight": "bold",
    "proof_font_style": "italic"
  }
}
```

#### 4.2.3 Exercise

```json
{
  "type": "exercise",
  "question": "Quelle est l'équation de la photosynthèse ?",
  "hint": "Pense aux réactifs et produits",
  "solution": "6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂",
  "style": {
    "question_color": "#000000",
    "hint_color": "#666666",
    "solution_color": "#008000"
  }
}
```

#### 4.2.4 Correction

```json
{
  "type": "correction",
  "exercise_id": "exercise_uuid",
  "steps": [
    "Identifiez les réactifs",
    "Identifiez les produits",
    "Équilibrez l'équation"
  ],
  "explanation": "La photosynthèse utilise le CO₂ et l'eau pour produire du glucose et de l'oxygène.",
  "style": {
    "step_number_color": "#0000FF",
    "explanation_color": "#000000"
  }
}
```

#### 4.2.5 Quiz

```json
{
  "type": "quiz",
  "questions": [
    {
      "id": "q001",
      "question": "Qu'est-ce que la photosynthèse ?",
      "options": [
        "Respiration",
        "Conversion lumière en énergie",
        "Digestion"
      ],
      "correct_index": 1
    }
  ],
  "style": {
    "question_color": "#000000",
    "option_color": "#666666",
    "correct_color": "#008000"
  }
}
```

#### 4.2.6 Important Note

```json
{
  "type": "important_note",
  "content": "La photosynthèse nécessite de la lumière solaire.",
  "icon": "info|warning|error|success",
  "priority": "high|medium|low",
  "style": {
    "background_color": "#E3F2FD",
    "icon_color": "#0000FF",
    "text_color": "#000000"
  }
}
```

#### 4.2.7 Warning

```json
{
  "type": "warning",
  "content": "Attention : La photosynthèse ne peut pas se faire sans lumière.",
  "severity": "critical|warning|info",
  "action": "Assurez-vous d'avoir une source de lumière.",
  "style": {
    "background_color": "#FFF3E0",
    "icon_color": "#FF6600",
    "text_color": "#000000"
  }
}
```

### 4.3 Justification de la structure

**Séparation sémantique** : Chaque type a un rôle pédagogique spécifique
**Réutilisabilité** : La structure peut être étendue avec d'autres types
**Flexibilité** : Les styles sont personnalisables par thème
**Extensibilité** : De nouveaux types peuvent être ajoutés sans casser l'existant

### 4.4 Conclusion Phase 4

**Composants pédagogiques définis** : ✅ OUI

**7 types spécialisés Academia** : ✅ OUI

**Structure JSON justifiée** : ✅ OUI

**Estimation** : 0 semaine (structure définie)

---

## PHASE 5 – SYSTÈME DE RENDERERS

### 5.1 Objectif

Le contenu doit être indépendant du thème graphique.

### 5.2 Renderers définis

| Renderer | Description | Style |
|----------|-------------|-------|
| notebook | Style cahier avec lignes | Fond ligné, écriture manuscrite |
| scientific | Style scientifique | Fond blanc, formules LaTeX |
| blackboard | Style tableau noir | Fond noir, craie blanche |
| minimal | Style minimaliste | Fond gris clair, épuré |

### 5.3 Structure d'un renderer

```json
{
  "id": "notebook",
  "name": "Cahier",
  "background": {
    "type": "image",
    "image_url": "https://example.com/notebook.png",
    "color": "#FFFFFF"
  },
  "text": {
    "primary_color": "#000000",
    "secondary_color": "#666666",
    "font_family": "HandwritingFont"
  },
  "blocks": {
    "title": {
      "font_size": 28,
      "font_weight": "bold",
      "color": "#000000"
    },
    "paragraph": {
      "font_size": 16,
      "font_weight": "normal",
      "color": "#000000"
    },
    "formula": {
      "font_size": 18,
      "color": "#0000FF"
    }
  },
  "accent": {
    "highlight_color": "#FFFF00",
    "border_color": "#000000"
  }
}
```

### 5.4 Mapping Storyboard → Renderer

```json
{
  "storyboard": {
    "theme": "notebook",
    "blocks": [...]
  },
  "renderer": {
    "id": "notebook",
    "config": {...}
  }
}
```

### 5.5 Conclusion Phase 5

**Système de renderers défini** : ✅ OUI

**4 renderers définis** : ✅ OUI

**Indépendance contenu/thème** : ✅ OUI

**Estimation** : 1 semaine (création assets + configuration)

---

## PHASE 6 – CLOUD RENDERER

### 6.1 Architecture cible

```
Flutter
  ↓
Storyboard JSON
  ↓
Kamatera Cloud (Backend Python)
  ↓
Renderer (Moteur de rendu)
  ↓
MP4
  ↓
Pipeline Challenge existant
```

### 6.2 Composants réutilisables

| Composant | Localisation | Réutilisation | Adaptation |
|-----------|-------------|--------------|------------|
| FFmpeg | Kamatera (installé) | ✅ 100% | Aucune |
| studio_video_renderer.py | academia_bobodo_backend | ⚠️ 30% | Extension majeure |
| tv_pro_filter_builder.py | academia_bobodo_backend | ⚠️ 40% | Extension majeure |
| videoasset_worker.py | academia_bobodo_backend | ✅ 80% | Adaptation légère |

### 6.3 Nouveaux composants nécessaires

| Composant | Nécessité | Complexité |
|-----------|-----------|------------|
| Endpoint Storyboard → MP4 | Critique | Haute |
| Moteur de rendu Storyboard | Critique | Très haute |
- Générateur de frames depuis blocs | Critique | Très haute |
- Moteur d'animation progressive | Critique | Haute |
- Mixage audio (narration) | Critique | Moyenne |
- Queue de jobs de rendu | Critique | Moyenne |

### 6.4 Flux de rendu détaillé

```
1. Flutter → RPC app_whiteboard_create_render_job
   ↓
2. Supabase → whiteboard_renders (status=queued)
   ↓
3. Worker Kamatera (poll whiteboard_renders)
   ↓
4. Worker télécharge Storyboard JSON depuis Supabase
   ↓
5. Worker télécharge narration audio depuis Supabase Storage
   ↓
6. Moteur de rendu génère frames depuis blocs
   ↓
7. Moteur d'animation applique animations progressives
   ↓
8. FFmpeg assemble frames + audio → MP4
   ↓
9. Worker upload MP4 vers Supabase Storage
   ↓
10. Worker met à jour whiteboard_renders (status=done, video_url)
   ↓
11. Flutter récupère video_url via RPC app_whiteboard_get_render_status
```

### 6.5 Moteur de rendu Storyboard

**Fonctionnalités requises** :
- Parser Storyboard JSON
- Générer des frames depuis chaque bloc
- Appliquer les animations (fade_in, slide_up, typewriter)
- Gérer les transitions entre scènes
- Mixer la narration audio
- Assembler le tout en MP4 via FFmpeg

**Approche technique** :
- Utiliser Pillow (Python) pour générer des images depuis texte
- Utiliser matplotlib pour générer des formules LaTeX
- Utiliser FFmpeg pour assembler images + audio
- Utiliser les expressions FFmpeg existantes pour animations

### 6.6 Conclusion Phase 6

**Cloud Renderer faisable** : ⚠️ OUI (développement majeur requis)

**Composants réutilisables** : ~30% (FFmpeg, worker pattern)

**Nouveaux composants** : Moteur de rendu Storyboard (très complexe)

**Estimation** : 4-6 semaines de développement

---

## PHASE 7 – PLAN DE DÉVELOPPEMENT SÉQUENCÉ

### 7.1 Étape 1 – Structure Storyboard (1 semaine)

**Objectif** : Définir et valider le format Storyboard JSON

**Tâches** :
- ✅ Schéma JSON déjà défini (SMART_WHITEBOARD_STORYBOARD_SCHEMA.md)
- Validation du schéma avec JSON Schema
- Documentation des types de blocs
- Documentation des renderers

**Livrables** :
- Schéma JSON validé
- Documentation complète

**Risque** : Faible (schéma déjà défini)

### 7.2 Étape 2 – Stockage Supabase (1 semaine)

**Objectif** : Créer les tables et RPCs Supabase

**Tâches** :
- Créer les tables (whiteboard_projects, whiteboard_scenes, whiteboard_narrations, whiteboard_renders)
- Créer les RPCs (7 RPCs)
- Créer les buckets Storage (whiteboard-projects, whiteboard-narrations, whiteboard-renders)
- Créer les RLS policies
- Tester les RPCs via RPC Python administrateur

**Livrables** :
- Tables créées
- RPCs créés
- Buckets créés
- Tests validés

**Risque** : Moyen (dépendance Supabase)

### 7.3 Étape 3 – Écrans Flutter (2 semaines)

**Objectif** : Créer les écrans Flutter pour le Smart Whiteboard

**Tâches** :
- Créer smart_whiteboard_input_screen.dart (saisie sujet)
- Créer smart_whiteboard_editor_screen.dart (édition contenu)
- Créer smart_whiteboard_preview_screen.dart (prévisualisation)
- Créer smart_whiteboard_service.dart (service Bobodo)
- Créer smart_whiteboard_models.dart (modèles de données)
- Intégrer avec l'onglet Challenge existant

**Livrables** :
- 3 écrans créés
- 1 service créé
- 1 fichier de modèles créé
- Intégration validée

**Risque** : Moyen (dépendance Flutter)

### 7.4 Étape 4 – Service Bobodo (1 semaine)

**Objectif** : Intégrer Bobodo pour la génération de contenu

**Tâches** :
- Créer le prompt système pour génération Storyboard
- Adapter l'Edge Function bobodo-chat pour générer Storyboard JSON
- Tester la génération de Storyboard depuis sujet
- Valider le format JSON généré

**Livrables** :
- Prompt système validé
- Edge Function adaptée
- Tests validés

**Risque** : Moyen (dépendance OpenRouter)

### 7.5 Étape 5 – Cloud Renderer (4-6 semaines)

**Objectif** : Déployer le renderer sur Kamatera

**Tâches** :
- Déployer le backend Python sur Kamatera
- Créer le moteur de rendu Storyboard
- Créer l'endpoint Storyboard → MP4
- Créer le worker de rendu vidéo
- Configurer Docker Compose sur Kamatera
- Tester le rendu complet
- Optimiser les performances

**Livrables** :
- Backend déployé sur Kamatera
- Moteur de rendu fonctionnel
- Worker fonctionnel
- Tests validés

**Risque** : Très élevé (complexité très haute)

### 7.6 Étape 6 – Connexion au pipeline Challenge (1 semaine)

**Objectif** : Intégrer le Smart Whiteboard avec le pipeline existant

**Tâches** :
- Intégrer smart_whiteboard_preview_screen.dart avec video_publish_screen.dart
- Passer le MP4 généré au pipeline existant
- Tester le flux complet
- Valider que les parcours Filmer et Importer ne sont pas modifiés

**Livrables** :
- Intégration validée
- Flux complet testé
- Parcours existants non modifiés

**Risque** : Faible (intégration simple)

### 7.7 Résumé du plan

| Étape | Durée | Risque | Dépendances |
|-------|-------|--------|-------------|
| Étape 1 – Structure Storyboard | 1 semaine | Faible | Aucune |
| Étape 2 – Stockage Supabase | 1 semaine | Moyen | Étape 1 |
| Étape 3 – Écrans Flutter | 2 semaines | Moyen | Étape 2 |
| Étape 4 – Service Bobodo | 1 semaine | Moyen | Étape 1 |
| Étape 5 – Cloud Renderer | 4-6 semaines | Très élevé | Étape 2 |
| Étape 6 – Connexion pipeline | 1 semaine | Faible | Étape 3, 5 |
| **Total** | **10-12 semaines** | **Élevé** | **Séquentiel** |

---

## RISQUES TECHNIQUES

### 8.1 Risque 1 – Kamatera non prêt pour le rendu

**Description** : Kamatera n'a actuellement aucun service de rendu vidéo actif.

**Impact** : Critique

**Mitigation** :
- Déployer le backend Python sur Kamatera en priorité
- Déployer le worker de rendu vidéo sur Kamatera
- Configurer Docker Compose sur Kamatera

**Validation requise** : Test de déploiement backend sur Kamatera avant Étape 5

### 8.2 Risque 2 – Moteur de rendu Storyboard très complexe

**Description** : Le moteur de rendu Storyboard doit générer des images depuis texte, appliquer des animations, mixer l'audio.

**Impact** : Critique

**Mitigation** :
- Commencer par un MVP simple (texte + fade_in)
- Étendre progressivement (formules LaTeX, animations complexes)
- Utiliser des bibliothèques existantes (Pillow, matplotlib)

**Validation requise** : POC du moteur de rendu avant Étape 5

### 8.3 Risque 3 – Performance du rendu

**Description** : Le rendu Storyboard → MP4 peut être lent sur Kamatera (4 vCPU, 9.7 Go RAM).

**Impact** : Moyen

**Mitigation** :
- Optimiser le moteur de rendu
- Limiter la résolution des frames
- Utiliser le cache pour les frames réutilisables

**Validation requise :** Benchmark de performance avant Étape 5

### 8.4 Risque 4 – Bobodo ne génère pas de Storyboard JSON valide

**Description** : Bobodo peut générer du JSON invalide ou incomplet.

**Impact** : Moyen

**Mitigation** :
- Valider le JSON généré avec JSON Schema
- Fournir des exemples à Bobodo
- Implémenter un système de retry

**Validation requise** : Tests de génération Storyboard avant Étape 4

### 8.5 Risque 5 – Intégration avec le pipeline Challenge casse l'existant

**Description** : L'intégration peut modifier les parcours Filmer et Importer.

**Impact** : Critique

**Mitigation** :
- Respecter strictement la directive de protection
- Ne modifier aucun fichier existant
- Tester les parcours existants après intégration

**Validation requise** : Tests de régression après Étape 6

---

## POINTS NÉCESSITANT VALIDATION AVANT DÉVELOPPEMENT

### 9.1 Validation 1 – Kamatera peut-il héberger le backend Python ?

**Question** : Peut-on déployer le backend Python sur Kamatera ?

**Action requise** : Test de déploiement backend sur Kamatera

**Critère de succès** : Backend accessible via HTTP sur Kamatera

### 9.2 Validation 2 – Kamatera peut-il exécuter FFmpeg pour le rendu ?

**Question** : FFmpeg peut-il être utilisé pour générer des MP4 depuis des images ?

**Action requise** : Test FFmpeg sur Kamatera (génération MP4 depuis images)

**Critère de succès** : MP4 généré avec succès

### 9.3 Validation 3 – Bobodo peut-il générer un Storyboard JSON valide ?

**Question** : Bobodo peut-il générer un Storyboard JSON conforme au schéma ?

**Action requise** : Test de génération Storyboard via Bobodo

**Critère de succès** : JSON valide conforme au schéma

### 9.4 Validation 4 – Le moteur de rendu Storyboard est-il faisable ?

**Question** : Peut-on générer des images depuis texte avec Python ?

**Action requise** : POC Pillow/matplotlib pour génération images

**Critère de succès** : Images générées avec succès

### 9.5 Validation 5 – L'intégration ne casse-t-elle pas l'existant ?

**Question** : L'intégration Smart Whiteboard modifie-t-elle les parcours Filmer et Importer ?

**Action requise** : Tests de régression sur les parcours existants

**Critère de succès** : Parcours existants inchangés

---

## CONCLUSION

### 10.1 Faisabilité globale

**Smart Whiteboard IA V1 faisable** : ⚠️ OUI (avec développement majeur)

**Estimation** : 10-12 semaines

**Risque global** : Élevé (dépendance Kamatera + complexité moteur de rendu)

### 10.2 Architecture recommandée

```
Flutter
  ↓
Storyboard JSON
  ↓
Supabase (stockage)
  ↓
Kamatera (rendu)
  ↓
MP4
  ↓
Pipeline Challenge existant
```

### 10.3 Points critiques

1. **Kamatera** : Doit être configuré pour le rendu vidéo (développement requis)
2. **Moteur de rendu** : Très complexe, nécessite un POC
3. **Bobodo** : Doit être adapté pour générer Storyboard JSON
4. **Intégration** : Doit respecter strictement la directive de protection

### 10.4 Recommandation

**Valider les 5 points critiques avant de lancer le développement** :

1. Déployer et tester le backend sur Kamatera
2. Tester FFmpeg pour génération MP4 depuis images
3. Tester Bobodo pour génération Storyboard JSON
4. POC du moteur de rendu Storyboard
5. Valider que l'intégration ne casse pas l'existant

**Si validation réussie** : Lancer le développement séquencé (10-12 semaines)

**Si validation échouée** : Réviser l'architecture ou abandonner le projet

---

**Fin du document**
